#!/bin/bash

# Simple script to create a kdialog/zenity dialog or call similar wish
# script which prints one fortune cookie from package fortune-cs
# Click on the dialog window to close it or wait a moment
#
# RCS: @(#) $Id: fortune-cs.sh,v 1.0 2006/11/28 19:01:01 zp Exp $

[ -z "$DISPLAY" ] && exit
TITLE="Citát z balíčku fortune-cs"
FCOMMAND="/bin/bash /etc/profile.d/x-fortune-cs.sh"
DELAY="12"
kdialog --passivepopup "`$FCOMMAND`" $DELAY --title "$TITLE" 2>/dev/null \
|| zenity --info --text="$FCOMMAND" --title "$TITLE" 2>/dev/null \
|| /usr/games/fortune-cs.tk

