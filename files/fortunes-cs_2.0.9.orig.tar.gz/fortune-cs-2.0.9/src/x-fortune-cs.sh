  # Everything in file ~/.fortune will be interpreted as command
  # parameters for fortune. Default is cs (czech texts).
  # To disable fortune, create ~/.fortune with single word `none'.
  # The binary itself should evaluate the state of locale settings

  #FORTUNEDIR=/usr/share/games/fortune
  FORTUNE=cs
  if [ -r ~/.fortune ]; then
    FORTUNE=`cat ~/.fortune`
  fi
  if [ "$FORTUNE" != "none" ]		&& \
     [ "$TERM" != "dumb" ]		&& \
     [ -x /usr/bin/fortune ]		&& \
     [ -x /usr/bin/tty ]		&& \
     #?[ "$USER" != "postgres" ]	&& \
     ! /usr/bin/tty | grep -q not
  then
       echo
       /usr/bin/fortune $FORTUNE
       echo
  fi
  unset FORTUNE FORTUNEDIR

