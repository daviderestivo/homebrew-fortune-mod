  TODAY'S SPAM
  ============

This package contains fortunes taken from subjects and bodies
of SPAM messages (mails, newsgroup posts, etc.); they are not
edited, except when lines were longer than 72 chars.


  WARNING
  =======
Some of the fortunes are _really_ vulgar and obscene;
you're warned.  Plaintext files are "encrypted" with rot13.


  INSTALL
  =======

Copy the files 'spam-o' and 'spam-o.dat' in one of the following
directory:
  /usr/local/share/games/fortunes/off/
  /usr/share/games/fortunes/off/
  /usr/local/share/games/fortunes/
  /usr/share/games/fortunes/

or wherever your unix puts fortune files.
In Linux, if you put the files in an "/off/"(ensive) directory the
fortune program will read the files only when the "-o" or "-a"
option is used (for details: man fortune).

If you're interested in Italian spam, you've to copy also the
files 'spam-ita-o' and 'spam-ita-o.dat'.
The charset of both files (spam-o and spam-ita-o) is iso-8859-1
(latin1); convert it to suite your system, if needed.


  CONTRIBUTING
  ============

You can send me funny or strange quotes taken from _real_
SPAM messages (links and names of specific products will
be removed!).
Beware that I _heavily_ filter my email addresses against
spam (isn't it ironic?), so it's better if you send me the
text "encrypted" with rot13 or the original message (g)zipped.
Please don't send me emails larger than few KB).


  AUTHOR
  ======

Davide Alberani

e-mail:         da@erlug.linux.it or alberanid@libero.it
my homepage:    http://erlug.linux.it/~da/
fortunes-spam page: http://erlug.linux.it/~da/soft/fortunes-spam/
Jabber ID:      alberanid@jabber.linux.it (I'm on-line only from time to time)
ICQ UIN:        83641305 (nick 'Mad77') (I'm on-line only from time to time)
PGP KeyID:      0x465BFD47 (the key is available in my homepage and
                            through every keyserver)

Sometimes you can find me IRCing on channels #python, #linux-it and
so on over irc.openprojects.net with the nick 'Mad77'.


  LICENSE
  =======

This package is SoulWare(tm): use it, and you'll go to hell!

Seriously:
This program is free software; you can redistribute it and/or modify
it under the terms of the BSD license.

NOTE: if you need/want a release of this package under a different free
license (e.g.: the GPL license), just ask me!

Copyright (c) Davide Alberani.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of the University nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.


  TODO
  ====

- More fortunes!
- RPM packages!!
- Get viagra online!!!


  CHANGELOG
  =========

* version 1.8 - 05 Jun 2010
  - 109 new cans of spam (1746 in total).
  - 70 new cans of Italian spam (346 in total).

* version 1.7 - 05 Mar 2009
  - 113 new cans of spam (1637 in total).
  - 42 new cans of Italian spam (276 in total).

* version 1.6 - 02 May 2008
  - 153 new cans of spam (1524 in total).
  - 68 new cans of Italian spam (234 in total).

* version 1.5 - 05 May 2007
  - 132 new cans of spam (1371 in total).
  - 15 new cans of Italian spam (166 in total).

* version 1.4 - 17 Sep 2006
  - 149 new cans of spam.
  - 77 new cans of Italian spam.

* version 1.3 - 09 Oct 2005
  - 80 new cans of spam.
  - 14 new cans of Italian spam.

* version 1.2 - 24 Apr 2005
  - 88 new cans of spam.
  - 19 new cans of Italian spam.

* version 1.1 - 04 Jan 2005
  - 111 new cans of spam.
  - 11 new cans of Italian spam.

* version 1.0 - 11 Nov 2004
  - 103 new cans of spam.
  - 3 new cans of Italian spam.

* version 0.9 - 19 Aug 2004
  - 65 new cans of spam.
  - 2 new cans of Italian spam.

* version 0.8 - 05 May 2004
  - 65 new cans of spam.
  - 1 new can of Italian spam.

* version 0.7 - 25 Feb 2004
  - 57 new cans of spam.

* version 0.6 - 02 Jan 2004
  - renamed "spam" to "spam-o" and "spam-ita" to "spam-ita-o"
    so that they can work correctly with the BSD fortunes.
  - 95 new cans of spam.
  - 5 new cans of Italian spam.

* version 0.5 - 27 Nov 2003
  - 99 new cans of spam.
  - "spam-ita" file with 19 Italian fortunes.

* version 0.4 - 26 Oct 2003
  - 88 new cans of spam.

* version 0.3 - 05 Oct 2003
  - 98 new cans of spam.

* version 0.2 - 24 Sept 2003
  - added "Today's spam:" introduction.
  - 57 new cans of spam.

* version 0.1 - 12 Sept 2003
  - first public release (85 cans of spam)

