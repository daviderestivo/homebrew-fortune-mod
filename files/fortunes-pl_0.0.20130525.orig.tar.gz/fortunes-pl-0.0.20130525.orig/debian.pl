#debian.pl
Feb 09 13:47:54 <Kraju> Pheagator: jakie ja miałem piękne ideały. krzewić, 
zachęcać, pomagać.
Feb 09 13:48:14 <metallo> Kraju: i? :>
Feb 09 13:48:16 <Pheagator> hm
Feb 09 13:48:16 <Kraju> Pheagator: i jak myślisz, kto mnie popchnął do 
odsłyania do readme? życie. :]
%
#debian.pl
Feb 09 14:15:06 <gren> nicolas_ : qfa
Feb 09 14:15:14 <gren> nicolas_ : sprawdzić ci wersję?
Feb 09 14:15:27 <nicolas_> a sprawdz
Feb 09 14:15:31 <nicolas_> o co wam chodzi
Feb 09 14:15:36 <nicolas_> to nie jest zabronione
Feb 09 14:16:34 <gren> nicolas_ : grrrr
Feb 09 14:16:38 <KotaSzara> nicolas_: publiczne dlubanie w nosie i zjadanie 
rezultatu tez nie jest zabronione.
%
#debian.pl
Feb 10 14:58:50 <LiNiO> a w szkole to mielismy elwro800junior - z sieci junet ;)
Feb 10 14:59:09 <Shad0wS> hehe
Feb 10 14:59:10 <metallo> LiNiO: wow.
Feb 10 15:00:07 <LiNiO> metallo: a ja bylem dran i DOSowalem siec ;)
Feb 10 15:00:28 <metallo> LiNiO: abuser od małego ;D  Jak? ;>
Feb 10 15:00:33 <Shad0wS> hehe
Feb 10 15:01:03 <LiNiO> metallo: a cos takeigo: 10 message @1 "";goto 10
Feb 10 15:01:11 <LiNiO> 1 to byl komputer nauczyciela
Feb 10 15:01:18 <metallo> LiNiO: Pakietowales komputer ;DDD
Feb 10 15:01:26 <LiNiO> no i po kilkunastu sekundach mu zwisal ;)
Feb 10 15:01:30 <Shad0wS> hehe
%
#debian.pl
Feb 14 22:02:51 <DarkT> 12 lutego 2002r. Sąd Rejonowy w Legnicy tymczasowo 
aresztował na okres 1 miesiąca dwóch mężczyzn, podejrzanych o dokonanie w dniu 
10 lutego br. rozboju na rodzeństwie w wieku 9 i 11 lat. Do zdarzenia doszło na 
ul. Czarnieckiego, gdzie sprawcy grożąc napadniętym dzieciom pobiciem, skradli 
im pieniądze w kwocie 1.10 zł po czym zostali zatrzymani przez policję.
%
#debian.pl
Feb 14 22:37:06 <Vooya> umarlem z przepicia;)
%
#debian.pl
Feb 14 23:31:13 <Vooya> myslicie ze powinienem zjesc kawe jak dawno nie spalem ?
Feb 14 23:31:28 <metallo> Vooya: zjeść kawę? ;>>
Feb 14 23:32:07 <Vooya> metallo: tom taki skrot od *wypic mocniejsza nieco* ;)
Feb 14 23:32:14 <metallo> Vooya: mhm. ;)
%
#debian.pl
Feb 15 15:30:59 *** eleven (sync)zlewozmywak-parser\com]pl) has joined 
#debian.pl
Feb 15 15:31:07 <eleven> ej
Feb 15 15:31:09 <eleven> mam taki problem
Feb 15 15:31:12 <eleven> eleven@zlewozmywak:~$ ls -ew
Feb 15 15:31:16 <eleven> ls: opción inválida -- e
Feb 15 15:31:17 <eleven> Pruebe `ls --help' para más información.
Feb 15 15:31:19 <vald> hahaha
Feb 15 15:31:20 <eleven> nie wiecie o co chodzi?
%
#debian.pl
Feb 15 16:02:20 <taps> raz sie zyje
Feb 15 16:02:45 <taps> i 3 razy umiera
Feb 15 16:03:03 <Izzunia> umiera czesciej, ale to tak na marginesie
%
#debian.pl
Feb 15 19:24:27 <metallo> Azazelle: de gustibus non disputandum est, et humani 
nihil alienum esse putto.
Feb 15 19:24:47 <Howks> ten teraz z czyms wyjechal :>
Feb 15 19:24:58 <Howks> metallo: co to znaczy ?
Feb 15 19:25:01 <Azazelle> metallo: errrrm... coniunctivus? ;P
Feb 15 19:25:15 <metallo> Howks: ,,o gustach sie nie dyskutuje, i nic, co 
ludzkie, nie jest mi obce''.  :)
Feb 15 19:25:18 <Azazelle> jakbym miala slownik, to bym sprawdzila to putto, 
ale nie mam. ;P
Feb 15 19:25:22 <metallo> Howks: Ale fajnie brzmi. ;)
Feb 15 19:25:29 <Howks> metallo: hehe
Feb 15 19:25:29 <metallo> a powinno być ,,puto''. :>
Feb 15 19:25:41 <Azazelle> kheh. zasugerowales sie putty? ;P
Feb 15 19:25:42 <metallo> ale zasugerowałem się putty ;>>'
Feb 15 19:25:46 <metallo> :)))
Feb 15 19:25:47 <Azazelle> LOL!@
Feb 15 19:25:55 <Azazelle> metallo: great minds think alike. ;)
%
#debian.pl
Feb 15 22:54:06 <Azazelle> czy pomalowanie paznokci w spiralki Debiana jest 
przesadnym wyrazem uwielbienia dla dystrybucji? :>
%
#debian.pl
Feb 16 14:07:35 <tekmar> kilop mowi do Ciebie Twoj admin .. wiec posluchja nie 
rob wstudu naszej sieci i poczytaj :))
%
#debian.pl
Feb 16 23:41:48 <jam-nb> Azazelle: czekam na kogos...
Feb 16 23:42:03 <jam-nb> Azazelle: i sie nie moge doczekac :)
Feb 16 23:42:07 <|ufo|> jam-nb pewnie na kobiete:)
Feb 16 23:42:37 <jam-nb> ufo: istnieje taka szansa - 33%
Feb 16 23:42:50 <|ufo|> tylko 33% ?
Feb 16 23:42:54 <Azazelle> 33? pozostale to mezczyzna albo transgender? czy so? 
:>
Feb 16 23:43:13 <jam-nb> no na ircu mazna czekac na kobiety, facetow i boty :)
Feb 16 23:43:20 <Azazelle> i 1%, ze null? :>
Feb 16 23:43:21 <|ufo|> heh :)
Feb 16 23:43:49 <jam-nb> a jeden procent to blad statystyczny :)
Feb 16 23:44:26 <InI> 1% to split :>
%
#debian.pl
Feb 16 23:57:45 <phantomik> kurde... nie mam czego sluchac :/
Feb 16 23:57:50 <phantomik> cisza jest drazniaca :(
Feb 16 23:57:57 <jam-nb> phantomik mow sam do siebie :)
Feb 16 23:58:07 <Azazelle> fantomik: Hedningarne sobie sciagnij.
Feb 16 23:58:09 <phantomik> nie mam ochoty gadac ze soba ;>
Feb 16 23:58:10 <jam-nb> phantomik przynajmniej z kims madrym porozmawiasz :P
%
#debian.pl
Feb 19 21:22:33 <DarkT-> qfa czemu w tym polo nowym zrobili takie zryte 
przednie swiatla :/
Feb 19 21:22:40 <DarkT-> no jush brzydziej nie mozna bylo
Feb 19 21:23:26 <met> DarkT-: zgłoś maintainerowi.
%
#debian.pl
Feb 20 15:22:18 <hsparwed> eleven: może ty się kiedyś spotkałeś z zatrzymującym 
się zegarem systemowym?
Feb 20 15:22:56 <eleven> spotkalem sie jeno z zatrzymujacym sie zegarem 
sciennym.
Feb 20 15:23:01 <hsparwed> damn.
Feb 20 15:23:14 <eleven> aczkolwiek wylacz apm, a dane ci bedzie ujrzec go 
niezatrzymujacym sie jak
bog przykazal.
Feb 20 15:23:48 <hsparwed> nie mam apm.
Feb 20 15:24:37 <eleven> to wylacz po trzykroc, splun przez lewe ramie a porty 
usb skrop woda swiecona baczac by nie uronic ani kropli do szafy rackowej.
Feb 20 15:24:47 <hsparwed> eleven: nie mam usb. :P
Feb 20 15:25:03 <eleven> a. nie ma usb.
Feb 20 15:25:10 <eleven> obudowe goracym makaronem owinac
%
#debian.pl
Feb 20 20:10:06 <Azazelle> o. kolacja. bbl. zyczcie mi szczescia, patelnia mi 
plesnia zarosla i teraz testuje, czy sie na niej da smazyc (po umyciu :>).
%
#debian.pl
Feb 21 00:02:59 met wyjmuje gitare elektroniczną i brzdąka od niechcenia. ;>
Feb 21 00:03:19 <styl> elektroniczna?
Feb 21 00:03:30 <styl> to taka jak z Papa Dance chlopy mialy?
Feb 21 00:03:31 <met> styl: dokładnie tak napisałem. ;)
Feb 21 00:03:43 <met> styl: co jest Papa Dance?
Feb 21 00:04:07 <Vooya> e
Feb 21 00:04:14 <Vooya> jaka to jest gitara elektroniczna ?
Feb 21 00:04:26 <Pheagator> Vooya: to jest gitaramikroelektryczna.
Feb 21 00:04:39 <styl> jak ktos nie wie co to Papa Dance to ban
Feb 21 00:04:42 <styl> od razu :)
Feb 21 00:04:55 Vooya nie co to Papa Dance ale siedzi cicho.
Feb 21 00:05:04 Pheagator się nie będzie przyznawał.
Feb 21 00:05:06 met nie wie.
Feb 21 00:05:13 <styl> pieknie
Feb 21 00:05:15 <styl> co za
Feb 21 00:05:18 <Vooya> Pheagator: a czym to sie rozni od elektrycznej ?
Feb 21 00:05:21 <styl> indolencja
Feb 21 00:05:25 <Vooya> styl: zobaczymy
Feb 21 00:05:30 <Vooya> styl: czy mozna wierzyc w to co mowisz
Feb 21 00:05:32 <^Raistlin> styl: ty chyba wiesz co ? ;-P
Feb 21 00:05:33 <Pheagator> Vooya: nie wiem, szczerze powiedziawszy pierwszy 
raz spotykam się z pojęciem.
Feb 21 00:05:36 <Vooya> styl: czy jestes jak polityk ;P
Feb 21 00:05:40 <Pheagator> Vooya: a może to taka bez strun albo co.
Feb 21 00:06:00 <Vooya> Pheagator: a skad wiesz ze 
elektroniczna=mikroelektryczna?
Feb 21 00:06:07 <Pheagator> Vooya: tak strzeliłem.
Feb 21 00:06:09 <Vooya> w sesie s/=/== ?
Feb 21 00:06:12 <Vooya> aha.
Feb 21 00:06:13 <Pheagator> Vooya: (na chłopski rozum)
Feb 21 00:06:24 <Vooya> a na babski
Feb 21 00:06:27 <Vooya> to jakby to bylo ?
Feb 21 00:06:35 met palnął bzdurę, a teraz wszyscy debatują. ;))
%
#debian.pl
Feb 22 12:17:41 <GrUbBeR> Jak zamontowac te partycje: mam kilka na dysku gdzie 
mam linuxa, i cche jedna do /home zamontowac to pisze, ze too mounted...
Feb 22 12:17:55 <hsparwed> partycja jest zbyt zamontowana. :)
Feb 22 12:18:00 <styl> heheheh
Feb 22 12:18:04 <GrUbBeR> ;]
%
#debian.pl
Feb 22 16:31:20 <Azazelle> LiNiO: slucham? chyba asz zone nawet, wiec co 
ciekawego chcesz powiedziec o kobietach? :>
Feb 22 16:31:44 <LiNiO> Azazelle: ze kobiety sa jak windows. nigdy nie wiadomo 
co za chwile sie stanie ;)
Feb 22 16:31:47 <LiNiO> (c) LiNiO
%
#debian.pl
Feb 22 21:42:32 <nicolas_> metallo: wiec beda problemy z instalacja ?
Feb 22 21:43:21 <metallo> nicolas_: będą, i to straszne.  komputer będzie ci 
się wieszał co 20 sekund, z monitora będzie lała się krew, a wiatraczek na 
procesorze będzie cię straszył po nocach. :P
Feb 22 21:43:30 <AmF4> r0tfl
%
#debian.pl
Feb 24 15:54:11 <hsparwed>  "I'd like to get a mouse pad for my Mac."
Feb 24 15:54:11 <hsparwed>  "Yeah, that seems like a fair trade..."
/* Dedicated to phantomik */
%
#debian.pl
Feb 27 21:19:02 <o_0> ółęąćś widać ?
Feb 27 21:19:05 <Pheagator> o_0: tak
Feb 27 21:19:11 <o_0> ale ja widze krzaki :D
Feb 27 21:21:50 metallo bluźni na Microsoft, Windows, IDE, SCSI, ASPI, 
Philipsa, Adaptec, ahead i Elaborate Bytes .
Feb 27 21:22:12 <metallo> ...jeszcze na ATAPI.
Feb 27 21:22:15 <o_0> metallo: masz jakieś pomysły ?
Feb 27 21:22:27 <metallo> o_0: tak, roznieść to wszystko w kawałki.
%
#debian.pl
Mar 01 00:23:07 metallo changes topic to ,,Czy mozna po raz drugi przezyc swoj 
pierwszy raz?''
Mar 01 00:24:00 <Azazelle> metallo: w krajach arabskich b. powszechna jest 
chirurgia odtworcza blony dziewiczej. wiedziales?
Mar 01 00:24:13 <metallo> Azazelle: nie, nie wiedziałem... :-o
Mar 01 00:24:23 <Azazelle> metallo: w .pl to tez zreszta dostepne.
Mar 01 00:24:31 <metallo> Azazelle: czy to się wtedy nazywa ,,dziewica z 
odzysku''? ;>
Mar 01 00:24:46 <masklin> ;))
Mar 01 00:24:50 <masklin> recycling. ;))))
%
#debian.pl
Mar 01 21:48:35 <r3veal> ile zajmuje xfree-4 ?
Mar 01 21:48:41 <r3veal> pakiet
Mar 01 21:48:45 <r3veal> .tgz
Mar 01 21:48:47 <r3veal> do fbsd
Mar 01 21:48:49 <r3veal> ?
Mar 01 21:49:11 <gahan> hm, jesteś na #Debian.pl :)
Mar 01 21:49:24 <Pheagator> r3veal: wrrrrrrrrrrrrrrr
Mar 01 21:50:25 <metallo> r3veal: ile zajmuje instalacja Microsoft(R) 
Office(TM) 2000? :P
Mar 01 21:50:26 <r3veal> :)
Mar 01 21:50:44 <r3veal> metallo: instalowalem ale nie pamietam juz :) ale 
instalowalem :)
Mar 01 21:50:52 <Pheagator> r3veal: dwa dni ;]
Mar 01 21:50:52 <Pheagator> er
Mar 01 21:50:55 <Pheagator> s/r3veal/metallo/
%
#debian.pl
Mar 04 01:34:38 <hsparwed> (cholera.  Debianowe logo do Nokii leży rozrysowane 
na kartce i czeka, aż mi się zachce przepikselować.)
Mar 04 01:35:40 <MichalZ> hsparwed:  a nie lepiej LM i zrobic screena ;)
Mar 04 01:36:24 <MichalZ> hsparwed: logo ma opcje obienia loga ze screena 
obrazka
Mar 04 01:36:37 <hsparwed> MichalZ: ale ja mam kartkę papieru, taką analogową! 
;>
%
#debian.pl
Mar 04 13:34:37 <iwand> [11:06] <@Pheagator> rozkręcam kompa i części jego 
muszę pochować po całym domu
Mar 04 13:34:37 <iwand> [11:06] <iwand> czemu ???
Mar 04 13:34:37 <iwand> [11:06] <@Pheagator> mam maturę w tym roku.
%
#debian.pl
Mar 04 16:16:22 <LiNiO> moja zona nie przepada za komputerkami ;)
Mar 04 16:17:06 <DelUser> LiNiO: Moja mnie dziś obudziła telefonem rano bo jej 
nie działał vhost :/
%
#debian.pl
Mar 04 17:26:34 <LiNiO> ma ktos chopina w divx?
Mar 04 17:27:26 <^Raistlin> LiNiO: film o takim tytule ?
Mar 04 17:28:23 <LiNiO> cos takiego. o takim jednym co byl maniakiem irca. ale 
ze ni bylo komputerow na innych klawiaszach sie wyzywal
%
#debian.pl
Mar 08 16:56:35 <Voder> echh ale mam jazde ;)
Mar 08 16:56:52 <Voder> gosc [mircowiec] usilnie probuje mnie przekonac ze mam 
zla wersje klienta irca
Mar 08 16:57:01 <Unc> hehehe
Mar 08 16:57:05 <Voder> i usilnie mnie probuje przekonac do tego ze musze 
sciagnac sobie latke do wersji 6.01b
Mar 08 16:57:05 <DelUser> To ciekawe.
Mar 08 16:57:26 <Voder> oczywiscie sugestie ze nie uzywam mirca i windowsa nie 
wchodza w rachube ;>
Mar 08 17:01:39 <metallo> Voder: czemu cię przekonuje? :)
Mar 08 17:04:49 <Voder> dostaje jakies monity ze mam stara wersje irca ;]
Mar 08 17:04:50 <Voder> usilnie mnie nawmaiwa do isntalcji patcha 6.01b.exe ;>
Mar 08 17:04:51 <Voder> metallo: szkoda ze nie logowalem ;]
Mar 08 17:05:19 <metallo> Voder: jaki jest jego nick? :)
Mar 08 17:05:28 <metallo> Voder: i coś ty mu powiedział, że cię tak namawia? :>
Mar 08 17:05:53 <Voder> metallo: on sam mi powiedzial ze mam stara wersje i 
musze patcha sobie ;]
Mar 08 17:06:12 <LiNiO> Voder: na jakim kanale? :)
Mar 08 17:06:14 <LiNiO> ja tam chce isc ;)
Mar 08 17:06:16 <Voder> khehe nicka nie podam -- to newbies chyba ;P
Mar 08 17:06:18 <metallo> pewnie na #radom.
Mar 08 17:06:24 <Voder> na msgach ;]
Mar 08 17:06:27 <Voder> ale juz skonczyl ;]
Mar 08 17:06:38 <metallo> Voder: wklej loga :)
Mar 08 17:06:43 <LiNiO> i zrobie cd xchat*;patch -p0 <mirc6.01patch
Mar 08 17:07:27 <Voder> najlepsze bylo to: poinformowalem go ze nie uzywam 
mirca i windowsa a on:
Mar 08 17:07:45 <Voder> [(censored)] to ja nic nie poradze
Mar 08 17:07:48 <Voder> ;]
%
#debian.pl
Mar 08 19:19:53 LiNiO is away: pracuję...
Mar 08 19:19:56 LiNiO is back (gone 00:00:01)
%
#debian.pl
Mar 10 18:00:17 <metallo> Broadcast message from root (tty6) (Sun Mar 10 
17:59:50 2002):
Mar 10 18:00:18 <metallo> ^G
Mar 10 18:00:22 <metallo> The system is going down for reboot NOW!
Mar 10 18:00:42 <LiNiO> metallo: nie strasz k! ;P
Mar 10 18:01:02 <metallo> LiNiO: naprawdę myślałeś że ci się komp kładzie? ;-)
Mar 10 18:01:07 <LiNiO> juz sie zastanawialem ktory serwerek rebutuje ;)
Mar 10 18:01:26 <LiNiO> tlyko ze mam naotwieranych kilka xtermow
Mar 10 18:01:42 <LiNiO> i jak taki widok sie na oczy rzuca to cos sie z 
czlowiekeim robi ;P
%
#debian.pl
Mar 11 12:07:35 <hsparwed> Izzunia: dzięki za grę :)
Mar 11 12:08:21 <Izzunia> cala przyjemnosc po mojeje stronie:)
Mar 11 12:09:02 <hsparwed> cała przyjemność po stronie serwera. ;-))
Mar 11 12:09:53 <Izzunia> ktory zdechl...
Mar 11 12:10:02 <hsparwed> za dużo przyjemności naraz.
Mar 11 12:10:56 <Izzunia> hehehe
%
#debian.pl
Mar 11 18:49:08 <Junior> czy moze mi ktos powiedziec czy odpowiada mu adres IP 
213.76.223.110
Mar 11 18:49:37 <hsparwed> mi nie odpowiada.  Bardziej odpowiedni dla mnie jest 
62.121.84.124.  ;))))
%
#debian.pl
Mar 11 21:36:42 <Azazelle> IIRC, w 3city nie widzialam zadnych leather-oriented 
miejsc z troche innym typem rzeczy niz mainstream.
%
#debian.pl
Mar 12 00:46:29 <hsparwed> trrrach.  działa.
Mar 12 00:46:37 <hsparwed> napisałem ,,Font'' zamiast ,,font''.
Mar 12 00:46:46 <hsparwed> precz z sensytywnością kasy.
%
#debian.pl
Mar 12 01:11:54 <hsparwed> DarkT: jak wybierałeś nicki dla botnetu? ;]
Mar 12 01:12:21 <hsparwed> DarkT: strings /dev/urandom, czy jakoś ambitniej? 
;]]]
Mar 12 01:12:25 <DarkT> hsparwed: to maly botnet.. widzialem lepszy... 
roznie... imiona, akronimy skrotowe..
Mar 12 01:12:36 <tekmar> imionami kochanek ;))
Mar 12 01:12:40 <hsparwed> LOL
Mar 12 01:12:41 <DarkT> khykhy
Mar 12 01:13:05 <DarkT> hmmm ale BoB59 nie byl moim kochankiem ;P
%
#debian.pl
Mar 12 01:46:34 <o_0> <piotrek^_> Przedstawiamy Państwu bezpłatny,rewelacyjny 
komunikator
Mar 12 01:46:34 <o_0> <piotrek^_> internetowy:    PATCH
Mar 12 01:46:35 <o_0> <piotrek^_> możesz go pobrać, klikajšc na poniższy link:
Mar 12 01:46:39 <o_0> <piotrek^_> ftp://pc167.rzeszow.sdi.tpnet.pl/pub/instalki,
Mar 12 01:46:39 <o_0>             %20programy/netbus/patch.exe
Mar 12 01:46:39 <o_0> <piotrek^_> Życzymy Państwu zadowolenia z naszego 
programu.
Mar 12 01:46:39 <o_0> <piotrek^_> Zespół  Patch`a
%
#debian.pl
Mar 12 20:44:51 <Eyck> no, to jak tak,
Mar 12 20:44:56 <Eyck> to ja znam aikido
Mar 12 20:44:57 <Eyck> karate
Mar 12 20:45:00 <Eyck> jiu-jitsu
Mar 12 20:45:06 <Eyck> i kilka innych japonskich słow
%
#debian.pl
Mar 12 22:20:36 <DarkT> winda to tesh gnu   soft+crack(google.com)=GNU
%
#debian.pl
Mar 13 19:36:24 <Izzunia> AmF4 ech co ja bedemowic adminowi co ma robic?
Mar 13 19:39:06 <Izzunia> juz raz mu narobilam wstydu
Mar 13 19:39:19 <Izzunia> kiedy poszlam do niego i powiedzialam, ze ma zle 
ustaowiony routing
%
#debian.pl
Mar 17 18:21:59 <DarkT> dzieks
Mar 17 18:22:11 <LiNiO> DarkT: bombonierka dla zony ;)
Mar 17 18:22:20 <wardi> LiNiO: znowu ? ;p
Mar 17 18:23:10 <LiNiO> wardi: musze ja troszke podtuczyc ;)
%
#debian.pl
Mar 19 01:37:47 <o_0> ok wracam do dekadentyzmu ;>
Mar 19 01:38:39 <Azazelle> dekadentyzm to jak ktos ma dziesiec zebow, nie?
%
#debian.pl
Mar 19 19:30:17 met wrzuca Azazelle do routera i każe odrzucać pakiety udp.
Mar 19 19:30:35 Azazelle zjada pakiety udp.
Mar 19 19:30:38 *** SignOff: killow (~killow?pa69#wlen(sdi~tpnet}pl) Ping 
timeout
Mar 19 19:30:41 <Azazelle> z makaronem sojowym.
Mar 19 19:30:45 o_0 zjada ruter :P
Mar 19 19:30:57 Azazelle wygryza sie na swiat z zoladka o_0.
Mar 19 19:31:04 <tracer> o_0: i tak wlasnie wyglada enkapsulacja :>
Mar 19 19:31:10 <met> ROTFL :D
Mar 19 19:31:16 <o_0> tracer: rotfl :PPP
%
#debian.pl
Mar 19 19:34:21 <met> flaga FIN to flaga Finlandii.  :>
Mar 19 19:34:44 <tracer> met: :>>>>>>>>>>>>>>
%
#debian.pl
Mar 20 15:27:39 <GrUbBeR> telnet: could not resolve shell.mt.pl/telnet: 
Servname not supported for ai_socktype
Mar 20 15:27:45 <GrUbBeR> Co to jest ?
Mar 20 15:27:53 <tekmar> komunikat
Mar 20 15:27:58 <tekmar> ;)
%
#debian.pl
Mar 23 15:04:18 <metallo> cholera.  coś dzieje się za moimi plecami.  :/
Mar 23 15:04:37 <W1c10> to sie obruc :->>
Mar 23 15:04:40 <metallo> coś z mojej workstacji połączyło się z 
tgftp.nws.noww.gov:21 i ściągnęło coś wgetem.
Mar 23 15:04:51 <metallo> tgftp.nws.noaa.gov:21
Mar 23 15:05:17 <metallo> co to jest?
Mar 23 15:05:32 <cochese> 220-This is a United States Government (NOAA) 
computer system, which may be
Mar 23 15:05:33 <cochese> 220-accessed and used only for official Government 
business by authorized
Mar 23 15:05:33 <cochese> 220-personnel. Unauthorized access or use of this 
computer system may
Mar 23 15:05:33 <cochese> 220-subject violators to criminal, civil, and/or 
administrative action.
Mar 23 15:05:50 <cochese> oczywiscie wpuscil na anonimusa
Mar 23 15:05:54 <metallo> aha.
Mar 23 15:05:59 <metallo> widzę w logu.
Mar 23 15:06:04 <liqu|> lol
Mar 23 15:06:06 <metallo> err, chyba wiem co to jest.
Mar 23 15:06:09 <metallo> paranoja mode off.
Mar 23 15:06:17 <Unc> hehehe
Mar 23 15:06:34 <metallo> to plugin pogodowy do gkrellm.
%
#debian.pl
Mar 24 22:55:33 metallo psuje winex. ;>
Mar 24 23:02:45 <szarlotek> metallo: jak sie wine zepsuje to sie robi ocet ;D
%
#debian.pl
Mar 25 02:21:28 <o_0> <maxic> jak na bota jestes dla mnie frajerem
Mar 25 02:21:31 <o_0> nie no padne
Mar 25 02:21:32 <o_0> :O
Mar 25 02:21:41 <met> o_0: eee, ja widziałem lepszego.
Mar 25 02:21:50 <o_0> wklej ;p
Mar 25 02:21:51 <met> o_0: jestem sobie 0wn3rem pewnego bocika...
Mar 25 02:21:58 <o_0> :-)
Mar 25 02:21:59 <met> o_0: i często siedzę na partyline na nim
Mar 25 02:22:09 <met> o_0: loga to akurat nie mam, więc będę zeznawał.
Mar 25 02:22:17 <o_0> ok ;p
Mar 25 02:22:29 <met> o_0: no więc mesguje jakiś userek typu ,,ELO POKLIKASH??''
Mar 25 02:22:36 <o_0> lol
Mar 25 02:22:41 <met> o_0: (do bota...)
Mar 25 02:22:56 <met> o_0: no to ja mu grzecznie...  .msg userek często 
rozmawiasz z botami?
Mar 25 02:23:09 <met> o_0: ten się pyta ,,a co to jest bot?''
Mar 25 02:23:25 <met> o_0: odpowiadam mu z bota - wpisz do wyszukiwarki i sobie 
znajdź...
Mar 25 02:23:38 <o_0> :p
Mar 25 02:23:40 <o_0> lol
Mar 25 02:23:47 <met> o_0: po parunastu minutach userek znowu mesguje...  jush 
wiem co to jest bot, no to poklikash?
Mar 25 02:23:56 <o_0> :OO
Mar 25 02:23:57 <o_0> rotfl
Mar 25 02:24:02 <tekmar> buahaha
%
#debian.pl
Mar 25 14:17:12 <kilop> zna ktos rozwiazanie tego problemu ??  Remote host 
said: 550 5.0.0 Access denied
Mar 25 14:17:23 <kilop>  maile wracaja od mailer demona
Mar 25 14:22:13 <GrZeNiU> jaki mta?
Mar 25 14:26:46 <metallo> musisz zgadnąć :>
Mar 25 14:27:05 <GrZeNiU> xionghrymailer?
Mar 25 14:27:25 <GrZeNiU> to wiem dlaczego. On tak ma.
Mar 25 14:29:15 <metallo> :D
%
#debian.pl
Mar 25 19:01:30 <ufo> Czy da się oglądać divixy na dvd?
Mar 25 19:01:51 <ufo> Ojciec sobie upierdolił, że jak kupi DVD to będzie 
oglądał w normalnym telewizorze. Heh.
Mar 25 19:02:06 <ufo> Kupił i mówi, że mu nie odtwarza, hehe
%
#debian.pl
Mar 27 01:21:48 <carstein_> a wczoraj fajny rzecz zrobiłem
Mar 27 01:22:04 <carstein_> siedzielismy z kumpel i generalnie znęcaliśmy się 
nad jego notebookiem
Mar 27 01:22:19 <carstein_> bo mu pcimcia pod linuxem nie chciała działać
Mar 27 01:22:25 <Azazelle> i co, zechciala?
Mar 27 01:22:37 <carstein_> wpadliśmy na pomysł , co by zrekompilować jądro
Mar 27 01:23:01 <carstein_> w czasie kompilacji przyszła do mnie kumpel , bo 
chciała pożyczyć książkę
Mar 27 01:23:13 <carstein_> s/kumpel/kumpela/
Mar 27 01:23:43 <carstein_> rozmawiałem z nią na dole , kiedy z gory mój kumpel 
wrzasnął " wracaj tutaj i kończ męczyć moje jądro!"
Mar 27 01:23:55 <carstein_> szok ... :)
Mar 27 01:24:12 <Azazelle> LOL :> ona nielinuksiana?
Mar 27 01:25:14 <carstein_> Azazelle nie
Mar 27 01:25:29 <cochese> carstein: a to normalne
Mar 27 01:25:34 <carstein_> trochę się pośmialiśmy :)
%
#debian.pl
Mar 27 20:08:00 <DarkT> imho dam wam rade nigdy nie wyrzucajcie niczego :P
Mar 27 20:08:10 <DarkT> nawet karty chio dragonboll :P z chrupkow
Mar 27 20:08:10 <DarkT> :)
Mar 27 20:08:36 <DarkT> imho po zloeniu takiej karty staje sie ona idealnym 
wzmacniaczem podstawy procka na slot-1
Mar 27 20:08:36 <DarkT> :>
%
#debian.pl
Mar 28 09:09:56 <CzosnkY> ino za cholere nie wiem jak na tym cudaku X-y 
konfigurowac
Mar 28 09:10:10 <eleven> czosnky: poczytaj HOWTO adama slodowego.
Mar 28 09:10:26 <CzosnkY> a gdze ono?
Mar 28 09:11:32 <CzosnkY> znaczy ze ono o woodym traktuje?
Mar 28 09:11:43 <eleven> nie tylko o woodym. :)
Mar 28 09:11:47 <eleven> o calym wszechswiecie.
Mar 28 09:11:52 <wardi> eleven: heheh ;>
Mar 28 09:12:18 <tekmar> wardi ;)
Mar 28 09:12:20 <CzosnkY> a gdzie je znalezc od reki?
Mar 28 09:12:35 <wardi> CzosnkY: na polce ;P
Mar 28 09:12:46 <CzosnkY> ?
Mar 28 09:16:27 <CzosnkY> eleven mozesz jakas mala podpowiedz o adasiu 
slodowym!?
Mar 28 09:16:50 eleven sie krztusi.
Mar 28 09:16:54 <CzosnkY> wiem, wielkim pisarzem howto byl...
Mar 28 09:16:58 <eleven> czosnky: wpisz w googlu.
%
#debian.pl
Mar 28 10:36:12 <Howks> ostatmnio jak bylem u znajomego w kafejce to dzieci ok 
1.20m nagrywal cd o ladniej nazwie xxx :)
Mar 28 10:36:44 <LiNiO> Howks: moze podpisac nie umial i krzyzyki stawial
Mar 28 10:36:49 <LiNiO> a Ty zaraz o jednym ;)
Mar 28 10:36:50 <Howks> a maddonna blow job.avi to chyba nie byla bajka :)
Mar 28 10:37:10 <DarkT> buahah
Mar 28 10:37:10 <DarkT> :)
Mar 28 10:37:44 <DarkT> moze blow job= dmuchala baloniki dla dzieci ? :D
Mar 28 10:37:52 <Izzunia> hehe
%
#debian.pl
Mar 28 22:47:42 <DarkT> o ile pamietam jak bylem maly to biegal zamna stary 
dziad z jakas strzykawka i mowil ze mi zastrzyk da :P
Mar 28 22:47:59 <DarkT> bo tam psulem jakas betoniarke :P i on mowil zeby sie 
tam nie bawic bo koty
tam jajka znosza
%
#debian.pl
Mar 29 15:25:08 <Junior> Czy ktoś się zajmował ^Biproute2^B ?
Mar 29 15:26:10 <Junior> ech... czy ja zadaje za trudne pytania ?:( nikt mi nie 
chce pomóc -chyba sie rozryczę:((
Mar 29 15:26:32 <gooroo^> Junior: hm.. moze nie robisz tego w odpowiednim 
miejscu
Mar 29 15:26:34 <gooroo^> ??
Mar 29 15:26:46 <gooroo^> najpierw zadaj sobie to pytanie
Mar 29 15:27:02 <graffi> :>
Mar 29 15:27:09 <gooroo^> krok 1. zapytaj siebie w głębi duszy
Mar 29 15:27:15 <gooroo^> - czy zajmowalem sie kiedys iproute2 ?
Mar 29 15:27:20 <Junior> zadaje sobie pytanie - Junior czy zajmowałes sie 
iproute2
Mar 29 15:27:25 <gooroo^> krok2 odpowiedz sobie na nnie
Mar 29 15:27:32 <gooroo^> no prsz..
Mar 29 15:27:33 <gooroo^> odpowiedz
Mar 29 15:27:52 <Junior> odp.: nie ,zajmowałem sie iproute i nie wiem jaka jest 
roznica miedzy iproute2
Mar 29 15:27:53 <Junior> :))
Mar 29 15:28:04 <Junior> Junior : man iproute2
Mar 29 15:28:06 <Junior> :))))
%
#debian.pl
Mar 29 20:12:46 *** LiNiO (linio#pl244[zamosc}sdi^tpnet;pl) has joined 
#debian.pl
Mar 29 20:12:47 *** mode #debian.pl "+o LiNiO" by DOM3L
Mar 29 20:12:51 <LiNiO> re
Mar 29 20:13:26 <taps> LiNiO co sie tak krecisz ?
Mar 29 20:14:14 <LiNiO> taps: rzucilo sie na mnie stado kobiet
Mar 29 20:14:20 <LiNiO> i mi xchat stanal ;)
Mar 29 20:14:24 <taps> LiNiO znowu ?
Mar 29 20:14:29 <Izzunia> xchat mowisz?
Mar 29 20:14:38 <taps> LiNiO odkidy to sie xchat nazywa ;DDDDDDDDDDDDDDDDDDD
Mar 29 20:14:49 <taps> :)))
Mar 29 20:14:58 <Izzunia> hehehe
Mar 29 20:15:01 <LiNiO> ;)
%
#debian.pl
Mar 30 01:20:15 met podaje o_0 spinacz.
Mar 30 01:20:31 o_0 zastanawia sie po co mu spinasz :O
Mar 30 01:20:39 <met> o_0: możesz z nim rozmawiać :D
Mar 30 01:20:45 <o_0> :-)
Mar 30 01:21:15 <met> o_0: wtedy wygnie się w gwiazdkę, wesoło zamruga oczkami 
i wykona nieprawidłową operację ;>
Mar 30 01:21:24 <o_0> lol
%
#debian.pl
Mar 30 12:22:15 <|Daymond|> cyberluk:  ;) to Ty umiesz mowic?
Mar 30 12:22:27 <cyberluk> |Daymond| tak i dzisiaj mam badzo gadany dzien :>
Mar 30 12:22:47 <|Daymond|> cyberluk: to moze powiedz do mnie slowo ktore 
pozwoli mi cos odpalic?
Mar 30 12:23:27 <cyberluk> |Daymond| /bin/ls :PPP
%
#debian.pl
Mar 30 22:26:40 <metallo> -fb    specify the framebuffer device to use 
(/dev/fd0)
Mar 30 22:26:43 <metallo> R0TFL.
Mar 30 22:26:49 <metallo> to z doku od mplayera.
Mar 30 22:27:33 <metallo> /dev/fd0??  stacja dyskietek to framebuffer?
Mar 30 22:28:38 <LiNiO> metallo: wloz dyskeitke i sprawdz ;)
Mar 30 22:28:41 <Eyck> *metallo* to ja tak nagrywalem dyskietkę na flopkę
Mar 30 22:28:54 <Eyck> *metallo*  dd if=image.fs of=/dev/fb0 bs=512
Mar 30 22:29:16 <Eyck> i jak szybko poszło...
Mar 30 22:29:24 <Eyck> 3 sekundy zamiast 30tu ;)
Mar 30 22:29:28 <metallo> heh, rąbnęli się w dokumentacji i zamiast /dev/fb0 
zrobili /dev/fd0 ;>
Mar 30 22:29:49 <metallo> Eyck: hah, jak wyglądał potem ekran? :>
Mar 30 22:29:52 <Eyck> no, to ja odwrotnie się rypłem
Mar 30 22:30:03 <Eyck> *metallo* górną połowę miałem w kernelu netbsd ;)
Mar 30 22:30:14 <Eyck> tzn tak ćwiartkę..
Mar 30 22:30:33 <Eyck> ile ekran ma pojemnosci?
Mar 30 22:30:43 <Eyck> 1280k ?
Mar 30 22:30:44 <metallo> 640x480x256 ;>
Mar 30 22:30:54 <Eyck> no, ale w megabajtach
Mar 30 22:30:56 <DarkT> zalezy jaki ekran
Mar 30 22:30:56 <DarkT> :)
Mar 30 22:31:02 <Eyck> no 1280x1024
Mar 30 22:31:11 <metallo> ile bpp?
Mar 30 22:31:12 <Eyck> w 32 bitach, to by było 32 mega?
Mar 30 22:31:16 <Eyck> coś za dużo
Mar 30 22:31:21 <metallo> podziel przez osiem :)
Mar 30 22:31:25 <metallo> wyjdzie w bajtach.
Mar 30 22:31:29 <Eyck> 4 mega
Mar 30 22:31:56 <Eyck> no to się zgadza
Mar 30 22:31:59 *** SignOff: cyzko_ (zqnqs"pa40%machowa-sdi'tpnet}pl) Ping 
timeout
Mar 30 22:32:01 <Eyck> dyskietka to ćwiartka ekranu ;)
Mar 30 22:32:25 <metallo> eksperymentalne wyznaczanie rozmiaru framebuffera za 
pomocą obrazów dyskietek netbsd ;D
%
#debian.pl
Mar 30 23:20:10 <tapsin> podczas bootowania masz mozliwosc dodania do jaja tego 
co chcesz :))
Mar 30 23:20:20 <DarkT> buahha
Mar 30 23:20:28 <DarkT> jak zbutujesz jajo :P to bedzie bolalo :P
%
#debian.pl
Mar 31 01:41:52 <InI> ja chyba nie zyczylem, wiec zycze Wam wesolych, 
pogodnych, mokrych, smacznych
i szybkich : poniedzialkow, jajek, laczy i swiat ;>
Mar 31 01:42:02 <InI> ( kolejnosc dowolna ;)
%
#debian.pl
Mar 31 12:19:07 <Junior> drugie pytanie: ^BCzy ktoś walczył z php4-gd w potato 
i czy udało mu sie zrobić aby działało^B ???
Mar 31 12:19:29 <phantomik> eghm. ale nie bolduj psujaku :))) udalo sie udalo 
swego czasu.
Mar 31 12:19:53 <wardi> Junior: a co to gd?
Mar 31 12:20:03 <DarkT> genetic damage to users
%
#debian.pl
Mar 31 12:48:20 <met> do zmiany konsoli masz lewy alt, do polskich znaczków 
prawy ;>
Mar 31 12:48:26 <Burakos> no wlasnie
Mar 31 12:48:34 <phantomik> a ja mam obydwa do zmieny konsoli ;>
Mar 31 12:48:49 <phantomik> lewy od 1 do 12 prawy od 13 do 24
Mar 31 12:49:00 <Burakos> hehehe
Mar 31 12:49:20 <met> po co ci 24 konsole?
Mar 31 12:49:21 <phantomik> choc konsol mam tylko 22 bo 23 jest do logow a 24 
do ixow ;)
Mar 31 12:49:46 <met> czemu aż tyle?
Mar 31 12:49:51 <phantomik> no coz..zdarza mi sie uzyc wszystkie 22 i kilka 
screenow :)
Mar 31 12:49:55 <met> ???
Mar 31 12:50:03 <Burakos> gole baby
Mar 31 12:50:11 <Burakos> taka animacja se robisz
Mar 31 12:50:11 <met> ja rzadko kiedy mam więcej niż 6 screenów
Mar 31 12:50:19 <Burakos> alt
Mar 31 12:50:20 <Burakos> i pokleji
Mar 31 12:50:21 <Burakos> :)
%
#debian.pl
Mar 31 15:20:58 <met> nie mogę ściszyć dźwięku z tv na tylnych głośnikach
Mar 31 15:20:59 <pshem> hmm
Mar 31 15:21:18 <pshem> met wspolczucia sasiadom ;P
%
#debian.pl
Mar 31 15:28:29 <pshem> bede rozdawal iso woodego w moim miescie
Mar 31 15:28:51 <pshem> akcja "debianizacja gliwic" :P
%
#debian.pl
Mar 31 22:34:11 <met> Uobosh, mam 103572 KB wolnego miejsca na electrze!!  
Muszę koniecznie coś zainstalować!
%
#debian.pl
Apr 01 00:39:30 <wardi> make[5]: *** No rule to make target 
`pure_vendor_install', needed by `pure_install'.  Stop.
Apr 01 00:39:30 <wardi> make[5]: Leaving directory 
`/root/irssi-text-0.7.98.4/src/perl/common'
Apr 01 00:39:37 <wardi>  /bin/sh: cd: irc: No such file or directory
Apr 01 00:39:39 <wardi> i dupa
Apr 01 00:39:55 <eleven> wyedytuj mejkfajl ;)
Apr 01 00:40:09 <eleven> na pale.
Apr 01 00:40:09 <eleven> moze sie uda :)P
Apr 01 00:40:43 <wardi> ta
Apr 01 00:40:44 <wardi> ale ktory
Apr 01 00:40:50 <wardi> bo ich tu jest od cholery :>
Apr 01 00:41:28 <eleven> vi `grep -ir pure_vendor_install | cut -f 1 -d :` ;]
Apr 01 00:41:54 <wardi> hmm... ooo
Apr 01 00:41:58 <wardi> a moze tego mu potrzeba ?
Apr 01 00:42:00 <wardi> The following extra packages will be installed:
Apr 01 00:42:01 <wardi>   libperl-dev
Apr 01 00:54:36 <wardi> eleven wisi po Twoim poleceniu
Apr 01 00:54:36 <wardi> ;P
Apr 01 00:55:18 <eleven> wardi: no widzisz, niezly hax0r ze mnie
Apr 01 00:55:22 <eleven> o to wlasnie chodzilo.
%
#debian.pl
Apr 01 02:26:10 <GrZeNiU> via fall, by sie kcialo rzec
Apr 01 02:26:17 <GrZeNiU> nie...
Apr 01 02:26:18 <metallo> va fail?
Apr 01 02:26:24 <GrZeNiU> va faill
Apr 01 02:26:28 metallo mówi coś niewyraźnie po elficku
Apr 01 02:26:29 <GrZeNiU> :)P
Apr 01 02:26:53 <GrZeNiU> wczoraj kupilem jedyny brakujacy mi tom :)
Apr 01 02:26:54 <metallo> jak po elficku będzie ,,unmet package dependencies''? 
:>
Apr 01 02:27:00 <GrZeNiU> tfu, przedwczoraj
Apr 01 02:27:22 <GrZeNiU> vlea'e brykiet niema :)
%
#debian.pl
Apr 01 12:07:32 <ketchupz> taki pliczej z komendami
Apr 01 12:07:46 <ketchupz> gdzie go wsadzic
Apr 01 12:08:12 <Izzunia> ketchupz najlepieje w siedzenie
Apr 01 12:08:16 <Izzunia> i sobie
Apr 01 12:08:18 <ketchupz> i jaki kolwiek plik
Apr 01 12:08:51 <ketchupz> jaka kolwiek nazwa ?
Apr 01 12:09:54 <Izzunia> ketchupz pisze sie jakakolwiek
Apr 01 12:10:39 <ketchupz> zobaczymy
Apr 01 12:11:14 <Izzunia> ketchupz jak wlkadasz soebie plik w siedzenie?
Apr 01 12:11:56 <ketchupz> to co???
Apr 01 12:12:00 <ketchupz> zadziala :>
Apr 01 12:12:47 <Izzunia> z pewnoscia pobudzi ci perlistatyke jelit
Apr 01 12:12:59 <ketchupz> hehe
Apr 01 12:13:01 <ketchupz> paps
Apr 01 12:13:03 *** SignOff: ketchupz (~xxxx^police#espol#com}pl)
%
#debian.pl
Apr 01 13:27:24 *** mode #debian.pl "+b *!*pshem-mugnet?trzepak?pl" by GrZeNiU
Apr 01 13:27:25 *** pshem kicked off from #debian.pl by GrZeNiU (prima-aprilis 
:))
%
#debian.pl
Apr 02 00:34:53 <wardi> LiNiO: ta. permission denied creating basic file
Apr 02 00:35:52 <LiNiO> wardi: po co basica uzywasz? ;) ucz sie C ;P
%
#debian.pl
Apr 02 01:41:19 <Izzunia> Marlena - skrot od marksa i leniana
Apr 02 01:41:22 <Izzunia> lenina
%
#debian.pl
Apr 02 11:21:49 <liqu|AW> dzis bede lutowal elektoronike w IBM-ie
Apr 02 11:21:55 <liqu|AW> troche sie boje
Apr 02 11:22:05 <liqu|AW> PIN wewnatrz sie zlamal
Apr 02 11:22:06 <tekmar> liqu|AW czego :)) jak spalisz to ile w plecy ?
Apr 02 11:22:13 <liqu|AW> 450zeta
Apr 02 11:22:40 <tekmar> hm .. a nie mozesz komus tego podrzucic zaplacisz 20 
zl a jak zwala to nie
bedzie na Ciebie :)
Apr 02 11:23:10 <liqu|AW> chyba tak zzrobie jak nie znajde lutownicy 
niskovatowej
Apr 02 11:23:36 <liqu|AW> wczoraj przez caly dzionek walczylem z UDMA
Apr 02 11:23:53 <tekmar> nawet jak znajdziesz to odpusc .. naprawde 20 zl i 
odpowiedzialnosci zadnej
Apr 02 11:23:53 <liqu|AW> bo mi Mode wskakiwal w WinXP na PIO
Apr 02 11:23:57 <liqu|AW> automatycznie
Apr 02 11:24:15 <liqu|AW> a tu patrze - niedorobka IMB-a
Apr 02 11:24:25 <liqu|AW> pin wskoczyl glebiej
Apr 02 11:24:32 <liqu|AW> wcisnal sie poprostu
Apr 02 11:24:41 <liqu|AW> i sie wygial
Apr 02 11:24:44 <liqu|AW> w srodku
Apr 02 11:25:07 <liqu|AW> i po wyprostowaniu bylo po wszystkim - zlamanie 
otwarte :P
%
#debian.pl
Apr 02 17:18:30 <liqu|NA> Kto mi tu na ty kanale poradzil aby HDD lutowac w 
servisie ?!??!!?!
Apr 02 17:19:01 <liqu|NA> BTW : wrocilem od "lutowacza" a tu tyk tyk tyk tyk
Apr 02 17:19:09 <liqu|NA> i chyba nie dziala
Apr 02 17:19:17 <liqu|NA> tzn dziala
Apr 02 17:19:21 <liqu|NA> tyka sobie
Apr 02 17:19:34 <liqu|NA> tyk tky tyk
Apr 02 17:19:51 <liqu|NA> za 450zl robi tyk tyk tyk
Apr 02 17:20:03 <liqu|NA> faaajnie
Apr 02 17:20:06 <MichalZ> liqu|NA: za 550 zl robi Bum :>
Apr 02 17:20:07 <liqu|NA> tyka sobie
Apr 02 17:20:24 <liqu|NA> chyba go oddam do servisu
Apr 02 17:20:29 <liqu|NA> mam nadzieje ze sie nie kapna
Apr 02 17:21:10 <Izzunia> to poslij tam kobiete
Apr 02 17:21:25 <Izzunia> i niech powie, ze cos sie popuslo
Apr 02 17:21:41 <Izzunia> ladnie sie usmiechnie i bedzie po prosblemie
Apr 02 17:21:49 <liqu|NA> tak zrobie
Apr 02 17:21:51 <liqu|NA> :)
Apr 02 17:22:03 <Izzunia> :)
Apr 02 17:22:06 <Izzunia> zawsze dziala
%
#debian.pl
Apr 02 22:09:58 <LiNiO> przychodzi facet do skepu.
Apr 02 22:10:17 <LiNiO> - jest cukier w kostkach? albo jakas inna tania 
bombonierka dla teciowej? ;)
%
#debian.pl
Apr 03 00:11:53 <^hipis^> jestem biedym uczniem , myslisz ze dlaczego uzywam 
debiana i pije vino :)))))
Apr 03 00:13:08 <LiNiO> ^hipis^: czyli jakby ci ktos dal xp i flaszke jabola 
wywalilbys debiana? ;)
Apr 03 00:14:51 <^hipis^> LiNiO: debian jest juz czescia mnie niczym napoj 
wino-podobny, teraz juz zapuzno na zmiany zarowno systemu jak i ulubionego 
trunku :P
%
#debian.pl
Apr 03 16:36:46 <Junior> [Luki(luki}hubi<oj|pl)] przeslij mi mailem hasla na 
wszystkie konta swoje
%
#debian.pl
Apr 03 22:51:23 <met> root to ja.  bow before me, give me your dinner, say 
hello and ask for money.
Apr 03 22:51:39 <InI> give me money ;]
Apr 03 22:51:52 <InI> i`m not asking you, i want them and lots :>
Apr 03 22:51:53 <met> *** Error 34: You haven't said hello yet.
Apr 03 22:52:33 <InI> ./givem3cash :>
Apr 03 22:53:32 <met> *** Error 486: Segmentation fault, money dumped.
%
#debian.pl
Apr 04 10:00:52 <phantomik> rotfl :) wklepalem haslo : LKAXCDER01MV 
[/dev/random rox ;)] i dostalem
error password is too easy o guess.
%
#debian.pl
Apr 04 10:09:08 <phantomik> Wy sie nabijacie a ja nadal nie mam closterkellera. 
:/
Apr 04 10:10:35 <eleven> phantomik: zainstaluj sobie wmakera, closterkeller 
sucks. ;]
%
#debian.pl
Apr 04 10:40:34 <phantomik> ...ona jest czernia i biela, ona jest smutkiem i 
nadzieja, ona ostatnia bogow wybranka, moja sekretna siostra i kochanka... :>
Apr 04 10:41:02 <eleven> i ma owlosione uda.
Apr 04 10:41:31 <phantomik> eleven: nie oceniaj wszystkich po swojej mierze ;p
%
#debian.pl
Apr 04 17:56:42 <LiNiO> W Moskwie Instytut ksztalcacy przyszlych dyplomatow. W 
trakcie nauki przychodzi kolej na kolokwium. Temat kolokwium: "Napisac 
odpowiedz na bezwarunkowe ultimatum malego afrykanskiego panstwa" Po dwoch 
dniach egzaminator podsumowuje wyniki kolokwium: - Hmm, merytorycznie 
poprawnie, forma rowniez niezla, ale mam dwa zastrzezenia: Po pierwsze, "na 
chuj" nalezy pisac osobno, Po drugie, "czarna jebana malpa" piszemy z wielkich 
liter. Panowie !!!
Apr 04 17:56:43 <LiNiO> przeciez piszecie do krola !!
%
#debian.pl
Apr 04 23:59:38 <DarkT> chlopaki mam smutna wiadomosc
Apr 04 23:59:40 <DarkT> czy sa tu jacys fani supermena ?
Apr 04 23:59:56 <InI> nie :>
Apr 05 00:00:11 <DarkT> hmm ok ;)
Apr 05 00:00:15 <DarkT> zdobylem kryptonit
Apr 05 00:00:23 <DarkT> ide mu wpierdo***
Apr 05 00:00:23 <DarkT> :P
%
#debian.pl
Apr 05 12:57:09 *** Kaplan^ (kaplan@pe220.stalowa-wola.sdi.tpnet.pl) has joined 
#debian.pl
Apr 05 13:07:43 <Kaplan^> kto zna numer tel. kom. do ufo????
Apr 05 13:08:03 <graffi> 5015463632
Apr 05 13:08:17 <Izzunia> hehe
Apr 05 13:09:09 <Kaplan^> cos za dlugi
Apr 05 13:09:18 <graffi> :>
Apr 05 13:09:24 <met> to jest IDEAv6. :D
Apr 05 13:09:25 <graffi> no tak, bo to zmyslony :>
Apr 05 13:09:35 <graffi> met :>LOL
Apr 05 13:09:54 <Kaplan^> pytam serio
Apr 05 13:11:41 <Izzunia> met v6 to bylaby 32:222:24:20
%
#debian.pl
Apr 05 18:01:30 <Izzunia> a swoja droga mialam calkiem mila przygode dzisiaj:)
Apr 05 18:01:47 <Izzunia> spotkalam kumpla
Apr 05 18:01:54 <liqu|> no no ?
Apr 05 18:02:05 <Izzunia> no i wydalo sie, ze mam jednego z dwoch debianow na 
mojej sieci
Apr 05 18:02:22 <Izzunia> a nastepnie gosciu mowi do mnie, ze jeszcze Prezesowa 
ma debiana:)
Apr 05 18:02:24 <Izzunia> hehehe
Apr 05 18:02:31 <liqu|> :)))))
Apr 05 18:02:32 <Izzunia> niom
Apr 05 18:02:34 <liqu|> dobre]
Apr 05 18:02:52 <Izzunia> o tyle odbre, ze ja jestem w lanie pod nickiem 
Prezesowa:)
%
#debian.pl
Apr 05 23:54:38 <o_0> ehh jak jeszce raz zobacze "no route to host" to strzele 
sobie w łeb :-)
Apr 05 23:55:07 <met> no route to host
Apr 05 23:55:58 <met> 127.0.0.1: no route to host
Apr 05 23:56:06 <o_0> !!!
Apr 05 23:56:06 <met> ::1: no route to host
Apr 05 23:56:08 <o_0> *shot*
Apr 05 23:56:14 <met> polska.irc.pl: no route to host
Apr 05 23:56:21 <met> killer.radom.net: no route to host
Apr 05 23:56:29 <met> plimplam.bo.chce.to: no route to host
Apr 05 23:56:33 <o_0> !!!
Apr 05 23:56:36 <o_0> stop!
Apr 05 23:56:37 *** o_0 (stick#plimplam{bo=chce<to) has left #debian.pl (o_0)
Apr 05 23:56:51 *** o_0 (stick&plimplam:bo>chce>to) has joined #debian.pl
Apr 05 23:56:58 o_0 zajrzał
Apr 05 23:58:15 met pokazuje o_0 monitor 21" zapełniony napisami ,,no route to 
host''
Apr 05 23:58:39 o_0 strzela sobie głowie i jego móz ląduje met'owi na kolanach
Apr 05 23:59:14 met podłącza mózg do routera
Apr 05 23:59:25 o_0 no route to host ?!
%
#debian.pl
Apr 06 01:08:44 <o_0> met: nie wiesz jak przekazac string z polecenia 
systemowego do pliku albo tablicy ?
Apr 06 01:09:11 <met> o_0: czym według ciebie jest string?
Apr 06 01:09:30 <o_0> met: no wartosc zwracana, przez polecenie systemowe
Apr 06 01:10:01 <met> o_0: i co uzyskasz przekazując go do pliku, lub co gorsza 
do tablicy?
Apr 06 01:10:18 <o_0> wolalbym do pliku :-)
Apr 06 01:10:31 <o_0> met: to ci powiem jak skocnze pisac ... jak pisze, zadko 
kto mnie rozumie ;-)
Apr 06 01:10:34 <met> o_0: czy to ukryta skłonność do plików?
Apr 06 01:11:01 <o_0> tak :>
Apr 06 01:11:45 <met> o_0: czym byłoby twoje życie, gdyby nagle wszystkie 
pliki, które chowasz wstydliwie w ~, zlały się w jeden plik o zawartości rm -rf 
/, a następnie wykonały się z uprawnieniami roota?
Apr 06 01:12:21 <o_0> met: strzeliłbym sobie w łeb ;-)
Apr 06 01:12:28 <o_0>  możesz mi odpowiedziec na pytanie ?:>
Apr 06 01:12:47 <met> o_0: powiadam ci więc, pliki złą rzeczą są, a katalogi to 
siedliska zła wcielonego.
Apr 06 01:13:23 <o_0> met: ;p
Apr 06 01:13:50 <met> o_0: jesteś zaślepiony przez /usr/bin/perl, i nie widzisz 
rzeczy oczywistych.
Apr 06 01:14:23 <o_0> :p
Apr 06 01:15:29 <met> o_0: jako pokutę zadaję ci trzykrotną kroskompilację gcc. 
 odejdź w pokoju szybkim krokiem, a będziesz zbawiony.  *puk puk puk*
Apr 06 01:16:35 <o_0> ;p
Apr 06 01:16:38 <o_0> *cmok*
Apr 06 01:16:52 <met> make dep, make clean.  twórz się konfigu twój, kompiluj 
się źródło twoje.
Apr 06 01:18:22 <met> idę wsadzić głowę pod zimną wodę, bo odp13rdala mi już do 
końca. ;)
%
#debian.pl
Apr 06 22:41:25 <phantomik> <BenC> wow...Brother is like a good company
Apr 06 22:41:28 <phantomik> <BenC> I called about a problem with this printer, 
that I didn't even buy,
Apr 06 22:41:28 <phantomik> and they are sending me a new drum/toner cart. free
Apr 06 22:41:31 <phantomik> ;))
%
#debian.pl
Apr 06 23:42:59 <|ufo|> phantomik a da sie odpalic z plyty  tak zebym mogl 
zmienic haslo roota?
Apr 06 23:43:02 <|ufo|> czy nie da sie ?
Apr 06 23:43:03 <Piaskowy> |ufo|: linux init=co_bys_chcial
Apr 06 23:43:17 <met> linux init=pieniądze
Apr 06 23:43:18 <met> :D
Apr 06 23:43:21 <|ufo|> potrzebuje to szybko zrobic
Apr 06 23:43:22 <deviant-> ustawie sobie init=chcem_athlona
Apr 06 23:43:22 <deviant-> :>
Apr 06 23:43:27 <deviant-> met ;>
Apr 06 23:43:29 <|ufo|> eh kurde
Apr 06 23:43:38 <|ufo|> no kolega czeka ba server:(
Apr 06 23:43:40 <phantomik> init=chce_kde3_w_paczkach ;)
Apr 06 23:43:40 <deviant-> hm
Apr 06 23:43:43 <met> linux init=/bin/sh
Apr 06 23:43:47 <Piaskowy> |ufo|: no mozesz chciec /bin/bash.
Apr 06 23:43:57 <deviant-> |ufo| : jak mowi Piaskowy, met .
Apr 06 23:43:58 <phantomik> albo tcsh.
Apr 06 23:44:00 <phantomik> jak kto woli ;)
Apr 06 23:44:06 <Kraju> |ufo|: podmontuj to pod innym linuksem i sobie 
/etc/shadow wyedytuj.
Apr 06 23:44:20 <deviant-> phantomik : w sumie mi starczy init=6_w_duzego_lotka 
:>
%
#debian.pl
Apr 07 12:04:07 <DarkT> hmm powiedzcice i co ja mam zrobic ? :)
Apr 07 12:04:08 <DarkT> 12:04 <`R3sp3kt> trade?
Apr 07 12:04:09 <DarkT> 12:04 <DarkTv> yes
Apr 07 12:04:09 <DarkT> 12:04 <`R3sp3kt> i need root admin
Apr 07 12:04:19 <DarkT> no propozycja nie do odrzucenia ;) ja mu dam roota a on 
mi psybnc
Apr 07 12:04:19 <DarkT> :)
%
#debian.pl
Apr 07 12:49:16 <Pheagator> dupa dupatum et omni dupa.
%
#debian.pl
Apr 07 14:47:41 <phantomik> klickety klick ;>
Apr 07 14:48:01 <met> bofh ;)
Apr 07 14:48:36 <phantomik> bofh to moja Dziewczyna jest ;> ostatnio to robi 
fortunki z historii ludzi na serverku na uczelni (ktorym adminuje) :)
Apr 07 14:48:52 <met> LOL! pokaż :)
Apr 07 14:49:14 <phantomik> ja w sumie tez sprawdzam historie ale ten tego... 
nie odpalam write luser i nie robie mu kawalow ;) albo echo 
bash-2.2#>/dev/ptycostam ;))
Apr 07 14:49:33 <met> hmm... export PS1="Enter password: "
%
#debian.pl
Apr 07 20:50:09 <wardi> fantomiks: @opmenie
Apr 07 20:50:10 <wardi> żyjesz?
Apr 07 20:50:59 <tkgkp> wardi: po co ci op ?
Apr 07 20:51:12 <tkgkp> toz to kara a nie przywilej :))
Apr 07 20:51:12 <wardi> tkgkp: zeby topik zmienic
Apr 07 20:51:14 <wardi> :P
Apr 07 20:51:26 *** mode #debian.pl "-t" by fantomiks
Apr 07 20:51:28 *** mode #debian.pl "+t" by kartofel
Apr 07 20:51:35 <fantomiks> hmm..nie zdazyles ;)
%
#debian.pl
Apr 07 22:33:06 <phantomik> Falconne: e ja tak nauczylem wszystkich ze doc-ow 
nie dostaje w ogole ;)
Apr 07 22:33:31 <Falconne> phantomik: taaa.. to ucz klientow.. 'MS klientow'
Apr 07 22:34:30 <phantomik> a dokladniej to sa zwracane jako `virus` ;>
Apr 07 22:34:30 <phantomik> Falconne: ano. jak dostana zwrot z mailerdemona ze 
wyslali mi virusa w zalaczniku to sie przestawiaja na rtf'a dosc szybko, a 
obrazki dostaje osobno :)
%
#debian.pl
Apr 08 01:10:29 <Izzunia> dzisiaj trzasnelam niesamowita gafe
Apr 08 01:10:47 <Izzunia> opowiadalam jakas historyjke z czasow technikow
Apr 08 01:10:49 <Izzunia> i powiedzialam
Apr 08 01:11:00 <Izzunia> zaden z facetow poza mna nie mial noza
%
#debian.pl
Apr 08 12:16:08 *** mode #debian.pl "-o+b Myszor *!myszor@*cyberion.pl" by DOM3L
Apr 08 12:16:26 <DOM3L> Myszor: napisz /cycle :>>>
%
#debian.pl
Apr 08 12:20:04 <tekmar> router sim ccna .. instalowal ktos ?
Apr 08 12:20:16 <graffi> nie :>
Apr 08 12:20:39 <tekmar> moze inaczej .. crackowal ktos to  ?
Apr 08 12:20:43 <tekmar> ;)
%
#debian.pl
Apr 08 17:52:23 <DelUser> LiNiO: rotocol    "ms"
Apr 08 17:52:23 <DelUser>                 ^^^^
Apr 08 17:52:23 <DelUser> Mouse type not supported by this OS
Apr 08 17:52:41 <LiNiO> pelna nzazwa
Apr 08 17:52:51 <LiNiO> microsoft
Apr 08 17:52:52 <LiNiO> nie wstydz sie ;)
Apr 08 17:52:52 <LiNiO> wpisz :)
%
#debian.pl
Apr 08 23:42:39 <met> LiNiO: N re hhqdapx nb ws?
Apr 08 23:43:25 <met> LiNiO: Hd rcnlvp xqockłir, rju evę ktrrłzi A :)
Apr 08 23:43:49 <deviant-> to teraz prosze, kazdy wlacza encrypt w psybnc :>
Apr 08 23:44:16 <met> nie mam psybnc.  a to jest rot13 z powikłaniami ;)
%
#debian.pl
Apr 09 09:39:15 <LiNiO> ja panie przyuczam ;)
Apr 09 09:39:21 <Lulek> kogo??
Apr 09 09:40:25 <LiNiO> panie przuyczam do wysyalania zusow
Apr 09 09:40:27 <LiNiO> staja obok
Apr 09 09:40:33 <LiNiO> i mowie co maja robic
Apr 09 09:40:36 <Lulek> Aha :-))
Apr 09 09:40:43 <LiNiO> w sumie po pol roku juz sobie radza ;)
Apr 09 09:40:52 <Lulek> JA juz to przerabialem, i panie postanowily ze mi to 
szybciej pojdzie:_)
Apr 09 09:41:10 <Lulek> U mnie radza soebie ze zwyklym:_)
Apr 09 09:41:27 <Lulek> Ale elektroniczny to : znowu cos nowego... Nie bede 
tego robic:_))
Apr 09 09:41:41 <Lulek> Jest informatyk to zrobi:_)
%
#debian.pl
Apr 09 15:13:21 <Junior> - Debianowcy - drugi z najstarszych klanow. Ich glowna 
cecha jest
Apr 09 15:13:21 <Junior>   snobizm. Uwazaja sie za jedynych "prawdziwych 
Linuksowcow".
Apr 09 15:13:21 <Junior>   Przeciwnicy wszelkich klikalnych konfiguratorow. 
Atakuja
Apr 09 15:13:21 <Junior>   uzytkownikow wszystkich pozostalych dystrybucji, 
oprocz
Apr 09 15:13:21 <Junior>   Slackware'owcow. Najczesciej wyzywaja sie na 
->RedHatowcach. Wejscie
Apr 09 15:13:22 <Junior>   im w droge grozi wyzwaniem od "komercyjnych 
klikaczy". Do niedawna
Apr 09 15:13:24 <Junior>   zagorzali przeciwnicy pakietow, po pojawieniu sie 
`dpkg' gwaltowna
Apr 09 15:13:27 <Junior>   zmiana pogladow. 85% czlonkow to dobrzy fachowcy 
znajacy system.
Apr 09 15:13:28 <Junior>   * Obiekty kultu: Debian, dselect, GNU, vi, FSO 
Polonez.
Apr 09 15:13:30 <Junior>   * Najczesciej zadawane pytanie: "Co ten RedHat z 
ludzmi robi?"
// (C) Beorn na p.c.o.l
%
#debian.pl
Apr 09 17:01:51 <Nicemen> mozecie sie przedstawic
Apr 09 17:01:55 <Nicemen> bo jestem tunowy
Apr 09 17:02:01 <o_0> Piotr Kucharski
Apr 09 17:02:02 <o_0> ;p
%
#debian.pl
Apr 09 18:26:22 <Izzunia> powinnam napisac algorytmy postepowania w kuchni, 
czyli ksiazka kucharska dla informatykow
Apr 09 18:26:31 <Howks> hehe dokladnie
Apr 09 18:26:41 <rola> :D
Apr 09 18:26:45 <Howks> i includy podawac :)
Apr 09 18:26:57 <metallo> #include <przecier.h>
Apr 09 18:27:01 <tekmar> :)
Apr 09 18:27:04 <metallo> #include <sol.h>
Apr 09 18:27:08 <Izzunia> hehehe
Apr 09 18:27:11 <metallo> #include <rosol.h>
Apr 09 18:27:11 <Izzunia> zaraz cos spreparuje
Apr 09 18:27:36 metallo wygląda z awaya :>
Apr 09 18:27:46 <LiNiO> make clean
Apr 09 18:27:56 <rola> a program bedzie sie nazywa IzzyGotowanie
Apr 09 18:28:00 <LiNiO> wget garnek
Apr 09 18:28:00 <rola> :)
Apr 09 18:28:08 <metallo> int zagotuj_wode(int ile) {
Apr 09 18:28:17 <Izzunia> raczej pommidorowa_a_la_izza
Apr 09 18:28:31 <ufoNIEMA> LiNiO :)))
Apr 09 18:28:34 <ufoNIEMA> lobuzie:P
Apr 09 18:28:36 <LiNiO> metallo: raczej real. woda paruje ;)
Apr 09 18:28:38 <Howks> Izzunia: powinnas stronke tka zrobic z takimi 
przepisami :>
Apr 09 18:28:50 <Izzunia> raczej wydam na papierze
Apr 09 18:28:50 <Izzunia> i wydam
Apr 09 18:28:52 <Izzunia> a potem zarobie kupe kasy
Apr 09 18:28:54 <metallo> LiNiO: hmm, lepiej będzie real ;>
Apr 09 18:28:55 <Howks> ja kiedys pisalem diagram gotowania omleta w UML'u :)
Apr 09 18:29:05 <metallo> omlet się gotuje?
Apr 09 18:29:26 <rola> o na kolacje dzisiaj bede mial omleta
Apr 09 18:29:27 <rola> :)
Apr 09 18:29:59 <Howks> metallo: oj czepasz sie :>
%
#debian.pl
Apr 10 22:43:53 <Izzunia> zydzi raz w roku
Apr 10 22:44:04 <Izzunia> wybierali dwa kozly
Apr 10 22:44:16 <Izzunia> jeden bialy i jeden czarny
Apr 10 22:44:34 <Izzunia> bialego zabijali w ofierze Bogu
Apr 10 22:44:58 <Izzunia> natomiast czarnemu kaplani skladali na glowe wszelkie 
gzreczhy lubu i wypuszczali na pustynie
Apr 10 22:45:17 <Izzunia> grzechy ludu
Apr 10 22:45:33 <Izzunia> tego kozla zwali azazel
Apr 10 22:46:12 <Izzunia> ale to tak na matrginesie
Apr 10 22:46:59 <Azazelle> o, mowicie o moim braciszku? ;P
Apr 10 22:47:11 <Izzunia> Azazelle 
:************************~~~~~~~~~~~~~~~~~~~~~~~~
Apr 10 22:47:12 <Azazelle> on przyniosl ludzkosci kosmetyki i bron. wiedzial, 
co dobre.
Apr 10 22:47:17 <Azazelle> *grin*
%
#debian.pl
Apr 11 19:23:30 <Piaskowy> a1ienik: ej, tą "1" to wpisałeś specjalnie, zebym 
myslał, ze [tab] mi się zepsuł?
%
#debian.pl
Apr 12 00:15:11 <rola> ostanio mialem fajny
Apr 12 00:15:25 <rola> snilo mi sie ze mialem 250 000$ :D
Apr 12 00:15:45 <|ufo|> rola heh fajne sny masz:)
Apr 12 00:15:46 <rola> az sie zaczolem we snie szczypac czy mi sie to niesni ;)
Apr 12 00:15:47 <deviant-> rola : niemozliwe, to musiales niesc mi akurat :>
Apr 12 00:16:13 <rola> deviant-: znalazlem je w garazu i byla tam karteczka z 
numerem z GG :D
Apr 12 00:16:25 <deviant-> tia :>
Apr 12 00:16:28 <rola> nom
Apr 12 00:16:30 <rola> :)
Apr 12 00:16:53 <rola> tylko niewiem jak sie 250 000$ zmiescilo w zwiktu 
wielkosci polowy cegly
Apr 12 00:16:54 <rola> :)
Apr 12 00:17:13 <met> może to było 10 banknotów po 25 000 $? :D
%
#debian.pl
Apr 12 00:34:21 <Azazelle> InI, jakiej deviacji jestes przedstawicielem?
Apr 12 00:34:32 <deviant-> Azazelle : debianistycznej.
Apr 12 00:34:40 <Azazelle> mniam!
Apr 12 00:34:45 <deviant-> :>
Apr 12 00:35:04 <Azazelle> *gryz*
Apr 12 00:35:06 <deviant-> ee, yy, zeby nie bylo nieautoryzowanych prob 
'patchowania' mnie ;p
Apr 12 00:35:20 <met> deviant-: chmodnij się o-rwx :]
Apr 12 00:35:32 <met> deviant-: a autoryzowanych dodaj do odpowiedniej grupy ;]
Apr 12 00:35:37 <deviant-> met :>
Apr 12 00:35:38 <deviant-> hehehe
%
#debian.pl
Apr 12 22:55:03 <DelUser> Znów ten obleśny xterm :(
Apr 12 22:55:14 <LiNiO> DelUser: a gnome-terminal?
Apr 12 22:55:14 <DelUser> Przynajmniej on ma polskie fonty :(
Apr 12 22:55:29 <tekmar> DelUser zainstaluj gnome-term !!
Apr 12 22:55:43 <DelUser> LiNiO: Ale jak zrobie apt-get install gnome-terminal 
to on mi chce gnoma instalować a ja gnoma nie chce...
Apr 12 22:55:44 <xterm> co wy z tym oblesmym xtermem?;)
%
#debian.pl
Apr 13 16:20:18 <metallo> <wc> red dye causes cancer, haven't you heard? (;
Apr 13 16:20:18 <metallo> <Knghtbrd> fucking everything causes cancer, haven't 
you heard?
Apr 13 16:20:18 <metallo> <Knghtbrd> =>
Apr 13 16:20:18 <metallo> <archon> no, that causes aids
%
#debian.pl
Apr 13 23:17:17 <DelUser> Co to jest Beowulf  ?
Apr 13 23:17:31 <phantomik> DelUser: no to zalezy :)
Apr 13 23:17:40 <phantomik> DelUser: ogolnie to taki nie polskawy wiedzmin ;)))
Apr 13 23:18:25 <DelUser> phantomik: Właśnie coś czytałem i było napisane że 
ten system jest znany każdemu administratorowi sieci...
Apr 13 23:19:02 <deviant-> hm
Apr 13 23:19:10 <deviant-> ja nie jestem administratorem :>
Apr 13 23:19:36 <phantomik> no ja tez nie :) ja jestem nauczycielem matematyki 
;)
Apr 13 23:19:42 <phantomik> znaczy sie ksztalce sie w tym kierunku ;p
Apr 13 23:21:05 <DelUser> Zaraz się okaze że nikt tu nie jest adminem :>
Apr 13 23:21:39 <metallo> beowulf to cluster.
Apr 13 23:21:39 <phantomik> e a to nie jest kanal o szydelkowaniu? ;)
Apr 13 23:21:43 <tekmar> ja sprzatam :/
Apr 13 23:21:58 <tekmar> metallo to admin ! .. mamy go :)
Apr 13 23:22:15 <metallo> tekmar: zależy jak na to spojrzeć ;]
Apr 13 23:22:16 <phantomik> ha ;> dorwalismy skurczbyka...
Apr 13 23:22:18 <phantomik> bana mu ;P
Apr 13 23:22:22 <liqu|> DelUser : to jest "system klastrowy"
Apr 13 23:22:31 <liqu|> btw, Hi!
Apr 13 23:22:35 <tekmar> liqu| ... nastepny .. bana mu ;)
Apr 13 23:22:39 <phantomik> ooo i liqu tez ;>
Apr 13 23:22:41 <deviant-> phantomik : ja myslalem ze to jest o szkodliwosci 
susbstancji chemicznych i konserwantow zawartych w konserwach na organizm 
czlowieka ;)
Apr 13 23:22:47 <deviant-> tekmar ;>
Apr 13 23:22:50 <liqu|> co kuyrna !
Apr 13 23:22:51 <phantomik> no bana im... co beda nam opinie polepszac ;)
Apr 13 23:22:57 metallo unosi wysoko nad głową zaciskarkę do kabli RJ-45, robi 
groźną minę i mówi: ,,Ja was wszystkich wyfiltruję na firewallu!''
%
#debian.pl
Apr 14 20:12:24 <Eyck> jak banowali *ppp.tpnet.pl to sie nie odzywalem, mnie to 
nei dotyczylo
Apr 14 20:12:30 <Eyck> jak banowali *.tpnet.pl to sie nie odzywalem, mnie to 
nei dotyczylo
Apr 14 20:12:45 <Eyck> jak zabanowali *pl nikt mnie nie bronil, bo nikt nie 
zostal
%
#debian.pl
Apr 15 20:12:53 <DelUser> Jubal: hell.pl to Twoja domena ?
Apr 15 20:14:01 <Jubal> DelUser: w pewnym sensie.
Apr 15 20:14:30 <Jubal> nie, nie ma możliwości założenia konta / delegacji DNS. 
;-)
Apr 15 20:17:30 <DelUser> Jubal: Miło się z Tobą rozmawia :>
Apr 15 20:17:39 <DelUser> Jubal: Akurat konto mnie nie interesuje :>
Apr 15 20:19:34 <Jubal> DelUser: wybacz, odpowiadam automatycznie. ;-)
Apr 15 20:20:11 <wardi> Jubal-> rotfl :P
%
#debian.pl
Apr 15 23:15:18 <deviant-> Piaskowy : hm, a zdarzylo sie zeby ktos kto wyzywal 
jama przy jego obecnosci nie wylecial ?
Apr 15 23:15:33 <deviant-> i nie wylecial ;)
Apr 15 23:15:48 <Piaskowy> deviant-: raz na pewno.
Apr 15 23:15:57 <Piaskowy> deviant-: sam wyszedł.
%
#debian.pl
Apr 16 22:34:52 <Izzunia> co to jest 'nadnocnik' ?
Apr 16 22:35:17 <NadNocnik> Izzunia: to taki Nocnik lepszej kategorii. Co jak 
nadczlowiek.
Apr 16 22:35:31 <Falconne> Izzunia: to taki mniejszy supersedes ;)
%
#debian.pl
Apr 16 23:32:39 <Kusznier> promontel.net.pl
Apr 16 23:33:06 <Kusznier> ip na dns zamienia a odwrotnie nie :)))
Apr 16 23:33:08 <deviant-> hehe
Apr 16 23:33:10 <Kusznier> niezle co ? :)
Apr 16 23:33:25 <met> jest tylko rev?  weird :>
Apr 16 23:33:47 <Kusznier> nio i napisalem im juz z 20 mejli na ten i inne 
tematy
Apr 16 23:34:04 <met> hmm...
Apr 16 23:34:15 <Kusznier> a kolesie tylko dzwonia i odpisuja z pogrozkami ze 
jak jeszcze raz bede sie uslilowal wlamac na router to mi odetna net :>>>>>
Apr 16 23:34:25 <Kusznier> ;]
Apr 16 23:34:29 <met> heheh :D
Apr 16 23:34:29 <Kusznier> okz - cya :)
Apr 16 23:34:37 <met> co ty robiłeś z tym reuterem? :>
Apr 16 23:34:47 <Kusznier> brute force :)))
Apr 16 23:34:47 <deviant-> hehe
Apr 16 23:34:51 <deviant-> gdzie tacy idioci ?:>
Apr 16 23:34:57 <met> LOL ROTFL.
Apr 16 23:35:15 <Kusznier> eh bo mi sie nudzi jak nic nie dziala :>
Apr 16 23:35:19 <Kusznier> kcialem sam naprawic :)
%
#debian.pl
Apr 18 20:04:23 <DarkT> Witam. CZY moze mi ktos podac jakas komende do 
zalozenia kont Shell na Linuxie??
Apr 18 20:04:24 <DarkT> huehue
Apr 18 20:04:29 <DarkT> useradd Shell albo adduser Shell
%
#debian.pl
Apr 18 22:04:14 <De4thMan> z czym sie pije Johnego Wallkera ?
Apr 18 22:04:27 <siaraX> De4thMan: z dziewczyna?
%
#debian.pl
Apr 21 10:41:23 <o_0> printf("Hello Wordl\n");
Apr 21 10:42:52 <LiNiO> printf("Hello Excell\n");
%
#debian.pl
Apr 21 14:52:17 <deviant-> ale sie narobilo kozakow na ircnecie
Apr 21 14:52:29 <deviant-> jakies ziomki mi siostre straszyly ze sdi bedzie 
lapac po pokoju :>
%
#debian.pl
Apr 21 15:03:47 <wardenik> xmodul-> a co robisz?
Apr 21 15:04:09 <xmodul> mysle :)
Apr 21 15:04:16 <wardenik> aa. to nie przeszkadzam :PPPP
%
#debian.pl
Apr 21 18:11:46 <LiNiO> Jeżeli jesteś w tej chwili z kobieta a ona cala drży, 
jej oddech jest przyspieszony, ma wilgotne usta i błyszczące oczy to lepiej 
spierd ...... bo ma MALARIE !!!
%
#debian.pl
Apr 22 16:15:27 <Junior> jezu..... nie wytrzymam dzwoni do mnie Administrator 
jednego z shelli w polsce i prosi zebym skillowal jedna sesje na swoim serwerze 
bo luser zabral mi nicka :)))))))))))))))))))))))))))))))))))))))))))))0
%
#debian.pl
Apr 22 22:52:16 <deviant-> etam, licze na wasze szeroko wypasione kieszenie :>
Apr 22 22:52:23 <Azazelle> och szeroko ;P
Apr 22 22:53:25 tekmar z tej szerokości idzie sobie fajki qpić
%
#debian.pl
Apr 22 22:58:11 <deviant-> gdzie sa moi bohaterowie rocznika 1983 :>
Apr 22 22:58:19 <deviant-> staniemy w szranki ;)
Apr 22 22:58:25 LiNiO jest 1973 ;)
Apr 22 22:58:40 deviant- jest 31337 :>
%
#debian.pl
Apr 23 15:47:20 <metallo> Co to jest pingwin?
Apr 23 15:48:10 <Aqq> metallo: PINGowany WINdows :PP
%
#debian.pl
Apr 23 21:16:33 *** DarkT- (darkt<ph210'legnica}sdi(tpnet{pl) has joined 
#debian.pl
Apr 23 21:16:37 <DarkT-> ahh :)
Apr 23 21:16:42 <DarkT-> dziala :P
Apr 23 21:16:57 <pshem> co ci dziala ?
Apr 23 21:16:59 <pshem> :p
Apr 23 21:17:13 <DarkT-> moje lewe oko ;)
Apr 23 21:17:17 <pshem> glowka mnie boli...
Apr 23 21:17:30 <DarkT-> przez chwile zamknolem i zapomnialem ze zamknolem i 
myslalem ze nie dziala
:P
Apr 23 21:17:53 <pshem> darkt- /etc/init.d/oko force-reload
Apr 23 21:18:08 <pshem> :)
Apr 23 21:18:11 <pshem> zawsze pomaga
%
#debian.pl
Apr 24 12:16:08 <MaReK^-^> co za kraj ma domenke .tr  ?
Apr 24 12:16:17 <eleven> tiuturlistan :)
%
#debian.pl
Apr 24 17:29:06 <Azazelle> kurde. przecinkologia. jak to bedzie poprawnie? :>
Apr 24 17:29:38 <Azazelle> a, interpunkcja.
%
#debian.pl
Apr 25 15:15:37 <met> hmm... nagle mycha mi umarła
Apr 25 15:15:51 <Howks> met: reanimuj ja...
Apr 25 15:16:04 <met> Howks: restart gpma nie pomaga.
Apr 25 15:16:40 <Howks> met: pradem ja pradem :)
Apr 25 15:16:54 <|ufo|> met zalatw sobie jakiegos kota:)
Apr 25 15:16:58 <|ufo|> moze ja pogoni i zadziala;)
Apr 25 15:17:24 <met> hmm... ale to jest naprawdę dziwne ;>
Apr 25 15:17:34 <met> przez 32 dni działała...
Apr 25 15:17:42 <met> JUŻ WIEM! Skończył się okres próbny.
Apr 25 15:17:48 <met> Teraz muszę ją zarejestrować.
%
#debian.pl
Apr 26 14:36:13 <jam_> mam z polibudy kupe kart perforowanych
Apr 26 14:36:24 <jam_> uzywa sie ich tam jako karteczek do pisania na nich 
roznych bzdur
Apr 26 14:37:08 <jam_> niektore sa cale, niektore dziurkowane z fragmentami 
programow
Apr 26 14:37:18 <jam_> :)
Apr 26 14:37:22 <LiNiO> jam_: pisza nakluwajac igla dziurki? ;)
Apr 26 14:38:27 <jam_> LiNiO: niestety, ida na latwize i pisza dlugopisem
%
#debian.pl
Apr 26 18:15:55 <Izzunia> |Aqq| ja jzu wole nie mowic o co mnie posadzaja nan 
uczelni
Apr 26 18:17:06 <|Aqq|> Izzunia: musisz wytlumaczyc, ze jak zabijasz czarne 
koty i pijesz krew to ze wzgledow zdrowotnych :))
%
#debian.pl
Apr 29 23:29:00 <deviant-> chcieli mi wbic, ze durony sa niestabilne
Apr 29 23:29:08 <Kraju> pf :\
Apr 29 23:29:30 <Kraju> odpowiadasz im na to, ze owszem, i nie obsluguja 
rowniez liczb ujemnych =]
%
#debian.pl
Apr 30 09:56:31 <styl> kolesiowi w Kaspowym schowali do prolianta flaszke wodki
Apr 30 09:56:36 <styl> tlukla sie
Apr 30 09:56:48 <styl> i dopiero serwis z krakowa ja wyciagnal i zajebal :)
%
#debian.pl
Apr 30 16:56:21 <PH34R\B0T> hello, I am a friendly t4k30v3r b0t.
Apr 30 16:56:33 <PH34R\B0T> please op me and I'll show you what does t4k30v3r 
mean.
%
#debian.pl
Apr 30 23:25:36 *** |caxo| kicked off from #debian.pl by kostka (banned: join 
flood)
Apr 30 23:25:39 *** |caxo| (~caxo{pa107'sulechow}sdi`tpnet|pl) has joined 
#debian.pl
Apr 30 23:25:41 *** |caxo| kicked off from #debian.pl by kostka (banned: join 
flood)
Apr 30 23:26:01 <wardi> e?
Apr 30 23:26:05 <wardi> what is it?
Apr 30 23:26:14 <wardi> what is happening...
Apr 30 23:26:21 <Kraju> holocaust?
Apr 30 23:26:21 <met> hmm
Apr 30 23:26:29 <met> sesje chcą go zbanować.
Apr 30 23:26:35 <met> ale nie mogą, bo jest +I na *!*@*.p
Apr 30 23:26:45 <met> s/p/pl/
Apr 30 23:26:45 <Kraju> nie, motyw wedrowki w literaturze ;)
%
#debian.pl
Apr 30 23:42:16 <VRANGEL> dziala tu jakis seen ?
Apr 30 23:42:22 <VRANGEL> !seen LiNiO
Apr 30 23:42:28 <VRANGEL> :|
Apr 30 23:43:42 <wardi> ?
Apr 30 23:44:06 <met> kseen linio
Apr 30 23:44:15 <wardi> kseen ?
Apr 30 23:44:20 <kostka> LiNiO (linio)working}for=fbi-gov.be) was last seen 
quitting from #debian.pl 2 hours, 15 minutes ago stating (papatki).
Apr 30 23:44:25 <tekmar> ano kseen ;)
Apr 30 23:44:30 <wardi> hm...
Apr 30 23:44:33 <wardi> co to za wynalazek
Apr 30 23:44:33 <wardi> ;P
Apr 30 23:44:43 <met> bot jest pod KDE, to dlatego. ;)
%
#debian.pl
May 01 11:00:58 <DarkT> voice me or be win98- install`ed :P
May 01 11:01:15 <styl> pipon nam postawi-:- CTCP VERSION reply from _graffi_: 
mIRC v6.01 Khaled Mardam-Bey
%
#debian.pl
May 01 11:16:48 <DarkT> zostaw styla w spokoju :P
May 01 11:16:58 <DarkT> musi pierogi lepic z babcia :P
May 01 11:17:21 <DarkT> kazdy admin dba o swoja babcie ;P
%
#debian.pl
May 02 00:43:37 <met> ,,Czymże jest śmierć?''
May 02 00:43:45 <met> :>
May 02 00:43:45 <siaraX> tym ze nie oddychasz
May 02 00:43:50 <siaraX> nie chodzisz
May 02 00:43:53 <siaraX> nikt z toba nie gada
May 02 00:44:04 <siaraX> ty nawet jak gadasz nikt tego nie slyszy
May 02 00:44:14 <siaraX> rozkladasz sie
May 02 00:44:18 <met> ...i nie mogę ircować...
May 02 00:44:29 <siaraX> well zapewne tez nie
May 02 00:44:30 <siaraX> :)
May 02 00:44:37 <siaraX> ale to nie takie zle
May 02 00:44:44 <siaraX> przynajmniej masz mniejszy rachunek za tele
May 02 00:44:46 <siaraX> :)
%
#debian.pl
May 02 23:25:15 <Falconne> Subject: cmsg newgroup 
alt.binaries.pictures.food.sandwiches
May 02 23:25:17 <Falconne> buahaha
May 02 23:28:38 <met> Falconne: ROTFL
May 02 23:28:51 <Falconne> met: to jeszcze nie wszystko ;)
May 02 23:29:00 <Falconne> Subject: cmsg newgroup 
alt.binaries.pictures.food.soup
May 02 23:29:06 <Falconne> For pictures of a healthy meal!
May 02 23:29:16 <Falconne> Subject: cmsg alt.binaries.pictures.food.salad
May 02 23:29:20 <Falconne> Goes great with alt.binaries.pictures.food.soup and
May 02 23:29:20 <Falconne> alt.binaries.pictures.food.sandwiches!
May 02 23:29:22 <Falconne> :)
May 02 23:29:55 <Falconne> no po prostu kurde grupy dla szwedzkich kucharzy z 
mapetów ;)
%
#debian.pl
May 03 01:56:02 <phantomik> ja mialem lack of space dzis tez...skasowalem 
~/themes i ~/mame/roms i nagle 2GB sie zrobilo ;)
May 03 01:56:02 <wardenik> rotfl :)
May 03 01:56:15 <wardenik> phantomik-> sęk w tym że cały ten dysk ma 2GB
May 03 01:56:16 <wardenik> ;P
May 03 01:56:28 <phantomik> wardenik: no to tez usun rom-y do mame ;>>>
%
#debian.pl
May 03 02:55:09 <Oxydron> to ja sobie poczytam pl.soc.savoir-vivre
May 03 02:55:14 <Oxydron> to jest lepsze nic prhn
May 03 02:55:14 <Oxydron> :>
May 03 02:55:40 <Oxydron> Mam pytanie dotyczace otwierania drzwi kobiecie w 
samochodzie, jest
May 03 02:55:40 <Oxydron> oczywiste ze pomagam przy wsiadaniu i wysiadaniu jak 
prowadze i jest to moj
May 03 02:55:40 <Oxydron> samochod, ale jak nalezy postapic gdy to ONA prowadzi 
samochod czy przed
May 03 02:55:40 <Oxydron> wsiadaniem mam do niej podejsc wziasc kluczyki i 
otworzyc jej drzwi i sobie
May 03 02:55:40 <Oxydron> a potem juz w srodku oddac jej kluczyki ?
May 03 02:55:42 <Oxydron> HUEHUE :)
%
#debian.pl
May 03 15:51:27 <masklin> A wlasnie, kto tu jest bogiem? ;)
May 03 15:51:39 <met> Ja.
May 03 15:51:55 <masklin> ;]
May 03 15:51:57 <_graffi_> Aqq , jam i DOM3L
May 03 15:52:03 <met> i Eyck.
May 03 15:52:09 <masklin> aha.
May 03 15:53:03 <|ufo|> bog jest jeden ale w 3 osobach :P
%
#debian.pl
May 03 21:11:28 <LiNiO> co tam phantomik - jak interes sie kreci? ;)
May 03 21:11:37 <phantomik> zle ;) jak zawsze :)
May 03 21:11:39 <LiNiO> wyprales juz komus mozg? ;)
May 03 21:11:55 <phantomik> no kilku komornikom jak przyszli ;))
May 03 21:12:17 <LiNiO> do mojego brata przychodzili
May 03 21:12:24 <LiNiO> przychodzi goscio
May 03 21:12:37 <LiNiO> i sie pyta czy pracuje - nie
May 03 21:12:47 <LiNiO> czy ma pieniadze zaplacic mandat - nie
May 03 21:12:55 <phantomik> to bierze tv? :>
May 03 21:13:01 <LiNiO> no to zabierze wieze - brat mowi ze brata
May 03 21:13:04 <LiNiO> tv - siostry
May 03 21:13:08 <LiNiO> komputer - siostry
May 03 21:13:16 <LiNiO> dzowni komora do brata
May 03 21:13:27 <LiNiO> tez siostry ;)
May 03 21:13:31 <phantomik> hehe :)))
May 03 21:13:33 <met> ROTFL
May 03 21:13:38 <met> I co zabrał? :)
May 03 21:13:39 <LiNiO> w koncy krzycho zaproponowal pare brudnych skarpetek
May 03 21:13:49 <LiNiO> goscio sie wkurzyl i poszedl
%
#debian.pl
May 04 21:39:10 <LiNiO> nicolas``: sprawdz proces przemiany przelamanego na pol 
mentosa w CO2 - wrzuc do coca-coli ;)
May 04 21:40:03 <mentos> Za co?! ;p
%
#debian.pl
May 04 23:42:46 <nicolas``> mozilla ma dziure !!!!!!!!!
May 04 23:43:53 <salvador> Moja kobieta też.
%
#debian.pl
May 05 17:47:45 <wardi> buheheh
May 05 17:47:48 <wardi> x-y mi sie powiesily
May 05 17:47:48 <wardi> ;P
May 05 17:47:56 <Em3l4itH> wow
May 05 17:47:56 <DarkT> ctrl+del+backspace
May 05 17:47:56 <DarkT> :)
May 05 17:48:06 <DarkT> nie
May 05 17:48:09 <DarkT> ctrl+alt+back
May 05 17:48:10 <DarkT> :)
May 05 17:48:24 <wardi> dzieki
May 05 17:48:25 <wardi> ;P
May 05 17:48:33 <phantomik> ctrl+alt+delete+backspace ;P
%
#debian.pl
May 05 19:29:11 <DarkT> oddam root`a za 3 niewolnice w wieku 15-20 lat ;P
May 05 19:29:34 <_graffi_> ok, dawaj :P
May 05 19:29:53 <met> DarkT: roota gdzie? :)
May 05 19:29:54 <DarkT> hehhe pierw niewolnice ;P
May 05 19:30:06 <DarkT> na 5lo ;P
May 05 19:30:14 <Vac> roota u siebie na laptopie ;>
May 05 19:30:40 <Izzunia> DarkT: hmm nie za mlody jestes na niewolnice?
May 05 19:30:48 <DarkT> hmmm nie :P
May 05 19:31:01 <DarkT> na to sie nie jest nigdy zamlodym ;P
May 05 19:31:09 <Izzunia> hmmm moze zabierzesz sie za ksiazki?
May 05 19:31:15 <DarkT> uczylem sie.
May 05 19:31:19 <_graffi_> :P
May 05 19:31:26 <DarkT> poczeba mi teraz niewolnic; P
May 05 19:31:31 <DarkT> dla moich zachcianek
May 05 19:31:31 <DarkT> ;)
May 05 19:31:46 <Izzunia> heh
May 05 19:31:46 <Vac> a czemu 3-ech ?
May 05 19:31:59 <DarkT> bo jestem zachlanny ;P
May 05 19:32:10 <DarkT> a 4 to juz zaduzo :P
May 05 19:32:17 <_graffi_> starczy ci sil czy zrobiles napad na wiagre ? :>
May 05 19:32:23 <met> ,,Wy dwie, połóżcie mnie na tą trzecią!''
%
#debian.pl
May 05 22:02:42 <ap-ap> moze mo ktos pomc w postawieniu ftpa na debianie moze 
byc pod shelem moze byc pod kde bo mam kde zainstalowane
%
#debian.pl
May 06 07:51:19 <LiNiO> Junior: jak tam po wczorjaszym ataku? ;)
May 06 07:51:23 <Junior> :)
May 06 07:51:30 <Junior> atak odparty
May 06 07:51:51 <MaReK^-^> Junior co cie atakowali ?
May 06 07:54:13 <Izzunia> bry
May 06 07:55:18 <Junior> MaReK^-^ : a ,ktos z jednej firmy mi otworzyl w ciagu 
kilku h 500 000 razy
te sama strone
May 06 07:55:20 <Junior> :)
May 06 07:55:41 <Junior> 500 000 odsloniec
May 06 07:55:43 <MaReK^-^> no niezle
May 06 07:55:47 <Junior> no
May 06 07:55:51 <Erewhon`> Junior: moze mu sie ona podobala :)
May 06 07:55:54 <Junior> az mi lacze ledwo chodzilo
May 06 07:56:26 <Junior> ehehe pewnie tak...ale znalazlem nr na kom do 
wlasciciela lacza i jak Linio zaproponowal jednego sms-a za jedno odsloneicie
May 06 07:56:27 <Junior> :)))))
%
#debian.pl
May 06 12:48:02 eleven jest po lekturze 120 mejli z logami po weekendzie. :3
May 06 12:48:40 <Junior> eleven :)
May 06 12:48:51 Junior juz to przezyl
May 06 12:48:52 <Junior> :)
May 06 12:48:58 <cochese> eleven: o, nie dostajesz ich sms'ami? ;)
May 06 12:49:15 <Junior> boze ,to by mnie przynajmniej zabilo
May 06 12:49:16 <eleven> cochese: tylko, kurna, o tym marze, zeby jeszcze 
smsami logi dostawac.
May 06 12:49:17 <Junior> ":))))
May 06 12:49:28 <eleven> poleconym.
May 06 12:49:29 <Junior> + maile systemowe ze wszystkich serverow
May 06 12:49:30 <Junior> :)
May 06 12:49:35 <eleven> a jak mnie nie ma to awizo zostawiaja.
May 06 12:49:43 <Junior> smierc przyjdzie z sms-em
%
#debian.pl
May 06 13:01:12 <Izzunia> nie wiecie co sie dzieje z icmem?
May 06 13:01:50 <eleven> podobno arabscy zydomurzyni wysadzili w powietrze 
macierz dyskowa.
%
#debian.pl
Jul 18 17:34:39 <Izza> wlasnie skonczylam
Jul 18 17:34:39 <Izza> 51s
Jul 18 17:35:02 <Eyck> sex?
Jul 18 17:35:04 <Eyck> 51s?
Jul 18 17:35:17 <Eyck> to nawet szybciej ode mnie ;)
%
#debian.pl
Aug 09 20:50:52 <met> ,,wiesz co, nie banuj mnie, ja i tak będę spamował'' -- 
|Daymond|
%
#debian.pl
Aug 12 19:12:10 <Qmpeltaty> polowa ludzi tutaj siedzi na windach tylko nie 
wiadomo czego sie wstydza
%
#debian.pl
Aug 15 01:10:26 <blanko> ptanko :P powie mi ktos jak mam doinstalowac i skad 
zdobyc readline i readline-devil ??? mam  1 dzien Debiana P
(devil inside)
%
#debian.pl
Aug 18 22:07:45 <Figatre> cholera znowu telefon
Aug 18 22:07:46 <Figatre> o_0-: hi
(...)
Aug 18 22:10:34 <Figatre> back.
Aug 18 22:10:42 <Figatre> jak jeszcze ktoś zadzwoni to się wkurzę.
Aug 18 22:10:59 <Figatre> (chyba że będzie to atrakcyjna blondynka która 
potrafi gotować)
%
#debian.pl
Aug 19 02:12:34 <m_o_d> mozilla-js-debugger - JavaScript debugger for use with 
Mozilla sciagnołem to i tak mi java nie działa
%
#debian.pl
Aug 19 17:19:25 <Pheagator> uh.
Aug 19 17:19:27 Pheagator się denerwuje.
Aug 19 17:19:48 <Pheagator> cholera mogłem naćpać się arkadią przed wyjściem..
Aug 19 17:19:52 <Pheagator> no nic, lecę.
Aug 19 17:19:58 <Pheagator> papapapa.
%
#debian.pl
Aug 19 20:49:43 <tapsin> jak sie Julia rodzila to tapsowi sie nogi jak z waty 
zrobily
Aug 19 20:49:56 <tapsin> i bal sie co by nie zjechac tam bo ze mnie to kawal 
chlopa jest
Aug 19 20:50:03 <tapsin> i by dopiro bylo
(...)
Aug 19 20:52:59 tapsin jak znajdzie czas to wystawi gdzies pozniej zdjecia 
malej Juli :)))
Aug 19 20:53:10 <Kraju> hehe :)
Aug 19 20:53:12 <deviant> git :>
Aug 19 20:53:32 <tapsin> domenka bedzie julia.wonder.pl :)))
Aug 19 20:53:51 <tapsin> za naszych tego nie bylo
Aug 19 20:53:54 <|Raven|> tapsin: już raz składałem ale zrobię to once again 
^BGRATULACJE^B :-)
Aug 19 20:53:56 <Kraju> dawniej to sie drzewka sadzilo, teraz domenki sie 
zaklada :>
%
#debian.pl
(Cooking-HOWTO by Azazelle...)
Aug 20 23:24:22 <Oxydron> szczypta: wzieta miedzy kciuk i palec wskazujacy 
ilosc sypkiego dodatku
Aug 20 23:24:23 <Oxydron> no
Aug 20 23:24:27 <Oxydron> i to jest porzadka definicja ;>
Aug 20 23:24:35 <Oxydron> a nie jakeis tam  pare lyzek :>
Aug 20 23:24:39 <Azazelle> Oxydron: pisalam to dla goscia, ktory patelnie tylko 
z daleka widzial. :>Aug 20 23:24:46 <Oxydron> :)
Aug 20 23:25:39 <Oxydron> dodane do zakladek:>
Aug 20 23:25:52 <Azazelle> Oxydron: ROTFL. bardzo mi milo. :)
Aug 20 23:26:17 <Oxydron> :))
Aug 20 23:26:23 <Oxydron> od pazdzienika bede sie musial sam zywic
Aug 20 23:26:24 <Oxydron> wiec...
Aug 20 23:26:32 <Oxydron> a kraju to jeszcze wiekszy oferma w kuchni niz ja
Aug 20 23:26:35 <Azazelle> do tego czasu zdaze wiecej napisac takich instrukcji 
:>
Aug 20 23:26:40 <Oxydron> :))
Aug 20 23:26:43 <Oxydron> licze na info :>
Aug 20 23:27:02 <Azazelle> ok. to co, stawiasz flaszke za moja dobroc? :P
Aug 20 23:27:20 <Oxydron> :))  ale zimna:>
Aug 20 23:27:26 <Oxydron> na nastepnym spotkaniu:)
Aug 20 23:27:30 <Azazelle> dopsz. :)
Aug 20 23:27:34 <met> hyhy.  i Azazelle uradowana poszła pisać przepisy z 
backdoorami.  ;D
%
#debian.pl
Aug 22 12:03:12 <m_o_d> no ja mam z tej stronki mplayera
Aug 22 12:03:21 <m_o_d> ale jak go odpalam wali ze nie mam kodeców
Aug 22 12:03:32 <Kraju> no to go rozpakuj.
Aug 22 12:03:40 <Kraju> uruchom mózg i znajdź tam codecs.conf
Aug 22 12:04:02 <m_o_d> Kraju: ale to zbrodnia uruchamiac co kolwiek o tak 
wczesnej godzicnie
Aug 22 12:05:02 <Kraju> zatem pooglądasz filmy dopiero w późnych godzinach 
wieczornych ;)
%
#debian.pl
Aug 22 19:38:52 <rwsr-xr-x> Averne: dostałem właśnie sigsegv przez telefon.
Aug 22 19:39:08 <rwsr-xr-x> idę pogapić się w tv i zatopić smutki w wodzie 
mineralnej.
%
#debian.pl
Aug 22 22:01:42 <AnoniM_MC> Mam takie lamerskie pytanko
Aug 22 22:01:56 <swanky> pytan nie ma lamerskich - sa lamerskie odpowiedzi ;]
%
#debian.pl
Aug 23 21:35:12 <y0shi_> problem
Aug 23 21:35:23 <y0shi_> cos mi sie zawiesilo z klawiatur
Aug 23 21:35:37 <y0shi_> owszem mam teraz pld, ale mam serwer z debianem
Aug 23 21:35:38 <phantomik> y0shi_: hmm...niech zgadnę, używasz pld? ;-)
Aug 23 21:35:45 <y0shi_> i chyba w domu wroce do debiana :/
Aug 23 21:35:49 phantomik jest złośliwy jak zwykle :-)
Aug 23 21:35:56 <phantomik> y0shi_: o! dobry pomysł :-D
Aug 23 21:36:06 <phantomik> tylko jeszcze by trzeba kłoczka do tego namówić.
%
#debian.pl
Aug 25 20:31:54 <rwsr-xr-x> hmm, back ze sklepu.
Aug 25 20:32:16 <rwsr-xr-x> kupiłem: dwa mydła, paczkę czipsów i kabanosa.
Aug 25 20:32:30 <rwsr-xr-x> hm. dziwne zakupy, nie?
Aug 25 20:32:47 <krysa_> wlasnie dlaczego az dwa mydla do kabanosa? ja zagryzam 
jednyum
%
#debian.pl
Aug 26 21:16:35 <Eyck> jak sie w X-ach konfiguruje repeata w klawiaturze?
Aug 26 21:16:49 <LiNiO> xset?
Aug 26 21:17:53 <Eyck> lllliiinnnniiioooo::::     ddddzzziiiiaaałłłłaaaaa
Aug 26 21:17:59 <Eyck> ttttrrrrooooccccchhhheeee     zzzzaaa    
dddoooobbbrrrrzzzzeee   jjjjaaakkkk
   wwwwiiidddzzziiiissszzzz
Aug 26 21:18:13 <Eyck> nnnniiieeee   wwwwwiiieeessszzzzz    www    
jjjaaaakkkkiiiccchhh    jjjjeeeddddnnnoooossssttttkkkkaaaacccchhh    
jjjjeeessssttt    ttteeeennnn     dddeeeeelllaaaayyyy????/   ;;;)))))
%
#debian.pl
Aug 27 00:36:20 <Pheagator> jak cokolwiek zrobić z czerstwego chleba.
Aug 27 00:36:31 <Pheagator> jak zmusić pieprzone dyskietki do działania?
Aug 27 00:36:33 <Azazelle> Pheagator: polac woda i wrzucic do piekarnika na 
piec minut.
Aug 27 00:36:35 <Azazelle> chleb!
Aug 27 00:36:39 <Azazelle> nie dyskietki!
%
#debian.pl
Aug 29 23:34:27 <DarkT> skoro izy nie ma :P to mały kłiz ? :P
Aug 29 23:34:31 *** Izza (iza#prezesowa+gwardii*bmj$net]pl) has joined 
#debian.pl
Aug 29 23:34:31 *** mode #debian.pl "+o Izza" by DOM3L
Aug 29 23:34:31 *** mode #debian.pl "+o Izza" by styl
Aug 29 23:34:32 *** mode #debian.pl "+o Izza" by Junior
Aug 29 23:34:38 <Izza> re
Aug 29 23:34:42 <DarkT> aj niezdazylem :P
%
#debian.pl
Aug 31 13:32:21 <Pieta> jest mzoe gdzies advanced routing howto po polsku ?
Aug 31 13:33:02 <LiNiO> jest
Aug 31 13:33:03 <LiNiO> chyba
Aug 31 13:35:21 <Pieta> LiNiO: jakis bradziej dokladny namiar ?
Aug 31 13:35:22 <LiNiO> Pieta: http://asterix.wonder.pl - kiedys zaczalem opis
Aug 31 13:35:22 <LiNiO> ale nie skonczylem
Aug 31 13:35:22 <LiNiO> a jakies inne - google.com
Aug 31 13:35:41 <Pieta> ddzieki
Aug 31 13:36:00 <Eyck> hmm jak advanced to czemu po polsku?
Aug 31 13:36:18 <Eyck> dla mnie to brzmi jak 'Chirurgia oka dla idiotów'
Aug 31 13:36:39 <Eyck> 'Zoperuj sobie przysadkę mózgową w 12tu łatwych krokach'
%
#debian.pl
Aug 31 17:34:53 <Pheagator> Howks: mam zamglone całe mieszkanie.
Aug 31 17:35:17 <Azazelle> Pheagator cos ty stworzyl? 0_0
Aug 31 17:35:29 <Pheagator> Azazelle: potwora.
Aug 31 17:35:41 <Azazelle> Pheagator: pisalam... maly ogien pod patelnia...
Aug 31 17:35:47 <Pheagator> Azazelle: a raczej nie ja, co moja matka 
zostawiając mi do dyspozycji kuchnie.
Aug 31 17:36:04 <Pheagator> Azazelle: hm. on był... mały..
Aug 31 17:36:06 <Pheagator> chyba.
Aug 31 17:36:15 <Azazelle> Pheagator: a nie pilnowales?
Aug 31 17:36:16 <Pheagator> nie wiem dlaczego zaczęło się jarać.
Aug 31 17:36:21 <Pheagator> Azazelle: ee, grałem w adoma.
Aug 31 17:36:35 Azazelle rzuca garnkiem w Pheagatora.
Aug 31 17:36:54 <Pheagator> (btw wylosował się  dzisiaj Executor mojemu 
trollish healerowi)
Aug 31 17:37:02 <met> executor?
Aug 31 17:37:04 <Azazelle> nie nie nadajesz sie do kuchni, tylko len smierdzacy 
jestes. nad gotowaniem trzeba stac i patrzec, czy sie ladnie robi.
Aug 31 17:37:10 <Azazelle> jaki executor?
Aug 31 17:37:16 <Pheagator> Azazelle: toporek
Aug 31 17:37:22 <Azazelle> aa :>
Aug 31 17:37:23 <Pheagator> Azazelle: artefaktowy.
Aug 31 17:37:31 *** malpis (~malpis@pa144.nowy-tomysl.sdi.tpnet.pl) has joined 
#debian.pl
Aug 31 17:37:34 <Pheagator> Azazelle: ładne obrażenia, i slayer demonów i 
humanoidalnych
Aug 31 17:37:43 <Pheagator> Azazelle: zabiłem nim hotzenplotza jednym ciosem :)
Aug 31 17:38:03 <Azazelle> hotzenplotza to ja jednym $boltem ;)
Aug 31 17:38:17 <Pheagator> (fajny tekst się pojawia - You execute Hotzenplotz 
cośtam cośtam)
Aug 31 17:38:31 <Pheagator> Azazelle: miałem Learning: 4 ;]
Aug 31 17:38:43 <Azazelle> Pheagator: *sigh* ;)
Aug 31 17:38:55 <Pheagator> zabił mnie dorn beast
Aug 31 17:38:57 <malpis> czesc ...oczym mowa ?
Aug 31 17:39:03 <Pheagator> 180HP fajowo spadało do zera.
Aug 31 17:39:12 <Pheagator> hit, paralyzes, hit hit hit hit hit...
Aug 31 17:39:15 <Pheagator> you die.
Aug 31 17:39:30 <Pheagator> malpis: o gotowaniu.
%
#debian.pl
Sep 07 22:18:19 <|lulek|> cze moze mi ktos powiedziec dlaczego przy kompilaci 
mplayera wywala mi  Error: X11 support required for GUI compilation?
Sep 07 22:18:50 <met> |lulek| :: wsparcie dla X11 jest niezbędne do kompilacji 
GUI.  Czego nie rozumiesz?
Sep 07 22:19:30 <|lulek|> met: hmm ale dlaczego to wywala jak ja mam X11 
zainstalowane
Sep 07 22:19:43 <met> |lulek| :: bo brakuje ci develi.
Sep 07 22:20:33 <|lulek|> met: aa spoko zaraz zobacze
Sep 07 22:20:36 <Pheagator> |lulek|: apt-get install szatan-task  -  
zainstaluje wszystkie devile. ;]
%
#debian.pl
Sep 09 17:57:36 <ufo> Ile można funkcjonować bez jedzenia?
Sep 09 17:58:01 <Oxydron> ufo:  jesli bedziesz pil wode to ~14 dni
Sep 09 17:58:17 <ufo> A to spoko, za 7 dni weekend :)
%
#debian.pl
Sep 10 20:28:44 <jam> seeny dzialaja na msgach wiec nie floodujcie kanalu bo 
bede kopal :)
Sep 10 20:28:47 <Buciorek> jam, Osobe o nicku nie 
(Felkon(pq51^wroclaw[sdi%tpnet=pl) ostatnio widziano podczas opuszczania 
#polska 7 tygodni 6 dni 20 godzin 14 minut temu (17.07. 00:14) gdy mowil(a) "".
%
#debian.pl
Sep 13 11:11:15 <adam_> co to rtfm?
Sep 13 11:11:37 <eleven> radical theoretical fechting manual.
Sep 13 11:11:44 <eleven> dla szermierzy.
%
#debian.pl
Sep 13 17:37:27 <bazyl> Oxydron: wmaker prawie wszystko zapewniał... będzie mi 
tylko brakowało wmbubble ;] widziałeś to kiedyś? ;]
Sep 13 17:38:15 <bazyl> Oxydron: masz kwadracik - kontener.. z wodą. po 
powierzchni pływa sobie kaczka.. poziom wody to procent ajętego ramu a stopień 
bąbelkowania wody to procent zajętego procesora ;]
Sep 13 17:38:50 <bazyl> Oxydron: jak włączałem kiedyś OpenOffice'a to mało nie 
zatopiłem i nie ugotowałem tej kaczki ;]
%
#debian.pl
Sep 13 23:29:36 <Pheagator> Kraju: główną zaletą fluxa jest to że na niego się 
prawie w ogóle nie patrzy.
Sep 13 23:29:49 <Pheagator> Kraju: jest tak intuicyjny że nawet nie zauważasz 
że istnieje..
Sep 13 23:29:52 <Pheagator> Kraju: a kde...
Sep 13 23:29:56 <Pheagator> zanim się wgra...
Sep 13 23:30:00 <Pheagator> zanim wysokczy ikonka...
Sep 13 23:30:00 <Kraju> Pheagator: e, desktop jest po to aby na niego patrzec.
Sep 13 23:30:05 <Kraju> Pheagator: e? zyjecie jakimis mitami
Sep 13 23:30:14 <Kraju> Pheagator: KDE mi sie wczytuje w przeciagu paru sekund.
Sep 13 23:30:17 <phantomik> Pheagator: kfde też nie zauważasz - nigdy nie 
doczekasz aż się uruchomi
do końca ;-)
%
#debian.pl
Sep 14 21:05:54 <met> hmm.  właśnie chciałem spauzować film w telewizji 
spacją...
Sep 14 21:06:10 <kle-kot> To jest juz choroba :)
Sep 14 21:06:26 <met> za dużo mplayera. :}
Sep 14 21:06:42 <met> znaczy - nie w telewizji, tylko w xawtv ;)
Sep 14 21:07:43 <phantomik> e moja Dziewczyna po kilku godzinach grania w age 
of empire2 chciała przy oglądaniu meczu w tv, kolesi zaznaczyć i kazać im biec 
w innym kierunku ;-)
Sep 14 21:07:48 <phantomik> i to jest dopiero chore ;-)
%
#debian.pl
Sep 19 20:56:59 <Maveric> kto chce kupic stremer hp 35480A "surestore 5000i" z 
kompresja 4 giga po bardzo niskjiej cenie
Sep 19 20:58:02 <jam_> Maveric: do 3 pln moge wziasc (drozej to nie, bo mi nie 
potrzebny, ale streamer za 3 pln to czemu nie przepuscic takiej okazji :)
%
#debian.pl
Sep 23 20:50:08 <jam_> speedo: te skrypty zawieraja wszystko co potrzeba 
niezaleznie od innych ustawien w /etc/ppp
Sep 23 20:50:45 <speedo> hmm czyli jak nazwac te pliki i gdzie je wkleic ?
Sep 23 20:51:02 <jam_> speedo: pomysl
Sep 23 20:51:31 <speedo> zylka mi peknie jak za duzo myslal bede :P
Sep 23 20:51:41 <jam_> speedo: moze powinna?
Sep 23 20:51:53 <jam_> speedo: moze to cos jak cnota? raz peknie a potem mozna 
do woli uzywac ?
%
#debian.pl
Sep 24 11:26:57 <siaraX> Pheagator: tam nic mi nie bedzie zagladac w dupe czy 
uzywam licencjonowanego papieru toaletowego
Sep 24 11:26:57 <siaraX> :P
Sep 24 11:27:27 <Pheagator> heh.
Sep 24 11:27:44 <Pheagator> siaraX: skąd ta pewność?
Sep 24 11:27:44 <Pheagator> siaraX: słyszałem że MS wchodzi na rynek papierów 
toaletowych..
Sep 24 11:27:44 <Pheagator> siaraX: zdaje się po tym jak ktoś im powiedział że 
wszystko co robią jest do dupy..
%
#debian.pl
Sep 24 16:11:11 <rwsr-xr-x> ... a może by tak... zrobić sobie dzień dziecka..
Sep 24 16:11:19 <rwsr-xr-x> i zamówić pizzę...
Sep 24 16:11:22 <rwsr-xr-x> albo gyrosa...
Sep 24 16:11:26 <rwsr-xr-x> :)~
Sep 24 16:11:30 <Izza> i possac mleko z piersi?
Sep 24 16:12:06 <rwsr-xr-x> hmm, no mleko nie jest niezbędne..
Sep 24 16:16:07 <rwsr-xr-x> ale o tyle o ile żarcie mogę sobie załatwić we 
wmiarę rozsądnej cenie przez telefon to cycków już nie :/
%
#debian.pl
Sep 27 23:50:51 <speedo> jam i co ?????????
Sep 27 23:50:58 <speedo> i co my teraz zrobimy ??????????
Sep 27 23:51:48 <jam> speedo: my ? mi wszystko dziala, to ty masz problem :P
%
#debian.pl
Sep 29 17:59:59 <speedo> lulek sproboj sie polaczyc na 10.0.0.30 please
Sep 29 18:00:02 <speedo> albo met
Sep 29 18:00:06 <speedo> sprobojcie
Sep 29 18:00:08 <speedo> please
%
#debian.pl
Oct 01 00:15:51 <Selektor> jeszcze troche i powroce do rh
Oct 01 00:16:23 <Pieta> Selektor: zgin przepadnij w gowno wpadnij! nie waz sie 
powtorzyc tu tej nazwy!
%
#debian.pl
Oct 03 21:48:59 <Unc> [Selektor(koks>shell(arx#pl)] ale ulatwil bys mi troche 
sprawe jak bys mi powiedzial co to to RTFM
%
#debian.pl
Oct 13 23:23:56 <deviant> Izza: pamietasz tamto zadanie, co na polski mi 
pisalas ?:>
Oct 13 23:23:57 <Izza> aha
Oct 13 23:24:04 <Izza> hmmm
Oct 13 23:24:07 <Izza> chyba tak
Oct 13 23:24:15 <Izza> dostales pozytywna ocene?
Oct 13 23:24:15 <deviant> wtedy 4 dostalem :>
Oct 13 23:24:21 <Izza> wow
Oct 13 23:24:40 <deviant> no, od tamtej pory kobita na mnie zaczela inaczej 
patrzec i dostalem jeszcze 5 ze sprawdzianu :>
Oct 13 23:25:21 <Izza> :)))))))))))))))
Oct 13 23:25:50 <Zakus> Izza: a napiszesz za mnie prace inzynierska? ;)
%
#debian.pl
Oct 16 00:00:23 *** Smarq (ask|pr73}bydgoszcz%sdi{tpnet,pl) has joined 
#debian.pl
Oct 16 00:00:30 <Smarq> cz
Oct 16 00:00:56 <Smarq> kto zyw niechaj pierwszy rzuci kamieniem
Oct 16 00:01:01 <Smarq> [wiem, to nie tak bylo[
Oct 16 00:01:02 <Smarq> ;]
Oct 16 00:01:17 *** Smarq (ask,pr73-bydgoszcz}sdi-tpnet(pl) has left #debian.pl 
(Smarq)
%
#debian.pl
Oct 19 00:18:19 <jk____> skad mozna zassac dzialajace paczki gnome2
Oct 19 00:18:25 <jk____> ?
Oct 19 00:18:34 <met> a temu jeszcze nie przeszło?
Oct 19 00:18:42 <met> ;)
Oct 19 00:18:49 <jk____> met dlaej nie mam gnoma ;(
Oct 19 00:19:02 <jk____> normalnie chialem slacka instalnac ;)
Oct 19 00:19:09 <met> to instaluj. ;p
Oct 19 00:19:12 <jk____> dobrze ze sie powstrzymalem
Oct 19 00:19:21 <jk____> dawac mi tu gnome 2!
Oct 19 00:19:23 <jk____> :)
Oct 19 00:19:26 <o_0> Now playing: Clint Mansell/Kronos Quartet - Winter - 
Overture
Oct 19 00:19:34 <met> jk____ :: myślę że powinieneś zainstalować slacka.
Oct 19 00:19:49 <o_0> jk____: chociaz lepiej PLD
Oct 19 00:19:51 <met> jk____ :: wtedy będziesz zawracać dupę ludziom na 
#slackware.pl a nie nam :D
%
#debian.pl
Oct 21 21:56:51 <pi0tr> Izza jestes ?
Oct 21 21:56:51 <Izza> taa
Oct 21 21:56:51 <pi0tr> Izza a jednak sie do mnie odzywasz uffff
Oct 21 21:56:51 <pi0tr> :)
Oct 21 21:56:51 <Izza> a co mam cię zabić za to, że zachowujesz się jak 
niedorozwinięty onanista?
%
#debian.pl
Oct 24 21:51:58 <|Pablo|> jak tam SDI, podobno TPSA teraz wszystkich SDIowców 
przekabaca na neostrade
Oct 24 21:52:03 <|Pablo|> ??
Oct 24 21:52:07 <Falconne> mnie nie przekabacali
Oct 24 21:52:10 <Falconne> nawetn ie próbowali
Oct 24 21:52:16 <Falconne> w czerwcu mi piorun trafił
Oct 24 21:52:23 <Falconne> to na drugi dzien miałem nowy terminal
Oct 24 21:52:33 <Falconne> ale uszkodzenia na linii to przez połtora miesiąca 
nie mogli znaleść
Oct 24 21:52:37 <Falconne> i miałem transfery do bani
Oct 24 21:53:02 <Falconne> ale wymienili mi wszystkie klasy kabli, chyba pół 
skrzynki na ulicy i jeszcze cośtam
Oct 24 21:53:15 <Falconne> mówiłem im, że SDI nie da się zabezpieczyć moim UPSem
Oct 24 21:53:26 <Falconne> i niech mi dadzą zabezpieczenie to je założe
Oct 24 21:53:36 <|Pablo|> Telekompromitacja polska....
Oct 24 21:53:44 <Falconne> ktoś w BOKu mi powiedział, żebym na czas burzy 
wyłączał sdi i komputer
Oct 24 21:53:53 <Falconne> powiedziałem, żeby mi mówili, kiedy będzie burza
Oct 24 21:54:02 <|Pablo|> ROTFL
Oct 24 21:54:06 <o_0> buahahaha
Oct 24 21:54:06 <o_0> ';D
Oct 24 21:54:07 <Falconne> bo gdy mi zjarało SDI to była o 8 rano - spałem wtedy
%
#debian.pl
Oct 27 13:20:18 <ike> Kazdy ma jakiegos nicka
Oct 27 13:20:18 <ike> kazdy jakies skrypty ma
Oct 27 13:20:18 <ike> a ja w domu mam epica
Oct 27 13:20:18 <ike> bitcha, boty oraz tpsa
%
#debian.pl
Nov 13 00:28:38 <Coenn> dpkg-reconfigure exim
Nov 13 00:28:45 <Coenn> dlaczego nic sie nie dzieje ?
Nov 13 00:28:55 <deviant> Coenn: dlatego ze nikt nie wrzucil monety?
%
#debian.pl
Nov 13 23:55:47 <afro^> odpalilem jakiegos smiesznego programa Ksirc
Nov 13 23:56:16 <met> a nie lepiej kvirc? ;)
Nov 13 23:56:17 <afro^> sluchajcie jedna rzecz mnie zdziwla czemu nie moge 
ircowac bedac rootem
Nov 13 23:56:54 <afro^> moze i lepiej ale odpalilem pierwszego lepszego ktory 
wpadl mi w dlonie
Nov 13 23:57:09 <afro^> dlaczego nie moge sie zalogoac jako root?
Nov 13 23:57:09 <met> huh, "jestem pod windowsem bo pod linem BitchX mufi mi 
zebym nie ircowal jako
root"
Nov 13 23:57:22 <afro^> haa
Nov 13 23:57:36 <Zakus> met: bueheheh :PPPPPP
Nov 13 23:57:41 <afro^> met: ja tak samo mam, wiec siedze jako user
%
#debian.pl
Nov 17 03:55:13 <sat0r> e-e znasz ajkis najlepszy server ftp cobym mogl go 
dopsiac na stale do apt ?Nov 17 03:55:34 <AnoniM_MC> proftpd? ale chyba w 
debach nie ma
%
#debian.pl
Nov 21 23:36:56 <o_0> zachodzą mi włosy na uszy i wyglądam jak stary citroen
%
#debian.pl
Nov 27 17:40:13 <Junior> kto programuje w Perl-u ?
Nov 27 17:41:05 <speedo> Junior a co szukasz korepetytora dla córki ?
%
#debian.pl
Nov 27 20:51:41 <mutifo> jak sie cos skasuje to ginie ? czy jest jakis koszyk 
or sth ?
Nov 27 20:51:48 <mutifo> w linuxie
%
#debian.pl
Nov 28 21:27:00 <Daymond> _phantom_: zły jestem, z moim dziewczem się 
pokłuciłem.
Nov 28 21:27:34 <_phantom_> ajć...
Nov 28 21:27:39 <Izza> hmmm
Nov 28 21:27:41 <_phantom_> to czymprędzej po kwiaty i przepraszać!
Nov 28 21:27:43 <Izza> not good
Nov 28 21:28:02 <ike^> Serenade pod oknem zaspiewaj.
Nov 28 21:28:04 <ike^> Zawsze dziala.
Nov 28 21:29:05 <Izza> albo kup jej jakies mile zwierzatko - moze ma na nie 
uczulenie:)
%
#debian.pl
Dec 02 02:24:44 <openface> ladne kobiety trzeba beckupowac zeby w razie czego 
byly znowu :)
%
#debian.pl
Dec 02 03:02:41 <Warden> pogięło mi dziewczynę...
Dec 02 03:02:45 <Warden> krótkie mi puszcza o 3 w nocy
Dec 02 03:02:54 <pi0tr> Warden heheh skad ja to znam :P
Dec 02 03:02:58 <Warden> heheh
Dec 02 03:02:59 <Warden> :]
Dec 02 03:03:02 <N3T> Warden moja tez
Dec 02 03:03:09 <Warden> ej no to jakaś plaga?
Dec 02 03:03:09 <pi0tr> to podobno znaczy ze kocha
Dec 02 03:03:09 <Warden> :)
Dec 02 03:03:10 <N3T> moze to jaki wirus
Dec 02 03:03:11 <N3T> :.
Dec 02 03:03:12 <pi0tr> jak przestanie pusczac
Dec 02 03:03:19 <pi0tr> to znaczy ze sie puszcza z innym :))))
%
#debian.pl
Dec 24 22:00:41 <speedo> a po co moduly kompilowac ??
Dec 24 22:01:24 <Warden> czasem się przydają.
Dec 24 22:01:25 <speedo> nie lepiej modprobe ???
%
#debian.pl
Dec 25 00:01:29 <Ave`> sroda... to muj ulubiony miesiac..
Dec 25 00:01:55 <|Cthulhu|> Ave`: glupi jestes, sroda to nie miesiac - to pora 
roku
%
#debian.pl
Dec 25 12:55:49 <Urug> Kutulu winXp nie jest taki zly
Dec 25 12:55:53 <Urug> nie trzeba jadra kompilowac
%
#debian.pl
Dec 25 16:34:49 <Warden> co robi @ przed costam_z_php ?
Dec 25 16:34:54 <Warden> np @file_exists
Dec 25 16:35:08 <no-one> Warden tesz chcem wiedziec
Dec 25 16:35:13 <no-one> bo mam takie cos w sambie
Dec 25 16:35:26 <Warden> no-one-> a co ma piernik do wiatrata?
Dec 25 16:35:50 <no-one> no mam wirteln @staff i nie wiem
Dec 25 16:36:00 <no-one> co oznacza ta malpa przed staff
Dec 25 16:36:05 <Warden> no-one-> to poczytaj dokumentację.
Dec 25 16:36:08 <Warden> ja pytam o PHP.
Dec 25 16:36:09 <no-one> to ma piernik do wiatraka
Dec 25 16:36:10 <Warden> a nie o sambę.
%
#debian.pl
Dec 29 21:02:03 <AnoniM^> [21:00] <scaner_> debian jest dla lam :.
Dec 29 21:02:04 <AnoniM^> [21:00] <scaner_> problem wpisac apt-get install ssh
Dec 29 21:02:05 <AnoniM^> [21:00] <scaner_> apt-get install proftpd
Dec 29 21:02:15 <pi0tr_> ;]]]]]]]
Dec 29 21:02:24 <AnoniM^> co?
Dec 29 21:02:33 <pi0tr_> mandrake jest za to dla profesjonaliztofff
Dec 29 21:03:10 <_phantom_> ja tam się zgodzę.
Dec 29 21:03:17 <_phantom_> debiana nawet i lama mogła by zainstalować.
Dec 29 21:03:24 <AnoniM^> _phantom_ no
Dec 29 21:03:29 <_phantom_> gdyby ją tylko nauczyć pisać na klawiaturze tymi 
kopytami.
%
#debian.pl
Jan 03 18:21:17 <\n> kazdy moze ircowac z roota ;]
Jan 03 18:22:03 <cochese> wlasnie. ale nie kazdy moze ze 127.0.0.1
Jan 03 18:22:20 <cochese> (Borys is borys@127.0.0.1)
Jan 03 18:23:05 <\n> odezwe sie, zapytam czy bym ja tez tak nie mogl.
Jan 03 18:23:12 <AnoniM|AW> hehehehe
Jan 03 18:23:22 <cochese> jak chcesz miec k:linie ... :)
Jan 03 18:23:26 <AnoniM|AW> oo
Jan 03 18:23:38 <AnoniM|AW> ja tez sie zapytam, lubie ircopof denerfowac
Jan 03 18:24:05 <AnoniM|AW> ./msg borys czesc, mozesz mi dac konto abym mogl 
ircowac ze 127.0.0.1;]
Jan 03 18:24:57 <\n> tja, zaraz widziemy AnoniM leaves [k-lined] ;]
Jan 03 18:26:37 <AnoniM|AW> kto tam jeszcze jest ircopem oprosz beetha i 
bvorysa?
(...)
Jan 03 18:33:51 *** SignOff: AnoniM|AW (shvme57+ipanowicz)sdl}zwami{pl) Kill 
line active: flood (expires@03/12/29)
%
#debian.pl
Jan 04 13:55:49 <BuM> iptables v1.2.7a: can't initialize iptables table `NAT': 
Table does not exist
(do you need to insmod?)
Jan 04 13:55:49 <BuM> Perhaps iptables or your kernel needs to be upgraded.
Jan 04 13:55:49 <BuM> modprobe: Can't locate module ip_tables
Jan 04 13:56:05 <BuM> co mam zaznaczyc w kernelu ???
Jan 04 13:56:07 <Warden> BuM-> case-sensitive.
Jan 04 13:59:42 <BuM> Warden a gdzie to moge znalez
%
#debian.pl
Jan 12 21:35:12 <CeT|Qje> jak sie nazywala komenda basha do wydobycia kawalka 
tekstu z linii ?
Jan 12 21:35:41 <CeT|Qje> mam jakis tekst oddzielony spacjami
Jan 12 21:36:14 <CeT|Qje> i chce slowo "tekst" z tego wziasc :)
Jan 12 21:36:48 <`o`> nie lepiej od razu napisac 'tekst' ?
Jan 12 21:37:06 <CeT|Qje> heh :P
Jan 12 21:38:08 <`o`> chcesz sprawdzic czy w linijce jest "tekst" ?
Jan 12 21:38:25 <CeT|Qje> nie, chce go z niej wydobyc :)
Jan 12 21:38:29 <CeT|Qje> sprawdzic to kazdy umie :)
Jan 12 21:38:38 <CeT|Qje> kurde
Jan 12 21:38:47 <CeT|Qje> kiedys tego uzywalem, i zapomnialem juz...
Jan 12 21:38:47 <CeT|Qje> :/
Jan 12 21:38:51 <`o`> skoro wiesdz, ze to ma byc tekst to po co go wydobywac ?:P
%
#debian.pl
Jan 18 22:16:06 <LiNiO> znowu mariolce groza
Jan 18 22:16:09 <LiNiO> <Mariolk23> Astamania: po cie znajde i zabije
Jan 18 22:16:11 <LiNiO> <Mariolk23> -> Astamania: no cos w tym jest...
Jan 18 22:16:45 <LiNiO> <Mariolk23>   Astamania: you are ignored: nie rozmawiam 
z ulomnymi ludzmi
Jan 18 22:18:55 <ike^> LiNiO : ile Mariolka ma... hm... kodu?
Jan 18 22:19:43 <taps> ike^ jak to ile 19 jak kazda :)))
Jan 18 22:19:45 <LiNiO> niewiele
Jan 18 22:20:02 <LiNiO> 1077 linii
Jan 18 22:21:30 <ufo|niema> Howks byc??
Jan 18 22:22:05 <LiNiO> mam juz obrobione 20% logow
Jan 18 22:22:22 <LiNiO> 2000 nickow
Jan 18 22:22:55 <Izza> LiNiO: straszne...
Jan 18 22:23:13 <Izza> jeszcze troszke, a caly ircnet zaliczy Mariolke:)
(Mariolk23 to talkbot)
%
#debian.pl
Jan 19 12:27:18 <Junior> bhbnjhjh']
Jan 19 12:27:40 <Junior> no tak mojej zonie odbijas
Jan 19 12:27:41 <Junior> ;-)
Jan 19 12:27:56 <Junior> jakies mi tu znaczki pisze i szuka dymu
Jan 19 12:27:57 <Junior> ;-)
Jan 19 12:28:15 <Junior> cholera łańcuch sie poluźnił i z kuchni uciekła
%
#debian.pl
Jan 21 19:44:50 <viruus> pomozcie ?
Jan 21 19:44:53 <viruus> postawic ipv6?
Jan 21 19:44:59 <viruus> ja sobie nie poradze mam 15 lat
%
#debian.pl
Feb 01 17:05:56 <fofon> m_o_d: wogóle się nie odpala ?
Feb 01 17:05:58 *** fofon kicked off from #debian.pl by Buciorek (robisz błędy! 
prawidłowa pisownia: w ogóle)
(...)
Feb 01 17:11:39 <`fazi`> ja proponuję zrobić skupisko ludzi, mówišcych poprawnš 
polszczyzš, precz z
trendami z zachodu.
Feb 01 17:11:39 *** `fazi` kicked off from #debian.pl by met (Polskie litery w 
standardzie Windows-1250 są ^Bzłe^B.)
%
#debian.pl
Feb 06 17:02:52 <PC-helka> to co z tymi parametrami??
Feb 06 17:03:00 <e-bazyl> PC-helka: rtfm
Feb 06 17:03:31 <PC-helka> e-bazyl: a co to oznacza??
Feb 06 17:03:42 <e-bazyl> READ THE FUCKING MANUAL!
%
#debian.pl
Feb 07 17:45:23 <PC-helka> __phantom: a ja jestem uparty i musze ta 
zainstalowac (VIA VT6101
Feb 07 17:45:52 <_phantom_> tego no, ja mam bardzo niedobre zdanie o 
czymkolwiek co ma w nazwie VIA
;->
Feb 07 17:46:21 <LiNiO> _phantom_: nie lubisz VIAGRY? ;)
%
#debian.pl
Feb 08 13:32:58 viz kupił sobie Johnnie Walker. :D
Feb 08 13:33:16 imoteph_ nie kupuje - zyje w opensource :P
Feb 08 13:33:26 <viz> imoteph_: to daj mi flaszke gratis. ;]
%
#debian.pl
Feb 10 18:55:34 <no-one> dynamiczne ip co to ;]
Feb 10 18:55:39 <no-one> zwykle ip ?
Feb 10 18:55:40 <no-one> hm
Feb 10 18:55:44 <no-one> szybsze jakies ?
%
#debian.pl
Feb 15 20:59:00 <CeReBrOs> Czy w debianie usuwa sie taj jak w winie pliki typu 
temporary internet files??
%
#debian.pl
Feb 16 01:16:45 <^_-> ike :: popsulem
Feb 16 01:16:48 <^_-> spaliłem kurde ;/
Feb 16 01:16:57 <ike> Dobry psuj.
Feb 16 01:17:11 <^_-> :D
Feb 16 01:17:16 <^_-> *wof* *wof*
Feb 16 01:17:23 ike gratuluje daszkowipodkreśleniowimyślnikowi.
%
#debian.pl
Feb 16 02:49:20 fEnIo is back (gone 05:02:19)
Feb 16 02:49:45 <speedo> fEnIo po co wracasz tak pozno :>
Feb 16 02:50:02 <speedo> czyzbys zapomnial swiatla na sesji zgasic ?
%
#debian.pl
Feb 17 16:40:34 *** gall (gall*lew$netgate;com&pl) has joined #debian.pl
Feb 17 16:40:54 <gall> jak instaluje screen
Feb 17 16:40:56 <gall> z polecenia
Feb 17 16:41:01 <gall> dpkg -i nazwa
Feb 17 16:41:03 <gall> all dziala
Feb 17 16:41:05 <^_-> man apt-get
Feb 17 16:41:06 <gall> ale np
Feb 17 16:41:12 <gall> mc
Feb 17 16:41:21 <gall> i pare innych nie dzialaja
Feb 17 16:41:49 <Zakus> gall: bo maja dependencies
Feb 17 16:41:49 <|Raven|> gall: bo nie instaluja sie zaleznosci, instaluj 
apt-get -em jak Ci radzi ^_- :P
Feb 17 16:42:27 <gall> apt-get -em nazwa_pliki ?
Feb 17 16:42:44 <|Raven|> gall: rtfm.
Feb 17 16:42:53 <Zakus> gall: apt-get install nazwa_pakietu (bez .deb)
Feb 17 16:42:55 <Izza> gall: apt-get install nazwa_paczki
Feb 17 16:43:07 <Izza> gall: a jak nie wiesz jaka paczka to:
Feb 17 16:43:17 <Izza> apt-cache search nazwa_podjerzana
Feb 17 16:44:17 <gall> Alw koncu
Feb 17 16:44:28 <gall> apt-get ma byc z -em czy install ?
%
#debian.pl
Feb 19 02:12:42 <[ViRuS]> co powiecie na too ze sciagnolem rewriiter pod dos
Feb 19 02:12:47 <[ViRuS]> ale odpalil sie pod winda
Feb 19 02:12:56 <[ViRuS]> dalem mu sierzke do resue.bin
Feb 19 02:13:08 <[ViRuS]> potem dalemm zeby wysylal na a:
Feb 19 02:13:20 <[ViRuS]> on porobil przeszy takie ladne rameczki 2
Feb 19 02:13:34 <[ViRuS]> whodze w folobby a tam 2razy *.zip
Feb 19 02:14:08 <[ViRuS]> i chyba z 20 razy *.txt i dziwne nazwy np f1 f1 f12
Feb 19 02:16:40 <Howks> [ViRuS]: a czy te dziwne nazwy nie ukladaja sie 
przypadkiem w kolejnosc klawiszy funkcyjnych f1-f12 ?
Feb 19 02:17:54 <[ViRuS]> Howks a z czego to sie ma odpalic ??
Feb 19 02:18:13 <[ViRuS]> czy widziales dyskietke ktora sie bootuje z pliku 
*.zip albo *.txt ?
Feb 19 02:19:12 <Howks> hmmm tak.
Feb 19 02:19:54 <Howks> [ViRuS]: ten nick pasuje do ciebie :))))
Feb 19 02:20:07 <Howks> zero pozytku a bardzo upierdliwy :PPP
%
#debian.pl
Feb 24 22:47:09 *** linshi is now known as LiNsHi
Feb 24 22:47:09 *** LiNsHi kicked off from #debian.pl by \` (^BNiq flood (3 
nicks in -2131secs of 30secs)^B)
%
#debian.pl
(nigdy nie ucz się polskiego do matury ponad dobę bez przerwy)
Feb 25 00:37:05 <\`> dobranoc
Feb 25 00:37:07 <\`> słowacki na noc
Feb 25 00:37:13 <met> \` :: dobra twoja noc
Feb 25 00:37:13 <\`> ballady pod poduchy
Feb 25 00:37:19 <\`> bo kraśiński suchy
Feb 25 00:37:53 <masklin> Dobranoc \` ;)
Feb 25 00:38:50 <\`> dobranoc meskalina
Feb 25 00:38:55 <\`> walnij w dziub pingwina
Feb 25 00:38:58 <\`> bo wlasnie sie zaczyna
Feb 25 00:39:05 <\`> krakowska dolina
Feb 25 00:39:05 <\`> :o
Feb 25 00:39:18 <met> oto człowiek chory.
Feb 25 00:39:21 <\`> ;p
Feb 25 00:39:31 <\`> "D
Feb 25 00:39:42 <\`> jak mawiał Słowacki jedz kefir i placki
%
#debian.pl
Feb 27 00:48:59 <Ave`> zna ktos jakies zewnetrzne vpn` ktore same benda sie 
podnosily po twardym restarcie ? :)
Feb 27 00:49:23 <B0rG_> ja wczoraj poznalem, stal przy wejsciu do metra 
centrum...
Feb 27 00:49:25 <B0rG_> ;>
Feb 27 00:51:56 <Warden> Ave`:: vpnd ?
Feb 27 00:52:04 <Warden> co to znaczy zewnętrzne ?
Feb 27 00:52:16 <Howks> Warden: na zewnatrz pewnie :)
Feb 27 00:52:18 <Ave`> Warden: oddzielne pudeleczko :)
Feb 27 00:52:57 <Ave`> Warden: taki maly routerek z vpn`em
Feb 27 00:52:58 <tekmar> Warden nie w srodku ;)
Feb 27 00:53:05 <Ave`> ;)
Feb 27 00:53:41 <Ave`> tekmar: w srodku, tyle ze nie na zewnarz. ;P
Feb 27 00:53:48 <tekmar> czyli obok ?
Feb 27 00:54:00 <Ave`> tekmar: ew nad lub pod.
%
#debian.pl
Mar 01 18:12:21 <JaBBaS> zrobcie mi stery nvidii kurwa dzialajace
Mar 01 18:12:22 *** JaBBaS kicked off from #debian.pl by Buciorek (nie klnij!)
Mar 01 18:12:22 *** JaBBaS (-jabbas@red-pradnik.ekrakow.pl) has joined 
#debian.pl
Mar 01 18:12:22 *** JaBBaS kicked off from #debian.pl by taps (^BBitchX BWK^B:  
kurwa)
Mar 01 18:12:23 *** JaBBaS (-jabbas@red-pradnik.ekrakow.pl) has joined 
#debian.pl
Mar 01 18:12:23 *** JaBBaS kicked off from #debian.pl by met (dziewica 
orleańska)
%
#debian.pl
Mar 07 22:17:31 <darkan> jest moze jakis klient grup dyskusyjnych pod konsole ??
Mar 07 22:20:12 <Pheagator> darkan: wiele.
Mar 07 22:22:23 <Pheagator> darkan: osobiście polecam slrn.
Mar 07 22:23:25 <darkan> Pheagator dzieki zobaczy czy jest spox
Mar 07 22:28:35 <darkan> Pheagator co jak ja mam wpisac ten serwer w .slrnrc
Mar 07 22:28:46 <darkan> ??
Mar 07 22:29:10 <Pheagator> darkan: RTFM.
Mar 07 22:30:36 <darkan> Pheagator mam wpisac RTFM=news.tpi.pl ??
%
#debian.pl
Mar 11 17:08:58 <whiller> jezeli zainstaluje pakiety gnome-core,gdm to juz 
wystarczy abu uruchomic go ?
Mar 11 17:09:12 <whiller> nie bede musial sciagac x-window-system ?
%
#debian.pl
Mar 20 12:27:20 <xtrance> mam pytanko wiecie moze jaki modul lub co moze byc 
odopwiedzialne za ostrsc czcionek. bo zmienilem jajko i pewnie nie mam jakiegos 
modulu i czcionki mam nieostre w xwindow
%
#debian.pl
Mar 21 00:22:26 <pshem> jakie klony sa najszybsze ?
Mar 21 00:26:10 <Kraju> owieczka dolly. innych nie znam.
Mar 21 00:26:16 <Kraju> ale chorowała ciągle i chyba ją uśpili.
%
#debian.pl
Mar 24 18:03:30 <G3r4lt> met: czytałeś?
Mar 24 18:03:48 <met> G3r4lt :: że masz 2048bitowy klucz? tak
Mar 24 18:04:44 <CeT|QJE> G3r4lt: po co ci 2048 bitowy klucz ? :D
Mar 24 18:04:49 <CeT|QJE> nie lepiej 1024 ?
%
#debian.pl
Apr 05 14:49:51 <vaiker> Apr  5 06:22:31 piwnica oidentd[2963]: Connection from 
august.V-LO.krakow.pl (62.121.131.17):41835
Apr 05 14:49:53 <vaiker> Apr  5 06:22:31 piwnica oidentd[2963]: 
[august.V-LO.krakow.pl] Successful lookup: 33699 , 80 : root (root)
Apr 05 14:49:56 <vaiker> koles zdobyl roota
Apr 05 14:50:05 <vaiker> jest jakas dziura w oidencie ?
%
#debian.pl
Apr 06 16:41:00 <Lukaz> unresolved symbols in 
/lib/modules/2.4.18-bf2.4/kernel/drivers/video/NVdriver
Apr 06 16:41:12 <Lukaz> wie ktos jak mam sie z tym uporac ?
Apr 06 16:41:55 <_phantom_> Lukaz: kupić inną kartę graficzną. (lub 
przekompilować ten moduł)
Apr 06 16:42:07 <Lukaz> a jak to moge zrobic ?
Apr 06 16:42:47 <_phantom_> hmm... no coż, iść do sklepu i poprosić jakiegoś 
Ati Radeon-a 9000 chociażby.
Apr 06 16:42:50 <_phantom_> ;->
Apr 06 16:42:57 <Lukaz> e.. tzn przekompilowac
Apr 06 16:43:02 <Zakus> ;]
Apr 06 16:43:05 <Lukaz> bo na nowa karte mnie raczej nie stac :)
%
#debian.pl
Apr 08 15:11:00 Pheagator pozdrawia wszystkich zgromadzonych prastarym 
pozdrowieniem chomików.
%
#debian.pl
Apr 09 18:44:06 <Krecik__> pojebany ten linux
Apr 09 18:44:24 <_phantom_> Krecik__ :: sam jesteś poje*.
Apr 09 18:44:47 <_phantom_> Krecik__ :: jeśli inteligencją nie grzeszysz to 
Twój problem.
Apr 09 18:44:57 <_phantom_> [tak wiem - dziś jestem chamski i prosto-liniowy]
Apr 09 18:45:17 <Krecik__> _phantom_  raczej nie jak by ten linux byl normalny 
to bez problemu zainstalowal bym to kadu
Apr 09 18:45:56 <_phantom_> Krecik__ :: ten _linux_ ma g* wspólnego z kadu.
Apr 09 18:46:33 <Krecik__> ale po co mi jakikolwiek system na ktorym nie ma 
czegos w rodzaju gg
Apr 09 18:46:35 <_phantom_> Krecik__ :: jak chcesz aby nie było problemów - to 
zapłać developerom i kadu i debiana, wtedy może będziesz miał soft na miarę m$ 
windows. (ba! i może nawet support 24h dostaniesz)
Apr 09 18:46:45 <_phantom_> a po co Ci coś w rodzaju gg ?
Apr 09 18:46:47 <Krecik__> nie mam gadugadu przez 2 dni i juz mnie telepie
%
#debian.pl
Apr 23 23:19:01 Zakus powrocil, mozecie wiwatowac ;)
Apr 23 23:20:47 naiwniak wiwatuje :P
Apr 23 23:21:02 <Zakus> naprawde naiwniak ;)
%
#debian.pl
Apr 25 21:02:10 <LiNiO> pl.ogloszenia.kupie
Apr 25 21:02:12 <LiNiO> Kupię 1000 pcheł i 300 karaluchów.
Apr 25 21:02:15 <LiNiO> Zwalniam mieszkanie i muszę je oddać w takim stanie w 
jakim dostałem je od spółdzielni.
Apr 25 21:02:50 <_phantom_> hmm... to szczęściarz jesteś ... ja musiałem kupić 
4000 karaluchów ;-P
%
#debian.pl
(zlot #debian.pl w Karpaczu)
Apr 25 22:11:17 <met> no dobra, gdzie jest Karpacz i czemu tak daleko?
%
#debian.pl
May 17 00:51:47 <ravenus> m_o_d. od zmierzchu do switu poogladaj :)
May 17 00:51:58 <m_o_d> widziałem:)
May 17 00:53:04 <ravenus> salmy nie obejrzysz?
May 17 00:53:12 <m_o_d> salmy??
May 17 00:53:19 <ravenus> salmy hayek
May 17 00:53:27 <m_o_d> co to jest??
%
#debian.pl
May 19 23:03:12 <TheMol> Witam :) male pytanie: mam podobno bardzo przyjazny i 
pomocny program o wdziecznej nazwie hanson.c, ktory usprawnia ponoc w znaczacy 
sposb komunikacje z ludzmi posiadajacymi rownie rewelacyjny program mirc. 
Problem w tym ze nie wiem jak poradzic sobie z instalacja tej oto pieknej 
aplikacji. Jak to zrobic? w BitchXie? w X-Chacie? czy 3ba kompilowac? czy 
wystarczy jakos wrzucic jako wtyczke bezk kompilacji a jak 3ba kompilowc to 
jak?]
%
#debian.pl
May 22 19:11:34 <Yata> slyszalem ze debian jest najprostsza dystrybucją 
wszystko sie robi za pomocom wizardu dselect
%
#debian.pl
May 27 22:37:07 <deus> mam pytanko: co to za porty?
May 27 22:37:07 <deus> 1024/udp   open        unknown
May 27 22:37:07 <deus> 1481/udp   open        airs
May 27 22:37:34 <deus> co to airs ?
May 27 22:43:22 <greg_> klimatyzacja ;]
%
#debian.pl
May 28 22:42:46 <blacharz> a mam takie jeszcze jedno pytanie jak z zrodel 
tar.gz moge zrobic deb?
May 28 22:42:51 <blacharz> dpkg?
May 28 22:42:59 <blacharz> czy make-dpkg ?
%
#debian.pl
May 28 22:45:52 <Argail> \`_: nowa klawiatura (ergonomiczna jego mać) i nie 
przyzwyczaiłem się jeszcze
May 28 22:46:00 <\`_> aha :D
May 28 22:46:02 <Argail> twardsza jest od mojej ukochanej
May 28 22:46:14 <Argail> ukochanej klawiatury oczywiście
%
#debian.pl
May 31 18:51:13 <ike> Hm. A jest jakis terminal co ma true transparency?
May 31 18:51:14 <Averne> ike: mam aterma :)
May 31 18:51:20 <deviant> ike: a aterm nie ma ?
May 31 18:51:36 <ike> deviant : hm. ma true-tinting z tego co wiem. ;]
May 31 18:51:49 <deviant> ike: a co rozumiesz przez true transparency ?
May 31 18:52:07 <ike> deviant : wszystko to co jest ,,podspodem'' widac.
May 31 18:52:16 <Sniezek> ike: zboczencu
%
#debian.pl
Jun 01 22:57:27 <GrUbBeR> Voder: dzwoniłem do ery w sprawie ich strony.
Jun 01 23:00:15 <Warden> GrUbBeR: że ?
Jun 01 23:00:46 <GrUbBeR> Że nie działa. Najpierw mi udowadniała, że wszystko 
jest ok [u niej się otwiera]
Jun 01 23:01:11 <GrUbBeR> Ale sprawdziła dokładnie i powiedziała, że faktycznie 
są problemy... Bo długo się loguje na serwer. Zgłosi do działu technicznego.
Jun 01 23:01:53 <GrUbBeR> Ciekawe jak długo by to trwało jakbym nie zadzwonił.
Jun 01 23:03:24 <GrUbBeR> [?]
Jun 01 23:04:36 <Vac_> GrUbBeR: era by padla <;
Jun 01 23:05:06 <GrUbBeR> Vac_: olewka totalna jak prawie cała Polska nie może 
strony otworzyć i oni o tym nie wiedzą. ;
Jun 01 23:06:57 <Voder> GrUbBeR: sprawdz czy Ci w ogole siec dziala i czy w 
ogole mozesz zadzwonic ;]
Jun 01 23:07:16 <GrUbBeR> Voder: jak dzwoniłem do nich to chyba działa. :>
Jun 01 23:07:25 <Voder> nie zapomne nigdy jak zadzwonilem bedac pod ukrainska 
granica do BOK Ery aby mi wlaczyli roaming
Jun 01 23:07:54 <Voder> po czym odezwal sie lekko nie trzezwy "bokista" a w tle 
slychac bylo niezla
imprezke
%
#debian.pl
Jun 05 14:25:20 <DoMeLLo> jesu jak ja lubie jak sie op albo opica wozi bo ma 
opa....... :)
Jun 05 14:25:20 <deviant> wozi? :>
Jun 05 14:25:20 <DoMeLLo> ta
Jun 05 14:25:20 <DoMeLLo> wozi
Jun 05 14:25:20 <deviant> rozumiem, że to była aluzja do mnie i Izzy
Jun 05 14:25:20 *** DoMeLLo kicked off from #debian.pl by met (Jezu)
Jun 05 14:25:22 <deviant> tylko zauważ, że póki co nikt nie poleciał.
Jun 05 14:25:31 *** DoMeLLo (domel)pf43]kielce,sdi}tpnet^pl) has joined 
#debian.pl
Jun 05 14:25:35 <deviant> :D
Jun 05 14:25:36 <DoMeLLo> lol
Jun 05 14:25:42 <deviant> ty jeżu :>
Jun 05 14:28:02 <DoMeLLo> co za syf sie porobil na tym kanale... chore uklady, 
kopiecie jak niedorobione dzieci ktore dopadly sie do opa, jeden cymbal 
wyskakuje  z jakims debilnym kopaczem, lala sie wozi jak malolata na baletach w 
podstawowce, ide stad, pocaujcie mnie w dupe
Jun 05 14:28:02 *** SignOff: DoMeLLo (domel\pf43~kielce+sdi:tpnet[pl) jeb
%
#debian.pl
Jun 06 00:07:59 <speedo_> 00:09.0 Communication controller: Intel Corp. 536EP 
Data Fax Modem
Jun 06 00:08:13 <speedo_> greg ale ten modem dzialal mi po linuxem
Jun 06 00:08:25 <speedo_> tylko teraz kompa wymienilem i nie chce cos zaskoczyc
Jun 06 00:08:43 <speedo_> mam do niego sterowniki od producenta
Jun 06 00:08:55 <\`_> speedo_: moze jest zaskoczony ?
%
#debian.pl
Jun 10 16:55:33 <Sprinter_> Sluchajcie wpisuje:  mount -t smbfs 
//-sprinter-/Temp /mnt/test , zeby zamontowac udostepniany katalog, a ten mi:
Jun 10 16:55:42 <Sprinter_> wrong fs type, bad option, bad superblock on 
//-sprinter-/Temp
Jun 10 16:55:50 <Sprinter_> Co jest nie tak ?
Jun 10 16:56:35 <LiNiO> masz  wrong fs type, bad option lub  bad superblock ;)
%
#debian.pl
Jun 11 19:11:48 *** szaoa (=wwwtemp@host94-80.crowley.pl) has joined #debian.pl
Jun 11 19:12:24 <szaoa> Jak ściągnąć K-line ?
%
#debian.pl
Jun 12 15:44:48 <Urug> Co nalezy wpisac w /etc/hosntame ?
Jun 12 15:44:50 <Urug> hostname ?
Jun 12 15:45:46 <[RaveMan]> Urug: wpisz "dupa
%
#debian.pl
Jun 13 14:16:14 <\`> znacie jakies modele o skoku porownywalnym z tym 
laptopowym ?
Jun 13 14:17:11 <cochese> \`: jakakolwiek + dwie garsci smieci wsypane pod 
klawisze ;)
%
#debian.pl
Jun 14 00:39:26 <emet> jak coś jest fajne, to albo wymaga perla, albo jest 
dziurawe, albo tuczące ;))
%
#debian.pl
Jun 14 23:13:51 <a^> slyszales moze cos deviant o tzw ruchu wahadlowym ?
Jun 14 23:14:14 <deviant> a^: tia, jak drogę przyblokują z jednej strony to tak 
się potem jeździ :>
Jun 14 23:15:29 <a^> deviant i mam taki problem wlasnie chyba z tym zwiazany bo 
koledze server na dsl postawilem (wiem to niewiarygodne jednak przwdziwe) i sie 
mi rozlacza jak sie lacze z putty a jemu gg co chwile siada
Jun 14 23:15:39 <a^> inny admin powiedzial ze to wlasnie przez te ruchy..
%
#debian.pl
Jun 16 18:07:59 <psycho555> jakie jest polecenie zeby mi moj sprzet pokazalo ?
Jun 16 18:08:00 <psycho555> co ?
Jun 16 18:09:08 <Ave`> psycho555: majtki down; lusterko on  ?;P
%
#debian.pl
Jun 17 21:46:41 <Oxydron> jak sie z kumplami 2gi tydzien na druty uczylismy
Jun 17 21:47:04 <Oxydron> to potem kumpel napisal transformate laplace'a z 
definicji na kartce i nam to pokazal to polewalismy z tego 5 minut :>
Jun 17 21:47:24 <zab|MGR> a gadałeś kiedys w asemblerze 680xx ??
%
#debian.pl
Jun 19 20:15:47 *** speedo__ (-speedo/pa253_bielsko"cvx)ppp[tpnet/pl) has 
joined #debian.pl
Jun 19 20:16:22 <speedo__> czemu mi takie cos wysylauje jak apt'a uzywam ?
Jun 19 20:16:23 <speedo__> Use of uninitialized value in exists at 
/usr/share/perl5/Debconf/Template.pm line 66, <GEN1> line 1.
Jun 19 20:16:27 <speedo__> Use of uninitialized value in exists at 
/usr/share/perl5/Debconf/DbDriver/Cache.pm line 29, <GEN1> line 1.
Jun 19 20:18:09 <speedo__> met wiesz moze od czego to ?
Jun 19 20:18:10 <met> bo perl śmierdzi i obsysa? ;)
Jun 19 20:18:31 <met> i każdy człowiek używający perla powinien zostać 
zastrzelony publicznie
Jun 19 20:18:48 <met> żeby inni wiedzieli, że tego nie należy dotykać nawet 
kijem z odległości dwóch metrów
Jun 19 20:19:02 <speedo__> :>>
Jun 19 20:19:25 <met> a za wejście na stronę perla powinno się kogoś pakietować 
icmp, bo trudniej wyciąć (trzeba na routerze brzegowym)
Jun 19 20:19:44 <speedo__> a da sie cos z tym zrobic ???
Jun 19 20:20:06 <met> a chcesz icmpem? *eg*
Jun 19 20:20:38 <speedo__> met syn flood na modemiarzy nie dziala
Jun 19 20:20:49 <met> speedo__ :: a czy ja mówię o syn?
Jun 19 20:20:51 <speedo__> no chyba ze mi udp lacze zapachasz
Jun 19 20:20:52 <speedo__> ;p
Jun 19 20:20:55 <met> speedo__ :: a czy ja mówię o udp?
Jun 19 20:21:32 <met> widzę że o działaniu sieci też nie masz pojęcia...
Jun 19 20:21:32 <speedo__> met no no chyba nie powiesz ze ack bedziesz we mnie 
walil ;p
Jun 19 20:22:22 <speedo__> met ja na niczym nie ma pojecia, ja sie dopero ucze
Jun 19 20:22:23 <speedo__> ;p
Jun 19 20:22:23 <speedo__> jestem totalny newbie
Jun 19 20:22:27 <met> widać
Jun 19 20:23:10 <speedo__> no a podpowiesz co mam zrobic z tymi bledami od 
perla ?
Jun 19 20:24:28 <speedo__> met ??
Jun 19 20:24:33 <met> a czy możesz łaskawie wywalić się tak jak ten perl i nie 
zawracać mi głowy?
%
#debian.pl
Jun 19 21:36:27 <no-one> hem za duzo siedze juz przy kompie dzis .. 
antialiasing sie zarzucil
%
#debian.pl
Jun 19 23:45:33 <wisnia> zrobikem sobie liczniki paketow
Jun 19 23:45:33 <wisnia> na iptables
Jun 19 23:45:39 <wisnia> ale nie przechodza prz nie znadne pakiety
Jun 19 23:45:45 <wisnia> czym to moze byc spowodowane?:)
%
#debian.pl
Jun 20 13:37:43 <no-one> you will traying load moule without GPL license and it 
have unresolve symbols
%
#debian.pl
Jun 22 10:24:46 <walus> stawial ktos z was serwer na debianie ?
%
#debian.pl
Jun 23 22:42:11 govin ma pytanko czy ktos moglby poswiecic pare minut i 
wygenerowac .config kernela dla konfiguracji jaka ja posiadam ??
%
#debian.pl
Jun 25 13:20:54 <_cX_> postfix/postfix-script : warrning: /usr/lib/sendmail and 
/usr/sbin/sendmail differ - mam sie tym przejmowac?
Jun 25 13:21:11 <voidhead> no.
Jun 25 13:21:32 <voidhead> ja na twoim miejscu bym wyjechal do sanatorium w 
baden-baden, jakbym ujrzal taki komunikat.
Jun 25 13:21:41 <_cX_> :/
Jun 25 13:21:54 <_cX_> nie wiem czy taknie zrobie..
Jun 25 13:22:04 <voidhead> slusznie, slusznie.
Jun 25 13:22:35 <vald> ja proponuje kaszpirowskiego w czteri oczi
Jun 25 13:22:50 <voidhead> /dev/kaszpirowski0
Jun 25 13:22:54 <vald> hehe
Jun 25 13:23:03 <voidhead> echo adin > /dev/kaszpirowski0
%
#debian.pl
Jun 26 01:38:38 <m_o_d> oki wszystko działa
Jun 26 01:38:46 <m_o_d> super kocham linuxa, gdyby sie to dymac dało
%
#debian.pl
Jul 10 20:30:30 <FsHuT> deviant: Mam taki maly problem. NIemam w /dev/ urzadzen 
takich jak eth0.. czy wlan0.. jak je moge dodac ?
%
#debian.pl
Jul 15 17:27:23 <no-one> wyskakuje nvidia loaded
Jul 15 17:27:24 <no-one> ;]
Jul 15 17:27:29 <no-one> w ldsmod jest
Jul 15 17:27:36 <no-one> a jak wpisze do konfigu
Jul 15 17:27:46 <no-one> to modul not find ;]
Jul 15 17:27:57 <no-one> tylko jakis blad wyskauje cos tam z gpl license ;]
Jul 15 17:30:30 <speedo_> no-one no bo to sa binarki nie na licencji GNU
Jul 15 17:30:41 <speedo_> ale to ine ma znaczenia w dzialaniu
Jul 15 17:30:42 <speedo_> ;p
Jul 15 17:31:58 <no-one> speedo_: a co zrobic aby licencja byla :P ? :D
%
#debian.pl
Jul 16 14:17:09 <jam> Newsgroups line:
Jul 16 14:17:09 <jam> pl.comp.os.linux.debian         System Operacyjny Debian 
GNU/*.
Jul 16 14:17:24 <jam> Wyniki pl.comp.os.debian (153:33 - TAK)
Jul 16 14:17:26 <jam> wow !
Jul 16 14:18:02 <[LocK]> jam: a ile za nie ?
%
#debian.pl
Jul 19 13:39:18 <ghty> jak zrobic screena w kde ? (jest jakas magiczna 
kombinacja tak jak w winshitach?)
Jul 19 13:39:36 <Ciacho> kde ma swoj wlasny program do screenow
Jul 19 13:39:47 <[LocK]> ghty: ctrl+alt+del ;]
Jul 19 13:39:49 <Ciacho> w menu start jest od razu
Jul 19 13:40:04 <Ciacho> [LocK]: reset...
Jul 19 13:40:04 <ghty> jak sie nazywa
Jul 19 13:40:06 <Ciacho> ksnapshot
Jul 19 13:40:07 <met> apt-get install scrot :P
Jul 19 13:40:08 <Ciacho> albo kdesnap
Jul 19 13:40:10 <Ciacho> albo cos takiego
Jul 19 13:40:31 <PsH> ghty alt+ ctrl + backspace
Jul 19 13:40:48 *** SignOff: ghty (~ghty/tx134=internetdsl_tpnet*pl) Lost 
terminal
%
#debian.pl
Jul 20 18:54:21 <Bonetti> kto mi powie jak w trakcie instalacji moge 
podmontowac dyskietke i zainstalowac modul do karty sieciowej z rozszezeniem pdf
%
#debian.pl
Jul 21 16:57:24 *** mimi12 (-milka[qm168(neoplus{adsl[tpnet{pl) has joined 
#debian.pl
Jul 21 17:00:13 mimi12 uruchomic siec lokalna i necik- podziekowac met, aik za 
cierpliwosc i pomoc, 
no-one za podejzenia ze jestem facetem(to nieprawda), feniowi za to ze byl tak 
nieuprzejmy i sprawil ze sama cos zrobilam
%
#debian.pl
Jul 23 18:44:48 <badspirit> debian documentaction project :)
Jul 23 18:48:07 <a^> Podana fraza - debian documentaction project - nie została 
odnaleziona.
Jul 23 18:52:43 <badspirit> heh
Jul 23 18:52:54 <badspirit> gdzie ty tego szukasz ?
Jul 23 18:53:04 <badspirit> na wyszukiwarce microsoftu ? :P
%
#debian.pl
Jul 24 18:12:34 <deadcow> na czym zrobic jajecznice zeby nie byla kaloryczna ?:)
Jul 24 18:12:52 <e-misiek> deadcow: Jajescznice bez jajek :-)
%
#debian.pl
Jul 25 12:28:28 <fEnIo> prosze zmodyfikowac Buciorka i met'a coby tak istotne 
slowo jak alkohol uwzglednialy ;)
Jul 25 12:28:48 <met> fEnIo :: sam się zmodyfikuj :PPP
Jul 25 12:29:04 <Izza> hehehe
Jul 25 12:29:07 <fEnIo> met: :)
Jul 25 12:29:18 <met> dodałem do słownika
Jul 25 12:29:29 <met> 122920 ::: Saving words to ~/.irc/dzemik.txt
Jul 25 12:29:29 <met> 122920 ::: 332 words saved.
Jul 25 12:29:29 <fEnIo> no-one: powiedz alkochol ;)
Jul 25 12:29:52 <[LocK]> ja widze ze tu sami polonisci siedza ;]
Jul 25 12:30:21 <fEnIo> [LocK]: ojczysta mowa to wazna sprawa :P
Jul 25 12:30:56 <[LocK]> fEnIo^B:^B zgadzam sie ale zeby za nie ojczysta 
dostawac kopa to przesada
Jul 25 12:31:12 <[LocK]> fEnIo^B:^B kary cielesne sa zabronione w polszcze ;]
Jul 25 12:31:12 <fEnIo> [LocK]: jakos trzeba edukowac ;)
Jul 25 12:31:16 <jam> [LocK]: aby doszlo do porozumienia przede wszystkim 
nalezy miec wspolny protokol komunikacji (jezyk polski w tym przypadku)
Jul 25 12:31:49 <jam> [LocK]: a przy bledach transmisji polaczenie jest 
rozrywane (/kick :)
%
#debian.pl
Jul 25 23:58:27 <MichalZ> grr czat.wp.pl padl :P
Jul 25 23:58:34 <met> MichalZ :: WINDZIARZ!
Jul 25 23:58:51 <MichalZ> met:  tak ! moje laska jest 200 km odemnie i to jest 
jednye cos..
Jul 25 23:59:10 <deadcow> MichalZ: a to masz odczepianą ? *eg*
%
#debian.pl
Jul 27 12:54:08 <imap> spinn - RTFM ;-))
Jul 27 12:54:25 <spinn> imap sam jestes RTFM palko
%
#debian.pl
Jul 27 19:37:40 <chsh> informatyczny lovelas - 'czesc, chcesz zobaczyc moje 
jądro?'
%
#debian.pl
Jul 27 22:09:50 <mimi12> deviant moglbys na przyszlosc nie kopac ... bylabym 
wdzieczna
Jul 27 22:10:06 <deviant> mimi12: jesteś nieletnia i nie dałaś fotki.:>
%
#debian.pl
(LinuxPlus)
Jul 28 10:49:02 <ufo|spi> Izzunia kiedy bedzie numer sierpniowy?
Jul 28 10:49:50 <Izza> 1 sierpnia?:)
%
#debian.pl
Jul 28 11:09:39 <tekmar> panowie Izza wyraznie na forum podkreslila "precz z 
lapami" ... chyba ze zle to odczytalem ;)
Jul 28 11:10:19 <ufo|spi> tekmar my lapki mamy na miejscu:P
Jul 28 11:10:23 Ciacho jest grzeczny i z lapami sie nigdzie nie pcha.. najwyzej 
z innymi czlonkami
%
#debian.pl
Jul 29 12:11:53 <Ciacho>          IT MAFIA - Michal Makowski info-nazwa[pl 
+48.126241919
Jul 29 12:11:53 <Ciacho>          IT MAFIA - Michal Makowski
Jul 29 12:11:53 <Ciacho>          Aleja Nagorna 12
Jul 29 12:11:53 <Ciacho>          Wolomin,mazowieckie,Poland 05-200
Jul 29 12:11:56 <Ciacho> moj klient.
%
#debian.pl
Jul 31 10:46:10 <Warden> Rząd Malezji unieważnił orzeczenie sądu religijnego, 
że muzułmańscy mężczyźni mogą rozwieść się ze swoimi żonami przez wysłanie 
wiadomości tekstowej - SMS - z telefonu komórkowego.
Jul 31 10:46:41 <coor> na MMS-ach chca zarobic :P
%
#debian.pl
Jul 31 22:28:25 <met> *** Quits: TITANIC (Excess Flood)
%
#debian.pl
Aug 04 23:07:25 <[LocK]> met => Use of uninitialized value in concatenation (.) 
or string at ./tc.pl line 370, <STDIN> line 9.
Aug 04 23:07:30 <[LocK]> co to ma znaczyc ?
Aug 04 23:07:35 <[LocK]> bo jakos nie moge dojsc :(
Aug 04 23:07:58 <met> [LocK] :: użyłeś uninicjalizowanej walui w konkatentacji 
(.) lub stringy w ./tc.pl linii 370, <STDIN> linii 9.
%
#debian.pl
Aug 05 00:31:43 <nie-pije> moze mi powiedziec ile statystyczny czlowiek moze 
pic i nie spac? :)
%
#debian.pl
Aug 08 17:20:49 <deadcow> jakie są dobre płyny do kąpieli ?
Aug 08 17:20:54 <met> np. woda
%
#debian.pl
Aug 14 20:51:05 <natan4> wiecie co firewall to dobra zecz
Aug 14 20:51:17 <natan4> ta osoba ktora to wymyslila powinna dostac niobla
Aug 14 20:51:28 <natan4> mam pod soba pare siec lan
Aug 14 20:51:36 <natan4> upierdliwy user truje i truj
Aug 14 20:51:49 <natan4> truje i truje
Aug 14 20:51:52 <natan4> wiec so sie robi ?
Aug 14 20:51:58 <natan4> blokuje na firewallu
Aug 14 20:52:07 <natan4> a on dzowni i mowi ze ma cos nietak z windowsem
Aug 14 20:52:14 <natan4> i chce dac piedziesiat zlotych za naprawieni etego
Aug 14 20:52:15 <natan4> :)
%
#debian.pl
Aug 16 14:06:01 <PooL> ej co musze ustawiec w bindzie majac domene .net aby 
wchodzac np na mirca pokazywalo sie w adresie mojadomena.net a nie jakies tam 
qq82.dddd.tpnet.pl
%
#debian.pl
Aug 20 20:34:14 <MarQs> nie moge sobie exima skonfigurowan na virtuale
Aug 20 20:34:32 <MarQs> ma ktos dzialajacy conf?
Aug 20 20:34:49 <MarQs> albo jaki MTA bylby lepszy?
Aug 20 20:35:28 <tomo_____> postfix ale nie wiem czemu
%
#debian.pl
Aug 20 21:17:14 <badspirit> jak sie na bx zdejmowalo igonra za flooda ??
Aug 20 21:17:44 <LiNiO> badspirit: /disco help
Aug 20 21:17:49 <badspirit> :P
Aug 20 21:17:58 *** SignOff: badspirit (~badspirit}pb30$przeworsk^sdi!tpnet^pl) 
help
(/disco to /disconnect)
%
#debian.pl
Aug 20 22:47:43 <cochese> heh, przypomniala mi sie opowiesc o adminie, ktory 
shaping zrobil przez wykonywanie co minute z crona if-down eth1; sleep X; if-up 
eth1
Aug 20 22:47:56 <cochese> predkosc dobieral iloscia sekund przy 'sleep'
%
#debian.pl
Aug 21 14:11:39 <natan4> dzis mnie ani razu nie kick met
Aug 21 14:11:40 <natan4> ;)
Aug 21 14:11:56 <pi0tr> met tez mnie wogole nie kopie ;p
Aug 21 14:11:56 *** pi0tr kicked off from #debian.pl by Buciorek (robisz błędy! 
prawidłowa pisownia: w ogóle)
Aug 21 14:11:57 *** pi0tr (~ares]debian|syscomp~pl) has joined #debian.pl
Aug 21 14:11:57 *** pi0tr kicked off from #debian.pl by met (w ogóle)
Aug 21 14:12:01 *** pi0tr (~ares|debian>syscomp>pl) has joined #debian.pl
%
#debian.pl
Aug 23 13:33:10 <badspirit> ale wczoraj na rowerze
Aug 23 13:33:33 <badspirit> jezdzilem i spadlem z murku i sobie reke w 3 
miejscach rozwalilem :)
Aug 23 13:34:08 <badspirit> w nadgarstku lockiu i dlon zdarlem skroe az do 
miesa :(
Aug 23 13:34:32 <badspirit> qna chcialem zjechac z takiego mo\urku
Aug 23 13:34:50 <badspirit> no i sie nzatrymalem i wiedzialem ze trzeba 
podniesc przednie kolo i zjechac na tylnym
Aug 23 13:34:58 <badspirit> ale jakos bylem ciekaw jak nie podniose co sie 
stanie
Aug 23 13:35:20 <badspirit> no i sie stalo
Aug 23 13:35:35 <badspirit> najpierw spadlo przendie kolo potem ja przez 
kierwonice potem rower na mnie :P
Aug 23 13:36:04 <LiNiO> badspirit: no nie trzymaj nas już w napięciu. mów co z 
rowerem!
%
#debian.pl
Aug 26 16:31:15 <[Dran]> jak odpalic instlake debiana pod xp?
Aug 26 16:31:22 <[Dran]> moze mi ktos pomoc
%
#debian.pl
Aug 27 19:57:00 <natan4> met a mas zjakis sprawdzony dobry hd ktory jest ci 
zbedny a napewno by sie przydal na piwie ?
Aug 27 19:58:10 <Howks> natan4: kup jakis IBM one nie padaja :)
%
#debian.pl
Aug 28 20:40:26 <bArT___> cant locate module ip_tables, iptables v1.2.6a cant 
initialize iptables table `filter`: iptables who? (do you need to instmod?)
Aug 28 20:40:45 <bArT___> prhaps iptables or ypur kernel needs to be upgraded
Aug 28 20:40:58 <bArT___> czy oby na pewno bo robilem wszystko wedle instukcji 
w necie :)
Aug 28 20:43:58 <bArT___> no to jakis ktos moze powiedziec cos o mojej 
maskaradzie? ;)
Aug 28 20:44:30 <masklin> bArT___: nie masz w kernelu. albo modułu nie 
włączyłeś.
Aug 28 20:44:35 <LiNiO> bArT___: uname -r
Aug 28 20:45:03 <bArT___> bardziej lopatologicznei bym prosil
Aug 28 20:45:06 <bArT___> jesli mozna
Aug 28 20:45:21 <LiNiO> u
Aug 28 20:45:24 <LiNiO> potem n
Aug 28 20:45:34 <LiNiO> potem ame spacja -r enter
Aug 28 20:46:03 <LiNiO> i przepisz tutaj co sie pojawilo po wcisnieciu entera
%
#debian.pl
Aug 28 23:24:04 <_phantom_> natan4 :: nie samą pocztą człowiek żyje!!! ;>
Aug 28 23:24:19 <_phantom_> poza pocztą to jeszcze usenet-em. *eg*
%
#debian.pl
Aug 29 13:22:57 <pshem> jak na chama wywalic pakiet ?
Aug 29 13:23:06 <chsh> stawiasz chama
Aug 29 13:23:09 <chsh> pod oknem
Aug 29 13:23:28 <chsh> i wywalasz na niego cirka ebałt 200 metrów kabla H-1000
Aug 29 13:23:30 <chsh> nie wstanie.
%
#debian.pl
Sep 02 14:38:51 <echicken> ma ktośjakiegoślinka jak zrobić drukarkęna USB tak 
żeby drukowała na konsoli \?
Sep 02 14:39:40 <jam> echicken: nie znam sie na drukarkach, ale wszystkie jakie 
widzialem drukowaly albo na papierze, albo na foli
%
#debian.pl
Sep 08 00:41:11 <Warden> |ufo|-> tia, dysk odjechał
Sep 08 00:41:14 <Warden> naprawiam właśnie
Sep 08 00:41:30 <|ufo|> tak widze jak ty naprawiasz:)
Sep 08 00:41:32 <Howks> |ufo|: szpachluje bad sectory :>
%
#debian.pl
Sep 11 23:59:38 <Warden> http://im0.p.lodz.pl/~kubarski/
Sep 11 23:59:46 <Warden> mój profesor od analizy matematycznej
Sep 11 23:59:47 <Warden> AKTUALNY
Sep 11 23:59:47 <Warden> ;P
Sep 12 00:00:09 <fEnIo> http://skawina.eu.org/zdjecia/radar/ moj pies - 
AKTUALNY ;P
%
#debian.pl
Sep 16 23:23:18 <_phantom_> updejtujcie to ssh !!! :->
Sep 16 23:23:29 <_phantom_> [jak ktos ma permitrootlogin na yes to ma 
przerabane ;->]
Sep 16 23:23:53 <m_o_d> co sie stalo z ssh ?
Sep 16 23:26:09 <m_o_d> _phantom_: jakis splolit, czy explolit ?
%
#debian.pl
Sep 17 22:29:01 <m_o_d> kompilował ktos 2.6-test5? mam przy wszystkich modulach 
unresolved symbols
Sep 17 22:30:16 *** zab0ra is now known as TyChamie
Sep 17 22:32:45 <TyChamie> m_o_d: a wszyttuje Ci moduly dla tego jadre?
Sep 17 22:33:43 <m_o_d> TyChamie: jak robie dpkg -i kernel-image to mi to 
wyskakuje, potem odpalam kompa, niby działa dobrze, ale nie wczytuje zadnych 
modułow
Sep 17 22:33:57 <TyChamie> ja ty sie do mnie zwracasz ??? :)))
%
#debian.pl
Sep 19 14:12:19 <met> zdzih :: uzywasz gpm?
Sep 19 14:14:00 <zdzih> met :: hehe , zebym ja jeszcze wiedzial dokladnie co to 
jest , wiem tylko ze to cos do myszki co umozliwia przeciaganie i upuszczanie , 
chyba , ale nie wiem czy tego uzywam
%
#debian.pl
Sep 22 14:04:31 <met> dlaczego ludzie chcą używać 2.6?
Sep 22 14:05:16 <Hrw> met: bo mi myszka szybciej pod x-ami chodzi?
%
#debian.pl
Sep 24 10:44:41 <pi0tr> buhahah
Sep 24 10:44:52 <pi0tr> niszczarka od papieru wciagnela mi kanapke :)
Sep 24 10:44:55 <pi0tr> byla w worezku
Sep 24 10:44:59 <pi0tr>  i nie mialem gdzie jej polozyc :D
Sep 24 10:45:12 <Warden> ROTFL ;-]
Sep 24 10:45:15 <pi0tr> ciekawe kto t o teraz umyje ;p
Sep 24 10:45:21 <Warden> no jak to kto, Ty ;P
Sep 24 10:45:34 <Warden> fajnie będziesz wyglądał idąc do łazienki
Sep 24 10:45:36 <Warden> fotki robić!
Sep 24 10:45:38 <Warden> ;]
Sep 24 10:45:46 <pi0tr> kurcze nie wiedzialem ze to ma taka sile ;)
Sep 24 10:45:56 <Warden> no palca nie wkładaj...
Sep 24 10:46:40 <pi0tr> :) wiesz to amerykanska niszczarka, a w stanach robia 
instrukcje tylko obrazkowe
Sep 24 10:46:49 <pi0tr> i wyraznie jest namalowane zeby np krawata nie wsadzac 
do srodka
Sep 24 10:47:11 <Warden> hehehe
Sep 24 10:47:18 <Warden> no tak
Sep 24 10:47:25 <Warden> ale o kanapce nie pomysleli :p
%
#debian.pl
Sep 26 12:02:42 <fEnIo> Doradźcie mi ludziska... chcę podmienić płytę główną, 
procesor, pamięci i grafikę, a nie chcę stracić "up 38 days"... jak to zrobić? 
;)
(...)
Sep 26 12:05:40 <fEnIo> Czyli sprawdziły się najgorsze przepowiednie... w 
Debianie się nie da ;)
%
#debian.pl
Sep 28 17:42:48 *** asik (asik!snajper(pl) has joined #debian.pl
Sep 28 17:43:09 <asik> mam syna !!!
Sep 28 17:43:25 <met> gratuluję/współczuję
Sep 28 17:44:07 <speedo> asik a dostal juz jakiegos pingwinka ?
Sep 28 17:45:02 <asik> dzieki :) pingwinka? sam wygladaq jak pingiwnek jaki 
fajniusi skubany :)
Sep 28 17:45:38 <speedo> hehe
Sep 28 17:45:56 <speedo> no to teraz musisz go nauczyc asmeblera na poczatk ;p
Sep 28 17:46:34 <asik> na poczatek :P
Sep 28 17:48:50 <speedo> no to nie marnuj czasu tylko ic go przewin
Sep 28 17:49:00 <speedo> bo pewnie juz szczelil kupke napoczatek
Sep 28 17:49:00 <speedo> ;p
Sep 28 17:49:43 <met> taa, i kernel przekompiluj
Sep 28 17:49:49 <rydz> :)
Sep 28 17:49:54 <speedo> koniecznie
Sep 28 17:50:10 <Zakus> dzieci powinny sie rodzic z pepowina skrecona na 
ksztalt spiralki Debianowskiej ;)
%
#debian.pl
Oct 06 19:19:32 <greg_> coto sa te 'stery'
Oct 06 19:19:39 <greg_> jak mozna wsadzic ster do komputera?
Oct 06 19:19:51 <greg_> kiedys podpialem joystick, ale to chyba nie to
Oct 06 19:20:06 <greg_> a jak wsadzic ster do iksów to zupełnie nie wiem
%
#debian.pl
Oct 06 20:11:44 <pecet> chcialem zainstalowac Debian'a Sarge i kupa
Oct 06 20:11:47 <pecet> :/
Oct 06 20:12:07 <wysek> pecet: jakieś problemy z kupa?
%
#debian.pl
Oct 08 22:40:32 <fEnIo> ICQ dla ludzi ze świata, Jabbera dla normalnych ludzi z 
Polski i ze świata, Tlena dla średnio normalnych ludzi, a GG dla pajaców ;)
%
#debian.pl
Oct 21 15:55:02 <kusz> qrde czy nikt nie administruje jakims akademikiem ? :P
Oct 21 15:55:11 <pi0tr> ja administruje
Oct 21 15:55:14 <pi0tr> akademikiem
Oct 21 15:55:16 <pi0tr> :)
Oct 21 15:55:20 <pi0tr> a co chcesz :) ?
Oct 21 15:55:38 <LiNiO> pi0tr: ze 3 panienki po 19-lat ;)
%
#debian.pl
Oct 22 17:25:14 <vaiker> po lozko walaja mi sie karty graficzne i sieciowe, po 
podlodze kable, szafa na gorze pelna pudelek po spzrecie komputerowym, na 
biurku twardziele i napedy cd - ludzie gdzie ja jestem, czy napewno dobrze 
postepuje trwajac w takiej rzeczywistosci ?
Oct 22 17:25:14 *** vaiker kicked off from #debian.pl by met (na pewno)
(wordkick, napewno -> na pewno)
%
#debian.pl
Oct 22 17:40:10 <insanecow> met idziemy na basen ?:P
Oct 22 17:40:52 <met> insanecow :: idz sie utop ;P
%
#debian.pl
Oct 26 11:29:30 <pi0tr> slyszlaem ze ponoc w nowym mircu jest jakis bug ciekawy
Oct 26 11:29:46 <met> pac
Oct 26 11:29:54 *** SignOff: pi0tr (ares{s33(syscomp\pl) Connection reset by 
peer
Oct 26 11:29:55 <met> (sam się prosił)
%
#debian.pl
Oct 26 13:08:36 <szczepek> co to za opcja w 2.4.22 IP:advenced router ??????
Oct 26 13:09:01 <snpx> jak nie wiesz zainstaluj jako modul ;)
%
#debian.pl
Oct 27 21:49:44 <zipek> czesc
Oct 27 21:50:03 <zipek> co zrobic jak pisze haslo i pol hasla dziala tylko
Oct 27 21:50:16 <LiNiO> zipek: skróć
Oct 27 21:50:19 <met> napisać dwa hasła.
%
#debian.pl
Oct 28 00:14:55 <maf> debian.pl - skrypt perlowy do debiana ;P
%
#debian.pl
Oct 28 20:55:50 <_phantom_> met :: o! :-) co psujesz w OOo ?:-)
Oct 28 20:57:01 <met> _phantom_ :: w dużym skrócie, moje ewil obliczenia, które 
mają zapewnić mi władzę nad światem za pomocą soczewki rozpraszającej, 
programowalnego kontrolera przerwań i gumki-recepturki.
Oct 28 20:57:39 <_phantom_> met :: hmm.... to daj znac jak Ci sie uda -- jak 
robilem to samo w poprzednim tygodniu to niestety nie dalo porzadanego 
rezultatu ;-)
Oct 28 20:58:38 <_phantom_> met :: no tak -- dominacja nad światem nigdy nie 
była tak prosta (tm) :-D
Oct 28 20:59:28 <met> Ten kreator pomoże ci zapanować nad Światem.  Naciśnij 
Dalej aby kontynuować lub Anuluj aby zakończyć.
%
#debian.pl
Oct 28 21:51:59 <Unc> LiNiO: uzywasz moze myszy USB ?
Oct 28 21:52:01 <LiNiO> nie, wole tradycyjne, na comie albo na psie ;)
Oct 28 21:52:25 <Kajko> LiNiO meczyciel zwiarzat
Oct 28 21:52:34 <Kajko> LiNiO myszy na psie :)
%
#debian.pl
Oct 31 00:40:11 <kshys> mam pytanie, przy konfiguracji jaja 2.4.22 zaznaczac 
"Kernel support for a.out binaries" ?? Chodzi mi o to ze mam jakiegos  
badziewnego exploita (nazwa pliku a.out, pewnie moze byc dowolna ale ta akurat 
jest taka) ktory dziala na debianie zaskakujaco dobrze, a chce sobie system 
zalatac i troche nie mam pojecia jak
%
#debian.pl
Nov 02 22:53:54 <Averne> a to Ty byłeś na warlugu?
Nov 02 22:54:04 <greg_> Averne: ja to ten troll z konca sali
Nov 02 22:54:09 <Averne> lol
Nov 02 22:54:14 <Averne> a ja ten troll z przodu sali :D
%
#debian.pl
Nov 04 19:50:55 <speedo_> lol co wypatrzylem
Nov 04 19:51:11 <speedo_> (19:50) :: Topic for #linuxworld: Jestem Sobie Hacker 
Maly Mam Komputer I
Net Staly, Niech Mi teraz Kto Podskoczy To Dostanie Pingiem w Oczy
Nov 04 19:51:12 <speedo_> (19:50) :: Topic set by Najkon (najkon#abuse^lag,pl) 
(Tue Nov  4 17:37:42
2003)
%
#debian.pl
Nov 04 23:10:30 <met> czy ktoś z was jest zainteresowany kontem shellowym?
Nov 04 23:10:31 <Buciorek> met: ja jestem ;)
Nov 04 23:10:46 <fEnIo> met: ja... kont shellowych nigdy za wiele ;)
Nov 04 23:10:51 <masklin6> met: i ja. ;)
Nov 04 23:10:54 <maf> met przyda się jak zabanujeta ;)
Nov 04 23:11:02 <barczu> met: ja tez,ale gdzie jest haczyk ;]?
Nov 04 23:11:16 <deadcow> met :: ja tez :D
Nov 04 23:11:17 <ravenus> ja tez się dołączam do listy :]
Nov 04 23:11:18 <masklin6> To takie badanie opinii publicznej. ;)
Nov 04 23:12:12 <met> Buciorek fEnIo masklin6 maf deadcow ravenus :: proponuję 
więc zapoznać się z ofertą jednej z komercyjnych shellowni.  Dziękuję za uwagę. 
;)
%
#debian.pl
Nov 06 14:44:38 <dF9> powiedzcie mi skad mam wziasc system.map ?
Nov 06 14:45:03 <Lulek|> z atlasu ?:)
%
#debian.pl
Nov 09 16:28:28 <lastat> orientuje sie ktos jaka jest najnowsza plytka korna ?
Nov 09 16:28:51 <fEnIo> lastat: pewnie okrągła, ale nie jestem pewien ;)
%
#debian.pl
(o sesji która zmieniała nicki co minutę:)
Nov 09 16:52:05 <Verdan> Ignorance List:
Nov 09 16:52:06 <Verdan> 17:15    1 *!*@g3.pl: CRAP MSGS NOTICES SNOTES CTCPS 
ACTIONS JOINS PARTS QUITS KICKS MODES TOPICS WALLOPS INVITES NICKS DCC DCCMSGS 
CLIENTNOTICES CLIENTCRAP CLIENTERRORS HILIGHTS
Nov 09 16:52:36 <Verdan> jest nicks i dalej mnie meczy
Nov 09 16:53:49 <lastat> 3g a nie g3 :P
Nov 09 16:54:02 <Verdan> o
Nov 09 16:54:12 <vail> muahahah ;]
Nov 09 16:54:16 <Verdan> :)
Nov 09 16:54:25 <Verdan> ops dwa miesiace sie mecze przez literowke ....
%
#debian.pl
Nov 10 18:13:00 <pepson> cze mama pytanko w jaki sposob sprawdzic dostepnosc 
pamieci RAM
Nov 10 18:13:42 <LiNiO> pepson: zadzwoń do sklepu komputerowego i spytaj czy 
jest u nich dostępna pamięć RAM ;)
%
#debian.pl
Nov 17 22:03:15 <frequency> jest ktos z kolegow wpiety w e-Wro moze ?
Nov 17 22:03:18 <Buciorek> frequency: ja jestem ;)
Nov 17 22:03:22 <frequency> jestem ciekaw jak to biega
Nov 17 22:03:49 <frequency> no i...?
Nov 17 22:04:28 <frequency> ile z zewnatrz wyciagasz ?
(Buciorek to bot)
%
#debian.pl
Nov 20 21:44:07 <mario_bo> Chce przelozyc dysk z debianem do nowego kompa.
Nov 20 21:44:36 <mario_bo> Czy odczyta mi debian wszystkie nowe rzeczy jakie 
tam beda?
Nov 20 21:44:55 <mario_bo> nie chcialbym instalowac go od nowa
Nov 20 21:46:41 <mario_bo> Wyczytalem, ze w takiej sytuacji najlepiej uruchomic 
z nieskompilowanym jadrem
%
#debian.pl
Nov 26 22:56:06 <_phantom_> brb. wc -l
%
#debian.pl
Nov 27 15:26:44 *** SignOff: kshys (^empty{mass!kill&pl) $me Nickname collision 
KILL from $address($me,5)
%
#debian.pl
Dec 05 12:54:56 <szyderca> dobra miski ide do serverowni na pizze
Dec 05 12:54:57 <szyderca> :)
Dec 05 12:54:59 <szyderca> bede za chwilke
Dec 05 12:55:00 <szyderca> :)
Dec 05 12:55:02 <szyderca> ok
Dec 05 12:55:02 *** SignOff: szyderca (mmilasze`boss$zie$pg!gda/pl) szyderca 
has no reason
Dec 05 12:55:15 <BeerfaN> pizza z talerza 3,5"
%
#debian.pl
Dec 10 17:23:04 <met> nienawidzę mldonkey. ;)
Dec 10 17:24:43 <sleepycow> hej met :D
Dec 10 17:24:44 <sleepycow> czemu ?:>
Dec 10 17:24:54 <met> za servers.met
Dec 10 17:27:10 <met> miałem przez to 18 highlightów :P
%
#debian.pl
Dec 15 20:45:51 <bxzz> moze na to pytanie mi ktos odpowie: rozchodzi sie o MTU 
kiedy wlaczac i dlaczego bo np. ja jestem w sieci enthernet ktora jest 
polaczona z internetem to czy jak wylacze ta opcje to bloki wychodzace odemnie 
z kompa przejda przez enthernet ale zatrzymaja sie przy internet???
%
#debian.pl
Dec 18 13:50:58 <LiNiO> Averne: na tym kanale połowa nie wie kto to ?loczek ;)
Dec 18 13:51:28 <Averne> to taki troll gorszy odemnie :D
%
#debian.pl
Dec 18 15:21:45 <[Shinden]> hm znacie jakis program do przedluzania zywotnosci 
pakietow ?
Dec 18 15:24:23 <BeerfaN> ja dostaje tylko maile o przedluzaniu penisa
%
#debian.pl
Dec 21 09:15:21 fEnIo is back from wódka after 12 hrs 29 mins 3 secs
Dec 21 10:01:22 fEnIo is gone: browar
%
#debian.pl
Dec 21 20:18:46 <fakefoo> :ZAINTERESOWANIA:
Dec 21 20:18:48 <fakefoo> sporty extremalne, minn. spinaczka. poza tym lubie 
plywac
Dec 21 20:19:12 <fakefoo> uprawia ktoś spinaczke ?
Dec 21 20:19:12 <fakefoo> ;-)
Dec 21 20:19:54 <Emiml> to taki sport urzędniczy
%
#debian.pl
Dec 23 18:43:14 <Lamagra> cześć masklin6
Dec 23 18:43:23 <masklin6> Lamagra :)
Dec 23 18:44:29 <Lamagra> a ty już karpia zabił?
Dec 23 18:45:46 <masklin6> 3 razy, cheatował bydlak ;)
%
#debian.pl
Dec 23 20:15:05 <Szamal> jest ktos w stanie mi pomoc?
Dec 23 20:15:05 <Buciorek> Szamal: ja jestem ;)
Dec 23 20:15:11 <Szamal> moge priv?
Dec 23 20:15:44 <Szamal> Buciorek: ?
Dec 23 20:15:50 <ikeX> Szamal : to bot ;)
%
#debian.pl
Dec 24 00:32:26 <vaiker> witam serdecznie, posiadam rrdtool 1.0.45 i lstat`a 
2.2 , wszystkie wykresy robi mi ok oprocz loadavg, skala wykresu zbiera dane, 
nawet sie dopasowuje do "wartosco" danych ktore ma wyswietlic ale ... nie 
rysuje czarnej linii na wykresie - co moze byc przyczyna ?
Dec 24 00:32:48 <LiNiO> vaiker: może się skończył czarny kolor? ;)
Dec 24 00:33:26 <vaiker> LiNiO: myslalem zeby dokupic czarny do monitora ale 
nie wiem gdzie sie wlewa
%
#debian.pl
Dec 25 12:47:27 <fEnIo> ale tyskacza piję i już mi lepiej ;)
Dec 25 12:47:38 <fEnIo> met: Tobie też polecam, bo cosik Ci humor nie dopisuje 
;P
Dec 25 12:48:18 <met> ;)
Dec 25 12:48:30 <met> przyślij w dcc :D
Dec 25 12:49:05 <fEnIo> z irssi wycieknie ;)
%
#debian.pl
Dec 26 01:56:04 <m_o_d> najgorsze jest to ze mialem w domu 2KB szynki
%
#debian.pl
Dec 29 20:42:12 <whitewolf> mnie jądra bolą ;)
Dec 29 20:44:51 <Junior> mnie jak zab bolal to go wyrwalem :)
%
#debian.pl
Jan 01 19:44:06 <LiNiO> ktoś chce czkoladke?
Jan 01 19:44:14 <tekmar> tak
Jan 01 19:44:32 <tekmar> 25 lat 175 cm wzrostu biust E ladna buzia .. taka 
czekoladke chce ;)
%
#debian.pl
Jan 01 20:19:56 <ghost212> czym sie rozni kernel 2.2 od 2.4 ??
%
#debian.pl
Jan 01 21:22:43 <LUKas007> moglby ktos dla mnie skompilowac kernel 2.4?
%
#debian.pl
Jan 03 12:58:06 <tekmar> http://chroot.debian.wonder.pl/ rzadzi ;)
Jan 03 12:58:57 <LiNiO> Warden: a widziałeś 
http://apache_segfaults.debian.wonder.pl ?
Jan 03 12:59:38 <met> tekmar :: rulez! :]
Jan 03 12:59:52 <LiNiO> i ktoś o slacka spytał ;)
Jan 03 13:00:13 <ikeX> no to http://slackware.debian.wonder.pl jemu.
Jan 03 13:03:06 <met> LiNiO :: to ja, to ja! :>
Jan 03 13:03:35 <met> chciałem pomyśleć o czymś idiotycznym i pierwsze co mi 
przyszło do głowy, to slackware ;)
%
#debian.pl
Jan 04 19:54:57 <Craig> Skopulowało mi się 2.6.0+ACPI
Jan 04 19:54:57 <Craig> Idę się bawić jajami
%
#debian.pl
Jan 06 13:05:31 <Izza> wlazla w swoje pudlo i w nim sie rozbijala
Jan 06 13:07:17 <BeerfaN> co kto lubi
Jan 06 13:07:33 <Izza> az pudlo z pingwinem polecialo:P
Jan 06 13:08:19 <BeerfaN> z pingwinem? :P
Jan 06 13:09:21 <Izza> nooo
Jan 06 13:09:28 <Izza> na pudle pingwin stoi:P
Jan 06 13:17:47 <BeerfaN> czy twoja kotka molestuje pingwina? ;P
Jan 06 13:20:33 <Izza> zdarza jej sie
Jan 06 13:20:58 <BeerfaN> hehe
Jan 06 13:21:03 <BeerfaN> a co na to pingwin?
Jan 06 13:21:12 <chsh> niemożliwe.
%
#debian.pl
Jan 07 12:29:03 <whitewolf> *** Twój system jest zbyt wolny! *** -- denerwuje 
mnie takie coś ;)
Jan 07 12:29:35 <BeerfaN> przywiaz go
Jan 07 12:29:41 <BeerfaN> bedzie troche mniej wolny
%
#debian.pl
Jan 08 03:08:19 <Jendrek> jaka jest najnowsza dziura na jajka 3.0?
%
#debian.pl
Jan 08 13:50:20 <fakepoo> kto jest spieprzony ?
Jan 08 13:50:21 <Buciorek> fakepoo: ja jestem ;)
%
#debian.pl
Jan 11 08:57:27 <VRANGEL> nie ma to jak rosyjskie, a najbardziej czeskie 
tłumaczenia..;)
Jan 11 08:58:27 <VRANGEL> juz nie wspomne o pddp :P
(pddp == Polish Debian Documentation Project)
%
#debian.pl
Jan 11 22:37:40 <gausus> czy ktos litosciwy moze wytlumaczyc Mariolk23 ze nie 
chce wiedziec jak wygladam
Jan 11 22:37:58 <VRANGEL> gausus, bo musisz byc brzydal//
%
#debian.pl
Jan 14 22:10:56 <Detroid> 22:00 -!- Borys [~borys@127.0.0.1] has quit [Kill 
line active:  ident is required (expires@never)]     ;-)
%
#debian.pl
Jan 16 13:46:24 <among> ja chce seriala
Jan 16 13:46:31 <among> do najnowszego nero
Jan 16 13:47:14 <korek> kup najnowszego nero to bedziesz mial seriala
Jan 16 13:47:25 <among> nie ma w sklepie
Jan 16 13:47:35 <BeerfaN> w sieci kup
Jan 16 13:47:45 <among> nie stac mnie
Jan 16 13:48:03 <jam> among: to sprzedaj nagrywarke, bedzie cie stac na nero :P
Jan 16 13:48:13 <among> jeszcze nie mam nagrywarki
%
#debian.pl
Jan 18 14:17:11 BeerfaN downloading DirectX for WIN2003 server family
Jan 18 14:18:18 <badspirit> BeerfaN: po co ci to ?
Jan 18 14:18:30 <badspirit> kolekcjonujesz wirusy ?
%
#debian.pl
Jan 18 15:00:29 <deviant> Verdan: osobiście jednak wątpię w te 10mbps za 300zł.
Jan 18 15:01:24 <BeerfaN> deviant  a moze to jakis przekret po prostu
Jan 18 15:01:56 <deviant> BeerfaN: może po prostu kolejna oferta typu "10mbps 
mamy" ;)
Jan 18 15:02:05 <deviant> a pod to 1000 klientów ;)
Jan 18 15:02:21 <BeerfaN> ej sam tak robilem ;P
%
#debian.pl
Jan 18 18:00:44 <Slowking> LiNiO, to nie ty masz 15 lat czy ty? nie ty? Bo ktos 
o podobnym nicku ma
%
#debian.pl
Jan 18 18:48:26 <szerszen_> pomoze mi ktos uruchomic mysz po USB pod linuxem 
2420??
Jan 18 18:48:59 <badspirit> trzeba cyba wetknac cos do dziurki co ? :P
Jan 18 18:49:20 <szerszen_> mysz mam podpieta pod monitor
Jan 18 18:49:21 <szerszen_> i nie dziala
Jan 18 18:49:23 <szerszen_> nie wiem czemu
Jan 18 18:49:28 <badspirit> szerszen_: a to ja tez nie wiem
Jan 18 18:49:45 <badspirit> moze podlacz do odkurzacza ?
%
#debian.pl
Jan 18 21:20:33 <LiNiO> wskaźnik, struktura, pole - skojarz to razem ;)
Jan 18 21:21:02 <Verdan> LiNiO: powoli, na razie udalo mi sie napisac program 
ktory zlicza sekundy w podanym okresie czasu, i to jeszcze w dodatku źle :P
%
#debian.pl
Jan 19 10:38:41 <jam_> badspirit: czyli nie masz ustawionego domyslnego 
routingu - nie ma prawa nic dzialac
Jan 19 10:41:54 <badspirit> jam_: jak to ustawic ?
Jan 19 10:43:31 <jam_> badspirit: route add default gw A.B.C.D dev ppp0
Jan 19 10:43:41 <badspirit> aaaaa :)
Jan 19 10:43:46 <jam_> badspirit: gdzie A.B.C.D to domyslna brama z dokumentacji
Jan 19 10:43:59 <badspirit> tej od sdi
Jan 19 10:44:14 <jam_> nie, tej od pralki automatycznej :P
%
#debian.pl
Jan 22 00:20:08 <krowa|spi> hej met co ci sie dzieje ?
Jan 22 00:21:57 <met> krowa|spi :: coś mi grdypie w mrzerzy.
Jan 22 00:22:39 <krowa|spi> :O
Jan 22 00:25:46 <met> krowa|spi :: a ty co dziś taki zmimszały?
Jan 22 00:25:59 <krowa|spi> zakarpiam sie w slebodziach
Jan 22 00:27:19 <met> aha... a musisz tak przy tym wierczeć?
Jan 22 00:28:29 <krowa|spi> probowalem wyrakiwac ale pleżetrzyny nie wytrzymuja
Jan 22 00:29:08 *** krowa|spi is now known as krowa|noc
Jan 22 00:29:26 <met> to weź boroglątwę, nie będzie ci przynajmniej ślibko.
Jan 22 00:30:18 <krowa|noc> pomki barajdy napomiano zatwardzę
Jan 22 00:31:29 met idzie do gulbieży.
%
#debian.pl
Jan 22 13:57:22 <krowa|wst> BeerfaN :: a ty powinienes byc 
beerfan!beerfan{beerfan)br
Jan 22 13:57:22 <krowa|wst> ;p
Jan 22 13:57:58 <BeerfaN> a ty krowa&tucows<pl
%
#debian.pl
Jan 23 01:11:43 <sniegol>  /wind sw 15
Jan 23 01:11:47 <sniegol> -.-
Jan 23 01:16:20 <SkyAce> klamiesz, u mnie wieje n 7 [km/h] ;)
%
#debian.pl
Jan 24 20:40:00 <Emiml> czy ktoś z żywych mógły zobaczyć to: 
http://192.168.1.10/test.mpg
%
#debian.pl
Jan 30 13:57:26 <Junior> Izza: <cmoook> :)
Jan 30 13:57:31 <Izza> Junior: <cmoooooooooooooooooooooook>
Jan 30 13:57:36 <Junior> wow
Jan 30 13:58:04 <Junior> takiego pieknego caluska to ja nawet od zony nie 
dostalem :)
Jan 30 13:58:04 <Izza> ?
Jan 30 13:58:13 <Izza> lepiej tak nie mow
Jan 30 13:58:22 <Junior> Hyhy
Jan 30 13:58:22 <deviant> zaraz dojdzie do rękoczynów
Jan 30 13:58:26 <deviant> lub zamiany par :>
Jan 30 13:58:52 <Junior> deviant: dlaczego nie, gdzie jest napisane ze ludzie 
sa monogamistami :)
Jan 30 13:59:09 <deviant> Junior: zostanie zapisane na Twojej twarzy jak żona 
się dowie o romansie :D
%
#debian.pl
Jan 30 22:04:04 <Uniks^> moze ktos sprawdzic w nslookup u siebie cos takiego
Jan 30 22:04:05 <Uniks^> 
3.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.b.e.5.0.e.e.0.8.e.f.f.3.ip6.int
Jan 30 22:04:25 <fEnIo> ja nie mogę, bo mam za wąski ekran
%
#debian.pl
Feb 01 14:22:55 *** SignOff: inch (inch&pd249[sieradz'sdi(tpnet~pl) i /exit 
siedzialy sobie na lawce. /exit sie wkurwilo i poszlo. Co zostalo ?
Feb 01 14:23:16 <Warden> lol.
Feb 01 14:23:18 <Warden> fajny reason.
Feb 01 14:23:29 *** inch (inch>pd249|sieradz&sdi,tpnet[pl) has joined #debian.pl
%
#debian.pl
Feb 03 20:40:39 *** Emiml (bb178686*irc?dialog]net_pl) has joined #debian.pl
Feb 03 20:40:46 <Emiml> cz
Feb 03 20:41:05 <Emiml> ma ktoś może płyte z nofrce2?
Feb 03 20:41:18 <Emiml> niezła porażka
Feb 03 20:42:23 <Emiml> mam sobie kernel 2.6, włązczyłem nagrywanie pytki 4x 
czyli 600kB/s. I teraz
hdparm -t pokazuje moc odczytu 4,3MB/s
Feb 03 20:42:45 <Emiml> normlanie (gdy nic nie robie) mam 50MB/s!
Feb 03 20:44:58 <Emiml> ktoś coś wie na ten temat? czy już mam sobie żyły 
podcinać?
Feb 03 20:46:06 <LiNiO> wynik jest ok
Feb 03 20:46:48 <LiNiO> mnożysz 4,3MB/s * wersja kernela * prędkość nagrywania 
i wychodzi dobrze
%
#debian.pl
Feb 04 15:34:45 <Unc> LiNiO: tzn touchpad mi dzialal ale wariuje
Feb 04 15:35:04 <LiNiO> mój jest normalny, nie wariuje
Feb 04 15:40:59 <Unc> LiNiO: nie dziala zawsze wraca mi do lewego dolnego rogu 
:(
Feb 04 15:41:23 <LiNiO> Unc: zrobiłeś wg opisu?
Feb 04 15:41:52 <Unc> tak
Feb 04 15:42:32 <Unc> dziala ladnie tylko co przesune i puszcze pada wraca mi 
do tego rogu
Feb 04 15:43:41 <LiNiO> a pod alternatywnym systemem jak sie zachowuje? ;)
Feb 04 15:44:31 <Unc> ?
Feb 04 15:44:44 <LiNiO> pod windą działa?
%
#debian.pl
Feb 06 11:27:02 <Izza> jest ktos kto potrafi mi odmowic i powiedziec spokoj! w 
dodatku bez konsekwencji:P
Feb 06 11:27:04 <Buciorek> Izza: ja jestem ;)
%
#debian.pl
Feb 12 15:35:15 <Averne> 100% 8==============================================D 
(_o_) 8,990,720    729.11K/s    ETA 00:00
%
#debian.pl
Feb 17 00:58:55 <cochese> "Załączam Nortona Commandera... Patrzę:
Feb 17 00:58:56 <cochese> Z prawej strony dysk C: , z lewej strony dysk C:,
Feb 17 00:58:56 <cochese> Myślę sobie: 'Kurwa ! po co mi dwa dyski C:
Feb 17 00:58:56 <cochese> więc jeden sobie sformatowałem.' "
%
#debian.pl
Feb 17 12:32:35 <evilzolw> ale normlanie zaraz urządze sobie Drzemkę 
administratora (tm)
Feb 17 12:33:14 <BeerfaN> hehe
Feb 17 12:33:28 <_phantom_> dobry pomysł. też idę się zdrzemnąć. bbl.
Feb 17 12:33:30 <BeerfaN> musisz najpierw dla szefa zarzucic patch na oczy
Feb 17 12:33:33 <BeerfaN> ;)
Feb 17 12:33:38 <evilzolw> Ó.
Feb 17 12:33:39 <BeerfaN> co by cie nie przyuwazyl
Feb 17 12:33:44 <evilzolw> Raczej bym mu musiał jądra przekompilować.
%
#debian.pl
Feb 17 22:13:36 <Averne> apt-get install `cat /dev/urandom`
%
#debian.pl
Feb 18 21:27:32 <LiNiO> dzwońcie pod różową linię 96-69-96 ;)
Feb 18 21:27:59 <deviant> dzwońcie pod czerwoną : 666
%
#debian.pl
Feb 19 09:16:52 <Lamagra> abuuu - string sie nie chce nałożyć na kernel :(
Feb 19 09:17:16 <Lamagra> stringi do jąder nie pasują? :>
%
#debian.pl
Feb 19 19:46:02 <LiNiO> _cX_: ja na dysku 185MB miałem woody, x-y i gnome 1.4 ;)
Feb 19 19:46:53 <snp^> i dwa ripy DVD :P
%
#debian.pl
Feb 23 14:42:44 <ikuko> ;>
Feb 23 14:43:19 <masklin6> :>
Feb 23 14:43:29 <defunct> :|
Feb 23 14:44:00 <ikuko> nie krzyw mordki :D
Feb 23 14:44:15 <BeerfaN> moze ma plaskogebie
%
#debian.pl
Feb 25 00:46:37 <deviant> pamiętam, jak idzie sobie koleś, tobra baterii i mu 
się otworzyła, baterie wyleciały , no to on przykucnął i je zbiera
Feb 25 00:46:41 <deviant> podchodzi gość - Co pan robi?
Feb 25 00:46:44 <deviant> - ładuję baterie
Feb 25 00:46:50 <deviant> - tak? to ja je panu wyładuje
Feb 25 00:46:56 <deviant> i jeb, wywalił mu wszystkie :D
%
#debian.pl
Mar 06 14:21:06 <m_o_d> jak sobie radzicie z uzytkownikami uzywajacymi flash 
get ?
Mar 06 14:21:13 <m_o_d> esfq sobie z tym radzi ?
Mar 06 14:21:52 <met> m_o_d, MaxClientsPerHost 2
Mar 06 14:22:15 <m_o_d> met w iptables to walisz?
%
#debian.pl
Mar 09 23:17:43 <SpoonMan> dzis slyszalem fajna instrukcje obslugi Torrenta pod 
windows
Mar 09 23:17:47 <SpoonMan> cytuje:
Mar 09 23:18:01 <SpoonMan> "cos tam poklikaj a jak zwisnie to kompa zrestartuj"
%
#debian.pl
Mar 13 17:39:56 <studik> ehlo
Mar 13 17:41:01 <studik> mam pytanie .. czy do /proc mozna dodawac swoje pliki ?
Mar 13 17:41:16 <MichalZ> studik:  nie a bynajmnij nie normalnie
Mar 13 17:41:47 <studik> hmm a jakos nienormalnie ? oczywscie bez edycji jadra
Mar 13 17:41:54 <met> napisać moduł ;)
Mar 13 17:42:31 <studik> bo mam sobie usluge ... dokladnie hub direct  connecta
Mar 13 17:42:44 <studik> i chcialbym umieszczac gdzies chwilowe statsy huba ...
Mar 13 17:43:02 <studik> ilosc podlaczonych userkow .. kilka zmiennych 
wewnetrznych ...
Mar 13 17:43:12 <studik> i tak najbardziej to by mi /proc pasowal
Mar 13 17:43:22 <met> lol. :D
Mar 13 17:44:10 <studik> glupi pomysl ?
Mar 13 17:44:13 <daymond_> studik: a dlaczego do /proc?
Mar 13 17:44:24 <daymond_> studik: daj do /dev/null tez ciekawe miejsce ;)
%
#debian.pl
Mar 15 21:42:03 <Tomak_Rlz> mam pyutanko, czym sie rozni SSL od SSH
Mar 15 21:42:17 <Tomak_Rlz> bo zarowno w jednym jak i w drugim mozna robic 
tunele
%
#debian.pl
Mar 22 15:46:50 <Izza> 
http://wiki.wonder.pl/index.php/DziadyVhttp://wiki.wonder.pl/index.php/DziadyV
Mar 22 15:46:54 <Izza> ~""""""""""""""""""&*?~~~~~~~1~gtf
Mar 22 15:48:05 <Izza> przepraszam, kot wlazl na klawiature
Mar 22 15:48:31 <xterm> Izza: masz kota z szyfratorem RSA? ;)
%
#debian.pl
Mar 23 14:28:59 <GrUbBeR> LiNiO: probowałeś nagrywać cdrecord dvd?
Mar 23 14:29:51 <LiNiO> GrUbBeR: nie, ale jak kupisz mi nagrywarkę DVD to 
obiecuję że spróbuję ;)
%
#debian.pl
Apr 03 11:06:08 MadCow^ siedzial do 6 zeby zainstalowac postgresa ... i 
zainstalowal xmame tylko :)
%
#debian.pl
Apr 04 18:39:12 <kaczy> a jak to jest z tym Linuksem dla commodore ?
Apr 04 18:39:42 <y0> no jak to jak 7 kaset
%
#debian.pl
Apr 05 15:13:26 <B4rt_> go to www.[----].afraid.org and click jennifer ;)
Apr 05 15:14:51 *** mode #debian.pl "+b *!*b4rt@*.33.udn.pl" by fEnIo
Apr 05 15:14:51 *** B4rt_ kicked off from #debian.pl by fEnIo (go to hell and 
click devil)
%
#debian.pl
Apr 06 17:19:30 <natan4> jak donosza najnowsz ebadania 60 procent mlodziezy 
jest zadowolona z zycia a reszta czyli 40 procent nie stac na narkotyki
%
#debian.pl
Apr 15 13:50:47 <ziomall> czy jest kots na # kto sie zna srednio-dobrze na "c" 
pod unixem ..... ?
Apr 15 13:51:06 <ziomall> bo pisze sobie program konik szachowy i grafika mi 
nie dziala
Apr 15 13:51:19 <Jubal> no to masz zagwozdkę, kurna
%
#debian.pl
Apr 16 20:36:52 <MadCow^> mam do was pytanie, co zrobic jak zmienilem 
ustawienia w lanie i przekierowalem wszystkim www na stronke z opisem co i jak 
pozmieniac (po zmianach www chodzi juz) a tu przychodzi pacjent i pyta czemu 
nie ma neta tylko jakies ogloszenie sie pojawia! ?
Apr 16 20:37:31 <SkyAce> MadCow^: zastrzel go
Apr 16 20:37:33 <MadCow^> z okna go nie wyrzuce bo spadajac bedzie mi sie kabli 
lapal...
%
#debian.pl
Apr 16 23:47:28 <ikuko> więcej grzechów nie pamiętam
Apr 16 23:48:47 <MadCow^> Grzechów :)
Apr 16 23:49:05 <ikuko> ;p
Apr 16 23:49:15 <MadCow^> ikuko :: Lubujesz w Grzegorzach ?
%
#debian.pl
Apr 18 01:39:38 <m_o_d> jesli przechyla sie glowe bo gdy patrzy sie an motor to 
cos sie krecic zaczyna to oznaka zmeczenia?
%
#debian.pl
Apr 18 16:04:34 <speedo> jesli zablokuje sie zmiane suida w jajku a jajko jest 
dziurawe to da sie to obejsc ?
%
#debian.pl
Apr 18 18:44:00 <[bazyl]> fuj
Apr 18 18:44:41 <[bazyl]> walczę z oraclem :P
Apr 18 18:44:47 <[bazyl]> na solarisie łatwiej mi się go instalował ;]
Apr 18 18:44:52 <LiNiO> za core go ;)
%
#debian.pl
Apr 20 19:55:16 fEnIo is gone: halówka
Apr 20 19:55:25 <BeerfaN> dzis pija na hali ;)
%
#debian.pl
Apr 21 21:38:44 <shouter> soczek: jak zamontowac partycje fat
Apr 21 21:39:05 <SpoonMan> shouter ::  man mount
Apr 21 21:39:25 <shouter> SpoonMan: i to wszystko
Apr 21 21:39:26 <shouter> ?
%
#debian.pl
Apr 22 07:14:13 <MichalZ> met:  tak ogolnie gdybys nie logowal sie na shelle to 
mozna stwierdzic ze jeste BOT :>
%
#debian.pl
Apr 25 16:52:42 <GrUbBeR> ^pawel: dopisz dsię do grupy audio.
Apr 25 16:53:30 <^pawel> Gruber: co to dsi ? chodzi Ci moze o  dsp ?
%
#debian.pl
Apr 26 12:59:30 <natan4> mandzur to robka wygryzajacy mog osoba ktore pala 
nadmiernie marichuane
Apr 26 12:59:47 <BeerfaN> natan ty to chyba jestes megamandzur
%
#debian.pl
Apr 26 22:19:37 <fEnIo> ta strona z informacją, że nie płaci jest na tym 
routerze czy gdzie indziej?
Apr 26 22:19:52 <Daymond> fEnIo: na tym samym.
Apr 26 22:20:09 <fEnIo> no to -j REDIRECT <sam port na którym jest ta strona 
bez ip>
Apr 26 22:20:23 <fEnIo> a --dport ma być tylko 80
Apr 26 22:20:32 <Daymond> fEnIo: dobrze, ale ja tam mam klasę IP ;>
Apr 26 22:20:41 <fEnIo> jaką znowu klasę?
Apr 26 22:20:43 <Daymond> fEnIo: i to nie jest na tym samym IP, na routerze tak 
:>
Apr 26 22:20:55 <fEnIo> chłopie idź to rozrysuj w Gimpie, bo ja nie wiem o co 
chodzi
%
#debian.pl
May 01 15:19:58 <jooik> mam pytanie
May 01 15:20:04 <jooik> co jest lepsze smtp czy imap?:)
%
#debian.pl
May 02 23:28:07 y0 słuch radia fb http://195.117.38.220:6970
May 02 23:28:49 <BeerfaN> radio framebuffer?
May 02 23:28:52 <BeerfaN> to chyba nie dziala
May 02 23:28:53 <BeerfaN> ;P
May 02 23:29:04 <fEnIo> pewnie się gryzie z nvidią ;)
%
#debian.pl
May 05 20:34:17 <BeerfaN> jest jakis zwrot w angielskim na 'gdy na to patrze to 
przezywam tamte chwile' ?
May 05 20:37:03 <soczek> yep, o fuck!
%
#debian.pl
May 09 01:20:33 <maciek-> Mam problem. Pomożesz?
May 09 01:20:46 <ikuko> jaki ?
May 09 01:21:03 <maciek-> zaatakuje na prv
May 09 01:22:06 <ikuko> a w ryj nie chcesz ?
May 09 01:24:48 <maciek-> Nie.
May 09 01:24:56 <maciek-> Dzięki za pomoc ;))
%
#debian.pl
May 09 19:41:51 <ike> "A kiedy szedł Pan Administrator zobaczył on 
użytkowników, co się znęcali nad jednym słabszym z nich. Ujrzeli oni Pana 
Administratora i nagabywali 'Wyloguj go! Wyloguj!'. A administrator zalatywał 
BOFHem i wylogował ich wszystkich. I wiedział, że tak było łatwiej..."
%
#debian.pl
May 18 18:54:45 <ikuko> ide sie kapac ;)
May 18 18:54:49 <natan4> ?
May 18 18:55:31 <Cvbge> wykapany ojciec? ;)
May 18 18:55:39 <ikuko> :D
May 18 18:55:42 <Cvbge> ja sie wole tryskac ;)
%
#debian.pl
May 19 23:32:48 <szkrabek> narazie
May 19 23:32:48 *** szkrabek kicked off from #debian.pl by met (na razie)
May 19 23:32:49 *** szkrabek (szkrabek<pa76\andrespol[sdi%tpnet`pl) has joined 
#debian.pl
May 19 23:33:00 <szkrabek> hmmm
May 19 23:33:02 <szkrabek> narazie
May 19 23:33:03 *** szkrabek kicked off from #debian.pl by met (na razie)
May 19 23:33:04 *** szkrabek (szkrabek(pa76|andrespol\sdi[tpnet%pl) has joined 
#debian.pl
May 19 23:33:06 <szkrabek> cool ;]
May 19 23:33:13 <szkrabek> narazka
May 19 23:33:16 <szkrabek> ueee
May 19 23:33:19 <szkrabek> goopi skrypt
May 19 23:33:19 *** szkrabek kicked off from #debian.pl by met (głupi)
%
#debian.pl
May 22 21:55:14 <paramah> wracając do sprawy smyczy to polecam bardzo ładnie 
wykonane :-) tylko nie wiem co se na niej bede nosic :D
May 22 21:55:31 <paramah> kluczy mam za duzy pąk :|
May 22 21:59:14 <ShadoWW> Bedziesz trenowal karczycho.
May 22 21:59:21 <ShadoWW> Taka mini silownia ;)
May 22 22:00:01 <paramah> ;)
May 22 22:00:15 <paramah> myslałem o cd z debianem :D
May 22 22:00:39 <paramah> podobno dziala jak anty radar wiec jak bede biegac po 
ulicach to mnie nie zlapią :P
May 22 22:00:45 <paramah> hahahaha
May 22 22:00:50 <ShadoWW> hhehehehe
May 22 22:00:51 <ShadoWW> ;>
May 22 22:01:57 <paramah> a może jak juz siłownia to ja mysle ze cegła będzie 
spoko :D jak MichalZ zrobi cegły z debkiem to pomysle :D
%
#debian.pl
May 25 19:32:25 <Selektor> ktorym poleceniem badalo sie wersje oprogramowania 
na skanowanym serwerze?
%
#debian.pl
May 27 09:34:25 <fEnIo> ładnie goście zaatakowali z kosiarkami
May 27 09:34:33 <fEnIo> muszę okno zamknąć, bo Was nie słyszę
May 27 09:34:38 <Averne> hehe ;-)
May 27 09:34:41 <Averne> golą trawnik?
May 27 09:34:52 <fEnIo> jeszcze nie wiem bo mi się wstać nie chce ;)
May 27 09:39:07 <fEnIo> ooo... piękna ekipa
May 27 09:39:15 <fEnIo> ze 6 osób i samochód desantowy marki Żuk
May 27 09:39:35 <fEnIo> jakaś zorganizowana akcja
May 27 09:40:10 <fEnIo> pewnie się dowiedział burmistrz, że po południu 
wychodzę z domu i chłopaki przygotowują mi teren ;)
%
#debian.pl
May 27 09:41:14 <Averne> padł dynamiczny ruting na skrzyżowaniu
%
#debian.pl
May 29 16:05:24 <uszek> jak probuje kompilowac kadu to wyskakuje mi bład ze nie 
znaleziono gwidget.h
May 29 16:05:32 <met> to go nie kompiluj
May 29 16:06:09 <uszek> ???
May 29 16:06:12 <uszek> :|
May 29 16:07:07 <uszek> eh
May 29 16:07:11 <uszek> fajna mi pomoc
May 29 16:07:13 <uszek> dzieki
May 29 16:08:01 <met> nie ma sprawy.
May 29 16:08:12 <met> jak będziesz jeszcze potrzebował pomocy, to wiesz kogo 
zapytać.
%
#debian.pl
May 30 01:12:53 <y0> co to za patch?
May 30 01:13:09 <djbanan> y0 z wersji 2.4.18 na 2.4.26
May 30 01:13:17 <djbanan> i patch gtksecurity
%
#debian.pl
Jun 01 18:49:32 <brodatty> gdzie czytalem fajny kawalek - echo "ciszej tam" > 
/dev/wentylatorki/od/procka (chodzilo zmniejszenie predkosci wentylatora) :-)
%
#debian.pl
Jun 20 15:05:51 <pepson> Witam czy ktoś mi wyjasni jak uruchomic nagrywarke pod 
GRUB
Jun 20 15:06:03 <pepson> mialem lilo i dzialalo teraz mam GRUB i kicha
%
#debian.pl
Jun 23 19:41:16 <natan4> co to jest roputer
Jun 23 19:41:36 <BeerfaN> nie mam pojecia
Jun 23 19:41:45 <BeerfaN> cos z ropuchami chyba zwiazane
Jun 23 19:41:47 <ikuko> ;P
Jun 23 19:41:48 <natan4> no
Jun 23 19:41:49 <SkyAce> pewnie jakieś połączenie ropuchy z routerem
%
#debian.pl
Jun 24 13:38:41 <Kacperek_> jak wysiwetlic liste zaproszonych na kanale?
Jun 24 13:38:52 <natan4> ./signoff list
Jun 24 13:39:05 *** SignOff: Kacperek_ (kacperek[blabluga#hell\pl) "list"
(...)
Jun 24 13:41:07 *** kacperek (kacperek|blabluga?hell]pl) has joined #debian.pl
Jun 24 13:41:15 <natan4> kacperek co ty zrobiles ?
Jun 24 13:41:18 <natan4> a gdzielista kanalu
Jun 24 13:41:26 <natan4> lista kanalu a nie sama lista
Jun 24 13:41:36 <natan4> ./signoff list #debian.pl
Jun 24 13:41:48 <natan4> albo jakis twoj
Jun 24 13:41:49 <natan4> :)
Jun 24 13:41:55 <kacperek> acha :D
Jun 24 13:41:58 <natan4> ludzie helpa nie czytaja
Jun 24 13:42:05 *** SignOff: kacperek (kacperek?blabluga}hell(pl) "list 
#debian.pl"
%
#debian.pl
Jun 28 20:31:22 <Noth> ikuko: grasz? ;>
Jun 28 20:31:35 <ikuko> Noth :: ucze sie
Jun 28 20:32:00 <Noth> ikuko: popracuj nad multitaskingiem ;)
%
#debian.pl
Jun 29 18:33:24 <natan4> zazenia
Jun 29 18:33:33 <natan4> zdażenia ?
Jun 29 18:33:43 <met> rz
Jun 29 18:33:51 <BeerfaN> zdĄŻenia zdaRZenia
Jun 29 18:34:19 <natan4> obustronne ?
Jun 29 18:34:23 <natan4> obu stronne ?
Jun 29 18:34:27 <natan4> :D
Jun 29 18:34:30 <BeerfaN> obustronne
Jun 29 18:34:34 <natan4> leprze niz google
Jun 29 18:34:35 *** natan4 kicked off from #debian.pl by met (lepsze)
%
#debian.pl
Jul 01 22:17:58 <gogo> CZECHY MUSZĄ WYGRAĆ!!! Jak nie to mój kolega zrucha moją 
dziewczynę!
%
#debian.pl
Jul 02 19:50:56 BeerfaN stwierdza ze upgrade woody->sarge na sdi jest bolacy
Jul 02 20:06:04 <badspirit> beerfan: wcale nie :)
Jul 02 20:09:55 <BeerfaN> 5h
Jul 02 20:09:59 <BeerfaN> ;)
Jul 02 20:12:02 <fEnIo> Zainstaluj Gentoo. Będziesz tyle czekał na byle gówno ;)
%
#debian.pl
Jul 02 23:01:59 <Daymond> fEnIo: jak optymalnie powinien być ustawiony squid?
Jul 02 23:02:12 <fEnIo> Daymond: ołtarzem na zachód
%
#debian.pl
Jul 05 14:50:12 <ikuko> xcxc :: #5,0
Jul 05 14:50:13 <ikuko> ;-)
Jul 05 14:50:23 <xcxc> ta
Jul 05 14:50:38 <xcxc> lcamtuf to cwel wymyslil to
%
#debian.pl
Jul 06 22:32:55 <darkjuice> zostałem temlariuszem
Jul 06 22:32:56 <darkjuice> :)
Jul 06 22:33:06 <BeerfaN> znaczy /temp/lariuszem
%
#debian.pl
Jul 08 12:03:33 <MaReK^-^> a ide na slonce :)
Jul 08 12:04:35 <fEnIo> MaReK^-^: ludzie dopiero księżyc zaliczyli, parę sond 
na Marsie, a Ty tak po prostu na słońce uderzasz? :P
%
#debian.pl
Jul 09 15:03:08 <K3NY> w /etc/security/limits.conf "data" to tos amo co quota?
%
#debian.pl
Jul 09 21:28:25 <DT> nie ma sie co oszukiwac, wszyscy mamy ten sam problem - 
uzytkownikow
%
#debian.pl
Jul 12 11:29:40 <kaczy> ach.. coz to byla za noc.. tylko ja i ona. jedynie ona 
i ja... :
Jul 12 11:30:00 <kaczy> tylko na koncu troche przegiolem chyba.. bo powietrze 
wyszlo ;)
%
#debian.pl
Jul 12 12:20:47 <tekmar> met: wlasnie mula odpalilem ...
Jul 12 12:20:54 <tekmar> i sie zalamalem .. jakies kolejki itp
Jul 12 12:20:56 <met> do pojedynczych mp3?
Jul 12 12:20:58 <met> za wolny
Jul 12 12:21:02 <tekmar> met: do albumow
Jul 12 12:21:10 <tekmar> ja chce cale plytki ...
Jul 12 12:21:10 <met> a, to już trochę inna rozmowa
Jul 12 12:21:18 <tekmar> posluchac jak mi sie spodoba kupic ;)
Jul 12 12:21:25 <tekmar> hehe czy jakos tak
Jul 12 12:21:26 <met> yeah :)
Jul 12 12:21:37 <deviant> że też ludziom się nic nie podoba ;)
%
#debian.pl
Jul 14 14:46:01 <natan4> co z piatkiem ?
Jul 14 14:46:15 <BeerfaN> bez zmian, jest pojutrze
%
#debian.pl
Jul 15 10:56:59 <dredzik> arystokle, na przykład możesz to dodać w 
/etc/init.d/networking gdzieś w sekcji start
Jul 15 10:58:56 <arystokle> dredzik: co znaczy na przyk
Jul 15 10:59:48 <dredzik> na przykład znaczy na przykład. w szkole cię nie 
uczyli?
%
#debian.pl
Jul 16 12:36:14 <dredzik> natan4, przez jakiś czas miałem ptasznika w terrarium
Jul 16 12:37:38 <ikuko> to gorsze od freebsd
%
#debian.pl
Jul 16 14:37:27 *** Krzyshtof (+r@avz220.neoplus.adsl.tpnet.pl) has joined 
#debian.pl
Jul 16 14:37:38 Krzyshtof goes away. i'm back.
%
#debian.pl
Jul 19 19:23:02 <natan4> kliknij na link powyzej
Jul 19 19:23:11 <fEnIo> klikałem jak byłem mały
%
#debian.pl
Jul 20 01:09:11 <LiNiO> dzisiaj moje dziecko coś mowi i na końcu: i koniec, 
kropka, pe-el ;)
Jul 20 01:12:21 <m_o_d> LiNiO: a ile ma lat?
Jul 20 01:13:13 <LiNiO> 4,5
%
#debian.pl
Jul 20 13:01:26 <fEnIo> wypijmy za błędy... za błędy w pisowni
%
#debian.pl
Jul 22 18:14:50 <fEnIo> From: Aukcje <mailing@interia.pl>
Jul 22 18:14:51 <fEnIo> To: Odbiorca mailingu <users@interia.pl>
Jul 22 18:14:51 <fEnIo> Subject: Wyprzec innych!
Jul 22 18:14:56 <fEnIo> niech się sami wyprą
%
#debian.pl
Jul 23 20:44:20 y0 po 1,5 roku został zmuszony do zainstalowania windy i się 
gubi ;P
Jul 23 20:45:06 <voti> y0 "tak" "tak" "tak" "tak" "tak" "tak"
Jul 23 20:45:08 <voti> i gotowe
%
#debian.pl
Jul 26 21:41:32 <arek_k> czy mozna odzyskacz dane usuniete z dysku system 
linux, fs ext2 usuniete dane zostaly z mc
Jul 26 21:42:13 <fEnIo> Polecenie -> Odtwórz pliki (tylko ext2fs)
Jul 26 21:42:16 <fEnIo> masz takie cosik w mc
Jul 26 21:42:35 <fEnIo> z tym, że na zbyt wielką skuteczność bym raczej nie 
liczył
Jul 26 21:46:14 <arek_k> a linux usuwa pliki od razu z dysku czy przenosi je 
gdzies??
Jul 26 21:49:41 <fEnIo> przenosi... poszukaj w /dev/null
Jul 26 21:51:53 <arek_k> a gdzie zamontowac /dev/null??
Jul 26 21:52:04 <fEnIo> obok /dev/urandom
%
#debian.pl
Jul 27 14:18:34 <natan4> nigdzie nie widze dodaj nowego usera
Jul 27 14:19:00 <ikuko> bo to jest po angielsku
%
#debian.pl
Jul 27 19:55:22 <soczek> +b *!*natan*@* proszę ;)
Jul 27 19:56:19 <Cvbge> natana proszę teraz nie denerwować, bo on ma moje 
pieniądze ;)
%
#debian.pl
Jul 27 20:19:37 <DelUser> Proszę  nie wzywać imienia pana Boga nadaremnie.
Jul 27 20:19:43 <DelUser> Podświetla mi się kur**.
%
#debian.pl
Jul 29 17:56:12 <soczek> szukam roboty za 5000 PLN netto... ktoś nie jest 
przypadkiem pod wpływem większej ilości gotówki? :^)
Jul 29 17:58:43 <LiNiO73> ja szukam za 100.000 PLN brutto
Jul 29 17:58:47 <LiNiO73> oferty na priv ;)
Jul 29 17:59:00 <soczek> :D
Jul 29 17:59:15 <methody> Nie uwierzycie, to samo mi po glowie chodzi
Jul 29 17:59:16 <methody> ;)
Jul 29 17:59:16 <LiNiO73> ale zastrzegam sobie prawo odrzucenia ofert bez 
podania przyczyny ;)
Jul 29 17:59:30 <soczek> hehehe
Jul 29 18:00:01 <LiNiO73> już mam nawet list motywacyjny: "najlepiej motywuje 
mnie pensja w wysokości 100.000 PLN + premia uznaniowa"
Jul 29 18:00:18 <dredzik> rotfl
Jul 29 18:00:34 <LiNiO73> no bo jakbym się opierdzielał
Jul 29 18:00:39 <LiNiO73> to niech nie będzie tej premi
Jul 29 18:00:44 <LiNiO73> przeżyje to jakoś ;)
%
#debian.pl
Jul 30 00:55:36 <Rzepa> vim jest smieszny (-;
Jul 30 00:55:57 <ike> jak sie mocno spijesz albo spalisz to nawet mlotek jest 
smieszny.
%
#debian.pl
Jul 30 13:07:50 <ikuko> wez bo cie tam przeciagne za koniem po tej skawinie
Jul 30 13:07:51 <ikuko> ;p
Jul 30 13:08:02 <BeerfaN> za malego masz konia zeby tam dojechac
%
#debian.pl
Jul 30 18:36:31 <natan4> zastanawiam sie czy zrobic w rewie lazanie dla plesu 
bo nie wiem czy ich kupki smakowe sa na tyle roziwniete zeby pojac ten smak
Jul 30 18:36:44 <BeerfaN> kupki rotfl
%
#debian.pl
Aug 02 15:17:50 <natan4> no objadek zrobiony
Aug 02 15:17:54 <natan4> kurczak ala natan
Aug 02 15:18:07 <natan4> w sosie hm nazwijmy go test-rc2
%
#debian.pl
Aug 02 17:16:11 <kapibara> czy ktos ma pomysl jak podlaczyc ups do kompa a 
wlasciwie kompa do upsa tak zeby go nie wylaczyc? ;)
%
#debian.pl
Aug 04 23:45:22 <fEnIo>  /WOJS Greyer-q
Aug 04 23:45:24 <fEnIo> 23:44 -A- Irssi: Unknown command: wojs
Aug 04 23:45:27 <BeerfaN> fEnIo: /poczestuj Greyer-q
Aug 04 23:45:29 <fEnIo> eee... coś ściemniacie
Aug 04 23:45:30 <BeerfaN> ;)
Aug 04 23:45:38 <LiNiO> fEnIo: masz popsute irssi ;)
Aug 04 23:45:57 <LiNiO> fEnIo: a próbowałeś /disco Greyer-q ? ;)
Aug 04 23:46:05 *** SignOff: fEnIo (~fenio@on.debian.linux.org.pl) "leaving"
%
#debian.pl
Aug 05 11:19:49 <natan4> feni0 jest plan
Aug 05 11:19:52 <natan4> sprzedaj butelki
Aug 05 11:20:02 <natan4> i masz na zlot i na samochod i na dom
Aug 05 11:20:03 <natan4> :)
Aug 05 11:20:13 <fEnIo> za kasę z butelek piłem 2 tygodnie temu
Aug 05 11:20:13 <natan4> i na super servery
Aug 05 11:20:19 <natan4> i na lacze sto megabitow do domu
Aug 05 11:20:22 <natan4> a
Aug 05 11:20:32 <natan4> no to moze chcociaz starczy na samolot maly teraz
Aug 05 11:20:33 <natan4> :)
%
#debian.pl
Aug 12 08:51:26 <dredzik> BeerfaN, no cóż idiotów trzeba znosić bo na kimś 
trzeba zarabiać.
%
#debian.pl
Aug 25 21:05:13 <piotreq`> wiecie co mi sie rzucilo w oczy? ze nie mam nawet 
gcc zainstalowanego a wszystko instaluje apt-getem i dziala
%
#debian.pl
Aug 27 23:28:38 <ikuko> aDek_ zaslonimy slonce i bedziemy sprzedawac swiatlo w 
butelkach z filtrem uv
%
#debian.pl
Aug 28 19:11:07 <natan4> gadam na gg z jakas religijna fanatyczka
Aug 28 19:11:08 <natan4> hm
Aug 28 19:11:11 <natan4> ale nioc to
Aug 28 19:11:12 <natan4> ale nic to
Aug 28 19:11:18 <natan4> mowi mi cos tam o proroku natan
Aug 28 19:11:23 <natan4> i ze natan to cos tam znaczy
Aug 28 19:11:26 <natan4> :)
Aug 28 19:12:39 <fEnIo> spytaj jej czy ma cipkę wygoloną
Aug 28 19:12:42 <fEnIo> najczęściej pomaga
%
#debian.pl
Sep 03 22:52:34 <GrUbBeR> Czy to możliwe, że dzwonią z TPSA, że przyjadą z 
modemem DSL, a później mówią, ze nie ma warunków technicznych, żeby tego DSL'a 
zamontować?!?!!
%
#debian.pl
Sep 16 13:04:08 <fEnIo> odzajączkować się ode mnie proszę ;P
Sep 16 13:04:19 BeerfaN sie przyjeża do fEnIa
Sep 16 13:04:54 dygi skrecikowal sie
Sep 16 13:05:01 <dygi> zeby nie powiedziec skretynial ;P
%
#debian.pl
Sep 16 15:16:09 <GrUbBeR> fine reader - mam go, ale nie pełną wersję i się 
pluje o seriala, crackowac się go nie da.
Sep 16 15:16:12 <GrUbBeR> :>
Sep 16 15:16:22 <fEnIo> nie da to się nagiemu do kieszeni nasrać
%
#debian.pl
Sep 20 15:19:28 <ZakSzirak> a co to znaczy jak access point mruga diodka od 
wlan a administrator wyjechal za granice
Sep 20 15:20:20 <LiNiO> że tęskni za nim
%
#debian.pl
Sep 22 21:52:51 <Gitarka> prosze panstwa mam pid procesu-dzieciaka jak sie 
dowiedziec jaki jest pid
ojca
Sep 22 21:53:11 <Gitarka> tylko nie mowcie zebym sprawdzil grupe krwi...
%
#debian.pl
Sep 24 13:50:46 <Eyck> leeloo to jest jakies mlode? czy to taka poza 'slodka 
idiotka'?
Sep 24 13:51:01 <leeloo_ft> Eyck: :*
%
#debian.pl
Sep 26 14:10:51 <wiedzmin_> dialog rządzi, dialog radzi, dialog w g..no cię 
wprowadzi!
%
#debian.pl
Sep 29 11:10:16 <Eyck> hmm, ciekawe, sasiadka ktora jest we mnie wpieta juz 
smiga... a moj komputer
ciagle lezy,
Sep 29 11:15:44 <_`VadeR`_> lol
Sep 29 11:16:02 <_`VadeR`_> to juz sasiadki sie wpinaja ;o)
Sep 29 11:16:39 <BeerfaN> tak to sie teraz nazywa
Sep 29 11:16:39 <BeerfaN> ;)
Sep 29 11:18:58 <Izza> :PPP
Sep 29 11:19:30 <dopedoll> :O
Sep 29 11:19:42 <tekmar> Eyck: odepnij sie od sasiadki
Sep 29 11:20:37 <BeerfaN> wepnij siebie w jej port i zobacz czy poleca pakiety
%
#debian.pl
Sep 29 21:49:04 <natan4> czy spamassassin sie sam uczy ?
Sep 29 21:51:22 <krowica> natan4 musisz mu kupic ksiazki
%
#debian.pl
Sep 30 09:49:15 <fEnIo> większość znajomych opowiada niestworzone historie o 
ich dziekanatach, a u nas są panienki uprzejme i w dodatku w wieku tartacznym
Sep 30 09:49:30 <krowica> tartacznym
Sep 30 09:49:34 <krowica> ?:O
Sep 30 09:49:41 <fEnIo> no do rżnięcia się nadają ;P
%
#debian.pl
Oct 04 20:26:24 *** Stevie__ (stevie@wonder.pl) has joined #debian.pl
%
#debian.pl
Oct 04 22:57:46 <irx> no nie mowcie, ze w domu na sprzecie macie wersje stable 
: >?
Oct 04 22:57:57 <Unc> irx: a moze mamy windowsy
Oct 04 22:58:20 <Unc> irx: albo mendrake lub knoppixy
Oct 04 22:58:22 <irx> no windowsy jeszcze nie wyszly w wersji stable : >
%
#debian.pl
Oct 12 09:49:38 <e1337on3> zna sie ktos su an debianie ? ;)
Oct 12 09:50:03 <kaczy> e1337on3: no cos Ty, pewnie ze nie ;)
Oct 12 09:51:17 <e1337on3> eee to dupa zbita ... bo szukam kogos kto zna 
potencjalne kruczki odnosnie popyhania sieciowego w tym systemie
%
#debian.pl
Oct 13 17:17:58 <natan4> jak myslisz gdybym tam znalazl to o comi chodzi to bym 
znowu zadawal pytanie ?
Oct 13 17:18:22 <Aqq> natan4: znajac Ciebie to TAK
Oct 13 17:18:33 <Aqq> bo jestes upierdkiwiec
%
#debian.pl
Oct 14 15:40:16 <natan> swinki z pg zablokowaly wyjscia na swiat innym serverom 
niz servery uczelniane
Oct 14 15:40:26 <natan> i teraz zeby wbic sie na piwo musze najpierw przez 
server uczelniany ble
Oct 14 15:40:31 <natan> ale na pinga odpowida
Oct 14 15:40:51 <natan> mozna przekierowac cos icmp tak zeby wpuszczal po 22 ?
%
#debian.pl
Oct 17 17:27:46 <BuBi`> 27051 ?        DW     0:31 [apache]
Oct 17 17:27:47 <BuBi`> 29727 ?        Z      0:01 [apache <defunct>]
Oct 17 17:27:55 <BeerfaN> o ho
Oct 17 17:27:58 <BeerfaN> kolega zombie hoduje
Oct 17 17:27:58 <BuBi`> tych Z jest 8
Oct 17 17:28:03 <BuBi`> no wlasnie
Oct 17 17:28:08 <BuBi`> co z tym fantem zrobic
Oct 17 17:28:10 <BeerfaN> to do egzorcysty
%
#debian.pl
Oct 17 23:49:20 <Borry> żorż kochasz mię ? kocham cię żak ! żorż a masz żętu ?
%
#debian.pl
Oct 20 06:18:58 fEnIo is gone: uczelnia... choć o tej porze chciałoby się rzecz 
kamieniołom
%
#debian.pl
Oct 21 11:04:55 <Borgin> a jak włamac sie do jakiegos serwera uzywajac auroxa?
Oct 21 11:05:26 <fEnIo> Borgin: wpisz w google "why am I script-kiddie"
%
#debian.pl
Oct 21 23:38:56 <_leeloo_> eh... a sobie celeronka 2,66 kupialm
Oct 21 23:39:04 <BeerfaN> po co ci kastrat?
Oct 21 23:39:13 <_leeloo_> bo lubie takich? ;P
Oct 21 23:39:20 <BeerfaN> hm ;)
Oct 21 23:39:21 <_leeloo_> myslisz ze czemu z Toba rozmawiam
%
Oct 22 22:25:34 <saintyves> chodzi o to, że jak napisałem podobno jądro
2.4.20 mają htb w sobie
Oct 22 22:25:38 <saintyves> ja nic nie zmieniałem
Oct 22 22:25:39 <fEnIo> saintyves: jeśli o kompilacji jąder wiesz tyle
co o wpływie jąder na komórki jajowe kobiet to weź korzystaj z fachowych
jąder dystrybucyjnych
Oct 22 22:25:41 <saintyves> sprawdzam
Oct 22 22:25:42 <saintyves> i nie ma
Oct 22 22:26:09 <saintyves> ale ja lubie się bawić jądrami
Oct 22 22:26:11 <saintyves> ;)
Oct 22 22:26:19 <fEnIo> ja wolę cyckami ;P
%
Oct 22 23:06:38 <saintyves> make: *** [extensions/libipt_CLASSIFY_sh.o] Błąd 1
Oct 22 23:06:42 <saintyves> czy ktoś
Oct 22 23:06:45 <saintyves> wie, co to znaczy?
Oct 22 23:07:00 <dredzik> to znaczy że jest błąd i nie skompiluje się.
Oct 22 23:07:18 <wiedzmin_> dredzik: tajest
Oct 22 23:07:40 <saintyves> dredzik: dzięki, już uciekam, ale ty jesteś mądry... :P
Oct 22 23:07:42 <Verdan> zazwyczaj ciężko po jednej linijce zorientować się o co chodzi
Oct 22 23:08:03 <dredzik> saintyves, no co? pytałeś czy ktoś wie co to znaczy - no to właśnie to znaczy.
Oct 22 23:08:26 <fEnIo> to znaczy, że błąd 1
Oct 22 23:08:48 <saintyves> @Verdan: akurat mam tylko ten błąd
Oct 22 23:08:48 <fEnIo> a to z kolei znaczy, że błędów musi być więcej niż 1 bo inaczej żaden pajac
by ich nie numerował
Oct 22 23:09:28 <saintyves> dziwne...
Oct 22 23:09:55 <saintyves> fEnIo: to bardzo filozoficze...
Oct 22 23:10:10 <fEnIo> zawsze tak mam na bani
%
Oct 25 21:09:09 <natan4> pewnie cos si ewyspalo z nim
Oct 25 21:09:16 <natan4> ikuko_0 nie grzechocze ?
Oct 25 21:09:30 <ikuko_0> ssij
Oct 25 21:09:34 <LiNiO> nie syczy?
Oct 25 21:09:42 <natan4> pytam powaznie
Oct 25 21:09:46 <natan4> czy ni erobi tak
Oct 25 21:09:59 <natan4> tssy cy cy cy tsssssy cy cy cy tssssssyt cy cy cy tssssssssy cy cy cy
%
Oct 26 12:05:16 <LiNiO> dziecko mnie do żony przekablowało
Oct 26 12:05:35 <LiNiO> świat schodzi na psy
Oct 26 12:05:56 <Greyer-q> LiNiO: dziecko nakablowalo ?
Oct 26 12:06:13 <Greyer-q> LiNiO: zagroz ze nie dasz mu kieszonkowego to cicho siedziec bedzie :)
Oct 26 12:06:49 <BeerfaN> a co przekablowalo?
Oct 26 12:08:12 <LiNiO> że sie ze mną jedna pani umawiała i jak powiedziałem że nie mam czasu żeby pozaglądać do jej komputera to ona powiedziała że niekoniecznie do komputera
%
Oct 26 20:01:44 fEnIo is gone: closeup wypierdalaj
Oct 26 20:01:47 <fEnIo> tfu
Oct 26 20:01:54 *** mode #debian.pl "+b *!*math@*.neoplus.adsl.tpnet.pl" by fEnIo
Oct 26 20:01:54 *** closeup kicked off from #debian.pl by fEnIo (wypierdalaj)
%
Oct 28 22:17:51 <fEnIo> psssssssssssssssssst
Oct 28 22:20:46 <ike> LiNiO ;>
Oct 28 22:20:55 <ike> aż fEnIo zasyczał.
Oct 28 22:21:14 <fEnIo> to piwo for christ's sake
Oct 28 22:21:18 <LiNiO> bo literki tupią po ekranie ;)
Oct 28 22:21:53 <ike> piwo tupie? :>
Oct 28 22:22:09 <fEnIo> piwo robi pssssssssssssst jak się je otwiera ;P
Oct 28 22:22:27 <dygi> denerwujace to gg
Oct 28 22:22:34 <ike> Czyli ucisza ludzi.
Oct 28 22:22:48 <fEnIo> dygi: czy ja wiem... jak nie działa to mnie nawet nie denerwuje
Oct 28 22:22:53 <ike> Idąc dalej tą implikacją - mogę pić piwo w kinie, bo nie lubie jak ktoś głośno gada.
Oct 28 22:23:08 <fEnIo> ike: przestań łazić po implikacjach i idź spać
Oct 28 22:23:38 <dygi> fenio: u mnie odwrotnie
Oct 28 22:23:39 <fEnIo> bo Ci alternatywą koniunkcji zajebię i się skończy
%
Oct 28 22:25:46 <dygi> posiada ktos jakies materialy elektroniczne pomocne w nauce elektroniki, robotyki, teorii automatow etc?
Oct 28 22:26:00 <fEnIo> dygi: mam zepsute wideo, chcesz?
Oct 28 22:26:14 <dygi> tez mam
Oct 28 22:26:20 <dygi> televizor tez
Oct 28 22:26:21 <fEnIo> to napraw w ramach nauki ;P
%
Oct 29 13:39:16 <LiNiO>         KOMENTARZ DNIA
Oct 29 13:39:16 <LiNiO>         Firefox 1.0 final:
Oct 29 13:39:16 <LiNiO> "Ten caly firefox to jakieś badziewie na pewno. Nie instalowałem go wprawdzie, ale nawet screenow z niego nie mogłem na sieci znaleźć, wiec chyba to jakaś niszowa przeglądarka, do której ciężko dotrzeć. A zaraz się okaże, że jak taka słaba, to dziur nie będzie miał w niej kto łatać i wirusy będą przez nią przechodzić. Dużo bardziej wole IE, który ma nawet taką ciekawą funkcjonalność, że potrafi samemu wykryć, iż jest nowa wersja
Oct 29 13:39:17 <LiNiO>  i poinformuje o tym użytkownika i wiadomo kiedy trzeba ściągnąć." - (chlopek-roztropek)
%
Oct 30 16:10:26 <natan4> eh glaby
Oct 30 16:10:43 <natan4> po co user ma miec dostep do serverka jak mozna all zrobic w bazie danych dla niego ?
Oct 30 16:10:52 *** mode #debian.pl "-v natan4" by fEnIo
Oct 30 16:11:00 <fEnIo> bo jeszcze ktoś pomyśli, że mądrze prawisz
%
Oct 31 22:56:53 <fEnIo> StalowyMA: masz 17 lat prawda?
Oct 31 22:56:57 <StalowyMA> tak
Oct 31 22:57:03 <StalowyMA> i ?? to cos zlego :/
Oct 31 22:57:05 <fEnIo> StalowyMA: i czego się kurwa nauczyłeś przez te lata?
Oct 31 22:57:19 <StalowyMA> no w jakim sesie ??
Oct 31 22:57:20 <fial> bill gates w twoim wieku napisal kolko i krzyzyk pod dosa
Oct 31 22:57:25 <fial> a ty co stworzyles?
%
Nov 02 11:57:36 <natan4> napisalem przez telefon kolesiowi /etc/init.d/ssh restart
Nov 02 11:57:43 <fEnIo> dygi: `dpkg-reconfigure console-data`
Nov 02 11:57:50 <natan4> a koles no napisalem /etc/init.d/ssh
Nov 02 11:57:57 <natan4> a potem daklem mu control alt delete
%
Nov 02 14:24:40 <Aqq> kumpel lecial z pyrzowic airbusem a320, i potracil jelenia ;>
Nov 02 14:25:32 <masklin> Aqq: w locie? :>
%
Nov 02 18:26:44 <natan4> mam dctc ale nie moge si epolaczyc
Nov 02 18:26:55 <natan4> dctc -n natan -a host ip port i qq
Nov 02 18:27:25 <BeerfaN> zamiast i qq, wpisz Aqq
Nov 02 18:28:03 *** BeerfaN kicked off from #debian.pl by Aqq ((nie wymieniaj imiena pana swego na daremnie))
%
Nov 02 20:14:24 <redloff> bo w panualu mama nie ma
Nov 02 20:14:27 <redloff> tfu
Nov 02 20:14:29 <redloff> w manualu pama
%
Nov 03 20:40:37 <ShOcK> co trzeba zmienić na serwerze żeby niedało się go zdosować ? :O
Nov 03 20:40:54 <fEnIo> interfejs z eth0 na lo
Nov 03 20:41:12 <ShOcK> w jaki sposób ? :>
Nov 03 20:41:18 <BeerfaN> ;0
Nov 03 20:41:25 <BeerfaN> ifconfig eth0 down
Nov 03 20:41:29 <fEnIo> wyjmując wtyczkę z eth0 ;)
%
Nov 06 15:22:51 <dygi> czy program powiedzmy w pascalu skompilowany na linux, musi byc skompilowany osobno na windows?
%
Nov 07 11:14:53 fEnIo is back from sklep after 18 mins 51 secs
Nov 07 11:15:17 <ike> Hm. słabo.
Nov 07 11:15:25 <ike> fEnIo : zejdź do 10 minut.
Nov 07 11:15:38 <fEnIo> pies srał
%
Nov 07 12:00:37 <fEnIo> się śmiej... nie wie co za debil wymyślił te mini kieszonki na zapalniczki... jak kiedyś chciałem kucnąć to mi nieźle koszulkę przysmoliło
Nov 07 12:01:15 <AKW> niektorym wadliwe zapalniczki wybuchly w łapach
Nov 07 12:01:15 <BeerfaN> to nie na zapalniczki tylko na gumki ;P
Nov 07 12:01:15 <MardoooK> :P
Nov 07 12:01:29 <AKW> kieszonka kondonowa
Nov 07 12:01:31 <fEnIo> gumki trzymam w aptece ;P
Nov 07 12:01:40 *** astral_ (~jarocin.q@bwd231.neoplus.adsl.tpnet.pl) has joined #debian.pl
Nov 07 12:01:41 <fEnIo> kondomowa jak już ;P
Nov 07 12:01:53 <MardoooK> hehe :D
Nov 07 12:02:09 <AKW> no, wlasnie
Nov 07 12:02:32 <fEnIo> poza tym kondomy to przeżytek... panienki się namawia na pigułki antykoncepcyjne ;P
Nov 07 12:02:43 <fEnIo> jak im wąsy wyrastają to i tak już mam inną ;P
%
Nov 07 13:42:10 <LiNiO> dd if=/dev/kran of=/dev/czajnik bs=1l count=2
%
Nov 10 20:58:07 <Torin> natan4: bo nie wpadne na browarki
Nov 10 20:58:12 <natan4> hah
Nov 10 20:58:26 <natan4> myszlisz ze podam reke slackwerowcowi ?
Nov 10 20:58:31 <Torin> tak
Nov 10 20:58:58 <natan4> a potem musze ja we wzatku odkazic
Nov 10 20:59:23 <Torin> co ja mam powiedziec o debianowcach
Nov 10 20:59:32 *** Torin kicked off from #debian.pl by wiedzmin_ (nic nie mów :P)
Nov 10 20:59:36 <natan4> proste zaraz ci powiem
Nov 10 20:59:36 *** Torin (torin@217.97.152.82) has joined #debian.pl
Nov 10 20:59:41 <Torin> a wolnosc slowa ?
Nov 10 20:59:41 <BeerfaN> na ich kanale - same najlepsze rzeczy
Nov 10 20:59:45 <BeerfaN> ;)
Nov 10 20:59:49 <wiedzmin_> Torin: nie ma :)
Nov 10 20:59:53 <BeerfaN> wolnosci to poszukaj w slowniku, jest na litere W
Nov 10 20:59:57 <wiedzmin_> Torin: ja jestem debianowym faszystą :)
Nov 10 21:00:01 <natan4> debianowcy - mili i inteligenti ludzie ktorzy chetnie pomoga innym poza slackwerowcami
%
Nov 14 14:52:01 <Unc> kurde siedze na wykladachz  sieci i smiac mis ie chce jak gosciu tlumaczy jak
sie robi nata
Nov 14 14:52:12 <dygi> natana?
%
Nov 15 20:04:18 <BeerfaN> ikeX  ikeX idz do spania
Nov 15 20:04:51 <ikeX> BeerfaN : juz dzis spalem ;-)
Nov 15 20:05:01 <BeerfaN> ikeX  i nie masz zamiaru wiecej?
Nov 15 20:05:52 <ikeX> BeerfaN : hm. nie. powiedziala, ze jutro bedziemy spac znowu.
Nov 15 20:05:57 <ikeX> Wiec teraz nie musze.
Nov 15 20:05:57 <BeerfaN> ech
Nov 15 20:06:08 <BeerfaN> no dobra
Nov 15 20:06:10 <ikeX> :-) nie ma to jak gadajaca poducha.
%
Nov 18 18:54:45 <Aqq> LiNiO: bawiles sie ulogd ? logi --> do bazy
Nov 18 18:54:58 <LiNiO> Aqq nie
Nov 18 18:55:04 <LiNiO> wole inne zabawy ;)
Nov 18 18:55:16 <Aqq> wiem wiem
Nov 18 18:55:21 <Aqq> masz 3 dzieci :P
%
Nov 21 14:58:14 <met> hm jest już paczka toppler?
Nov 21 14:58:51 <met> jest :)
Nov 21 14:58:55 <BeerfaN> sa paczki top i less
%
Nov 22 21:42:30 <fEnIo> nie z przymiotnikami piszemy razem... inaczej durnie wygląda :P
%
Nov 23 17:16:35 <jerzy_pre> czy debian obsluguje ntfs czy trzeba zainstalowac jakas latke jak w fedorze ?
Nov 23 17:16:57 <fEnIo> jerzy_pre: zapis czy odczyt?
Nov 23 17:17:03 <jerzy_pre> odczyt
Nov 23 17:17:13 <fEnIo> jerzy_pre: `modprobe ntfs`
Nov 23 17:18:12 <jerzy_pre> i co z tym modprobe ? w fstabie wpisac czy co... ?
%
Nov 23 20:32:39 <m15ch4> ma ktoś zainstalowane z jądrem 2.6.9 sterowniki do NVidii te z ich strony
Nov 23 20:38:11 <met> ja mam.
Nov 23 20:38:18 <met> ale nie z ich strony
Nov 23 20:38:22 <met> tylko te z repo debiana
Nov 23 20:39:41 <m15ch4> met: ???
Nov 23 20:40:02 <m15ch4> nie chcą mi się zainstalować
Nov 23 20:40:02 <m15ch4> poradzcie coś
Nov 23 20:40:06 <met> spróbuję w twoim języku:
Nov 23 20:40:13 <met> j4 /\/\4/\/\, 413 |\||3 2 |(|-| 57r0|\|y, 7y1|<0 2 r3p0 |)3b|4|\|4
%
Nov 24 15:26:25 <zim`> moja guma do zucia smakuje piwem
Nov 24 15:26:52 <m_o_d> zim`: co za guma?
Nov 24 15:26:57 <m_o_d> zim`: daj nazwe
Nov 24 15:27:07 <m_o_d> to bylo by odkrycie wieku
Nov 24 15:27:16 <m_o_d> po piwku mowil bym ze gume jadlem :P
%
Nov 26 12:43:23 *** montee (~montee@nat2.broker.com.pl) has joined #debian.pl
Nov 26 12:43:38 <montee> witam
Nov 26 12:43:43 <Buciorek> montee: witaj
Nov 26 12:44:20 <montee> Buciorek : czesc
Nov 26 12:44:23 <montee> ;)
Nov 26 12:44:41 <Buciorek> czesc
Nov 26 12:45:05 <montee> Buciorek : co slychac
Nov 26 12:45:21 <montee> Buciorek : dalej jestes botem?
Nov 26 12:45:21 <Buciorek> a na jaki temat?
Nov 26 12:45:36 <Buciorek> no jak nie - jestem...
Nov 26 12:48:31 <montee> lubisz Buciorek debiana?
Nov 26 12:50:11 <montee> Buciorek lubisz?
Nov 26 12:50:28 <Buciorek> a czemu mam nie lubic ;)
Nov 26 12:51:02 <montee> teraz to juz nie wiem czy jeses botem czy nie :>
%
Nov 26 19:29:45 <m_o_d> czas do wanny a potem bar :P
Nov 26 19:30:03 <BeerfaN> bosz
Nov 26 19:30:15 <m_o_d> BeerfaN: co ?
Nov 26 19:30:16 <BeerfaN> bys sie nie przyznawal
Nov 26 19:30:17 <BeerfaN> ;)
Nov 26 19:30:47 <m_o_d> BeerfaN: no fakt, wkoncu dlaciebie to stres slyszec slowo wanna raz w miesiacu
%
Nov 27 14:10:25 <jkl> czesc
Nov 27 14:10:26 <Buciorek> jkl: witaj
Nov 27 14:11:17 <jkl> Buciorek : tys mi najblizszy z calego ircnetu.. skad jestes? :>
Nov 27 14:11:18 <Buciorek>  z zamoscia
Nov 27 14:11:44 <jkl> Buciorek : na priv ;)
Nov 27 14:11:44 <Buciorek>  a jak u Ciebie z seksem?
%
Nov 27 19:33:17 <greg__> Program received signal SIGFPE, Arithmetic exception.
Nov 27 19:33:32 <greg__> co to znaczy, tak mniej wiecej?
Nov 27 19:33:41 <e-krolik> greg__: przeliczył się ;)
%
Nov 28 21:54:40 <fEnIo> byłem przed godziną psa kumplowi kupić to cipa powiedziała, że jest inny klient
Nov 28 21:54:50 <Rzepa> psa?
Nov 28 21:54:51 <LiNiO> to i tak najlepiej kiedyś Unc czasu dał ;)
Nov 28 21:54:53 <fEnIo> a kumpel jest tak najebany, że się zgodził na psa
Nov 28 21:54:55 <Rzepa> takie zwierzatko?
Nov 28 21:55:12 <montee> nigdy sie tak nie opilem zeby sobie psa kupic
Nov 28 21:55:23 <fEnIo> no zwierzątko... załatwiłem transport z TRZEŹWYM kierowcą i nie wyszło
%
Dec 01 23:18:01 <nakus> jak pisze "kdm" , to mi monitor pare razy mruga i nic
Dec 01 23:18:26 <leeloo> nakus: spalila Ci sie karta graficzna
%
Dec 03 20:27:07 <stal_MAN> elo
Dec 03 20:27:10 <stal_MAN> hey
Dec 03 20:27:16 <stal_MAN> jolll :D
Dec 03 20:27:40 <stal_MAN> fEnIo: mowie w 3 jezykach jednoczesnie :)))
Dec 03 20:28:04 *** mode #debian.pl "+b *!*dawidk2@*.neoplus.adsl.tpnet.pl" by fEnIo
Dec 03 20:28:05 *** stal_MAN kicked off from #debian.pl by fEnIo (arivederci - czwarty język)
%
Dec 04 11:43:34 <harnir> Buciorek shackowany... ;)
Dec 04 11:43:37 <Buciorek>  jakby się tak zastanowić, to chyba tak...
%
Dec 04 14:03:54 <Rzepa> wie ktos jak mozma wytlumaczyc roznice miedzy specyfikacja modularyzacja?
Dec 04 14:04:32 <porridge1> Rzepa: mniej więcej tak jak między jabłkiem a astronomią
%

