/*    ---->> IRQ <<----         */
/* quick hack to split the text */

#include <stdio.h>

void main()
{

int no=1;
char buf[257];
FILE *r,*w;
r=fopen("excuses","r");
w=fopen("bofh-excuses","w");

 while ( fgets(buf,256,r) )
  {
    fprintf(w,"BOFH excuse #%d:\n\n%s\%%\n",no++,buf);
  }

fclose(r);
fclose(w);
}