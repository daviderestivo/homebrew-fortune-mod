#!/bin/sh

rm excuses
rm bofh-excuses
rm bofh-excuses.dat

wget -c -T 40 http://www.cs.wisc.edu/~ballard/bofh/excuses
./l2f.e
strfile bofh-excuses